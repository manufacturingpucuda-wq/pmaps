import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { Clock, Users, Settings, FileText, Download, Printer, User, Calendar, CheckCircle, AlertCircle, Coffee, Timer } from "lucide-react";
import { useClockEmployees, useClockLogs, useAddClockEmployee, useUpdateClockEmployee, useDeleteClockEmployee, useClockAction, useEmployeeTimeCard, useExportAllHours } from "@/hooks/use-clock-system";
import type { ClockEmployee } from "@shared/schema";

export default function TimeClock() {
  const { toast } = useToast();
  const hiddenInputRef = useRef<HTMLInputElement>(null);
  
  // State management
  const [currentEmployee, setCurrentEmployee] = useState<ClockEmployee | null>(null);
  const [statusMessage, setStatusMessage] = useState("");
  const [showAdminPanel, setShowAdminPanel] = useState(false);
  const [showTimeCardModal, setShowTimeCardModal] = useState(false);
  const [timeCardData, setTimeCardData] = useState<any>(null);
  
  // Admin form states
  const [employeeForm, setEmployeeForm] = useState({
    id: "",
    name: "",
    pin: "",
    payRate: ""
  });
  
  // Time card form
  const [timeCardForm, setTimeCardForm] = useState({
    employeeId: "",
    startDate: "",
    endDate: ""
  });
  
  // Export form
  const [exportForm, setExportForm] = useState({
    startDate: "",
    endDate: ""
  });

  // Queries and mutations
  const { data: employees = [], refetch: refetchEmployees } = useClockEmployees();
  const { data: logs = [] } = useClockLogs();
  
  // Type assertions for data
  const typedEmployees = employees as ClockEmployee[];
  const typedLogs = logs as any[];
  const addEmployeeMutation = useAddClockEmployee();
  const updateEmployeeMutation = useUpdateClockEmployee();
  const deleteEmployeeMutation = useDeleteClockEmployee();
  const clockActionMutation = useClockAction();
  const timeCardMutation = useEmployeeTimeCard();
  const exportMutation = useExportAllHours();

  // Auto-focus the hidden input for barcode scanning
  useEffect(() => {
    const focusInput = () => {
      if (hiddenInputRef.current && !showAdminPanel) {
        hiddenInputRef.current.focus();
      }
    };
    
    focusInput();
    const interval = setInterval(focusInput, 1000);
    
    return () => clearInterval(interval);
  }, [showAdminPanel]);

  // Handle barcode input
  const handleBarcodeInput = async (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      const employeeId = e.currentTarget.value.trim();
      if (!employeeId) return;
      
      // Clear input immediately
      e.currentTarget.value = '';
      
      // Check for admin access
      if (employeeId === 'ADMIN123') {
        setShowAdminPanel(true);
        return;
      }
      
      try {
        const result = await clockActionMutation.mutateAsync(employeeId) as any;
        setCurrentEmployee(result.employee);
        setStatusMessage(result.status);
        
        // Show status message temporarily
        setTimeout(() => {
          setStatusMessage("");
        }, 3000);
        
        toast({
          title: "Success",
          description: `${result.employee.name}: ${result.status}`,
        });
        
        refetchEmployees();
      } catch (error: any) {
        toast({
          title: "Error",
          description: error.message || "Failed to process clock action",
          variant: "destructive",
        });
      }
    }
  };

  // Admin functions
  const handleAddEmployee = async () => {
    if (!employeeForm.id || !employeeForm.name || !employeeForm.payRate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    try {
      await addEmployeeMutation.mutateAsync({
        id: employeeForm.id,
        name: employeeForm.name,
        pin: employeeForm.pin || undefined,
        payRate: employeeForm.payRate,
      });
      
      setEmployeeForm({ id: "", name: "", pin: "", payRate: "" });
      toast({
        title: "Success",
        description: "Employee added successfully",
      });
    } catch (error) {
      toast({
        title: "Error", 
        description: "Failed to add employee",
        variant: "destructive",
      });
    }
  };

  const handleDeleteEmployee = async (id: string) => {
    try {
      await deleteEmployeeMutation.mutateAsync(id);
      toast({
        title: "Success",
        description: "Employee deleted successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to delete employee",
        variant: "destructive",
      });
    }
  };

  // Time card functions
  const handleLoadTimeCard = async () => {
    if (!timeCardForm.employeeId || !timeCardForm.startDate || !timeCardForm.endDate) {
      toast({
        title: "Error",
        description: "Please fill in all fields",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await timeCardMutation.mutateAsync({
        employeeId: timeCardForm.employeeId,
        startDate: timeCardForm.startDate,
        endDate: timeCardForm.endDate,
      });
      setTimeCardData(result);
      setShowTimeCardModal(true);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to load time card",
        variant: "destructive",
      });
    }
  };

  const handleExportHours = async () => {
    if (!exportForm.startDate || !exportForm.endDate) {
      toast({
        title: "Error",
        description: "Please select start and end dates",
        variant: "destructive",
      });
      return;
    }

    try {
      const result = await exportMutation.mutateAsync({
        startDate: exportForm.startDate,
        endDate: exportForm.endDate,
      }) as any;
      
      // Create CSV content
      const csvContent = "data:text/csv;charset=utf-8," + 
        "Employee ID,Employee Name,Pay Rate,Total Hours,Total Pay\n" +
        result.employees.map((emp: any) => 
          `${emp.employeeId},${emp.employeeName},${emp.payRate},${emp.totalHours},${emp.totalPay}`
        ).join("\n");
      
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `payroll_${result.startDate}_to_${result.endDate}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      toast({
        title: "Success",
        description: "Hours exported successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to export hours",
        variant: "destructive",
      });
    }
  };

  const formatDuration = (milliseconds: number) => {
    const hours = Math.floor(milliseconds / (1000 * 60 * 60));
    const minutes = Math.floor((milliseconds % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  const formatTimestamp = (timestamp: number) => {
    return new Date(timestamp).toLocaleString();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'working': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'on-lunch': return <Coffee className="h-4 w-4 text-yellow-500" />;
      default: return <AlertCircle className="h-4 w-4 text-gray-500" />;
    }
  };

  const getNextAction = (employee: ClockEmployee) => {
    switch (employee.status) {
      case 'inactive': return 'Clock In';
      case 'working': return 'Start Lunch or Clock Out';
      case 'on-lunch': return 'End Lunch';
      default: return 'Unknown';
    }
  };

  if (showAdminPanel) {
    return (
      <div className="space-y-6 p-6">
        {/* Admin Header */}
        <header className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-b border-border px-6 py-6 -mx-6 -mt-6 mb-6 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Settings className="h-8 w-8" />
              <div>
                <h1 className="text-2xl font-bold">Time Clock Admin Panel</h1>
                <p className="text-blue-100 text-sm">Manage employees and generate reports</p>
              </div>
            </div>
            
            <Button 
              onClick={() => setShowAdminPanel(false)}
              variant="outline"
              className="bg-white/10 border-white/20 text-white hover:bg-white/20"
              data-testid="button-back-employee"
            >
              <User className="h-4 w-4 mr-2" />
              Back to Employee View
            </Button>
          </div>
        </header>

        {/* Employee Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Users className="h-5 w-5 mr-2" />
              Manage Employees
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Employee ID (e.g., EMP001)"
                value={employeeForm.id}
                onChange={(e) => setEmployeeForm(prev => ({ ...prev, id: e.target.value }))}
                data-testid="input-employee-id"
              />
              <Input
                placeholder="Employee Name"
                value={employeeForm.name}
                onChange={(e) => setEmployeeForm(prev => ({ ...prev, name: e.target.value }))}
                data-testid="input-employee-name"
              />
              <Input
                placeholder="PIN (optional)"
                value={employeeForm.pin}
                onChange={(e) => setEmployeeForm(prev => ({ ...prev, pin: e.target.value }))}
                data-testid="input-employee-pin"
              />
              <Input
                type="number"
                step="0.01"
                placeholder="Pay Rate"
                value={employeeForm.payRate}
                onChange={(e) => setEmployeeForm(prev => ({ ...prev, payRate: e.target.value }))}
                data-testid="input-employee-payrate"
              />
            </div>
            <Button 
              onClick={handleAddEmployee} 
              className="w-full"
              disabled={addEmployeeMutation.isPending}
              data-testid="button-add-employee"
            >
              Add Employee
            </Button>
            
            {/* Employee List */}
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Employee ID</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead>Pay Rate</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {typedEmployees.map((employee: ClockEmployee) => (
                    <TableRow key={employee.id}>
                      <TableCell className="font-mono">{employee.id}</TableCell>
                      <TableCell>{employee.name}</TableCell>
                      <TableCell>${employee.payRate}/hr</TableCell>
                      <TableCell>
                        <div className="flex items-center space-x-2">
                          {getStatusIcon(employee.status || 'inactive')}
                          <span className="capitalize">{employee.status || 'inactive'}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteEmployee(employee.id)}
                          data-testid={`button-delete-${employee.id}`}
                        >
                          Delete
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        {/* Time Card Generation */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Employee Time Card
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Input
                placeholder="Employee ID"
                value={timeCardForm.employeeId}
                onChange={(e) => setTimeCardForm(prev => ({ ...prev, employeeId: e.target.value }))}
                data-testid="input-timecard-employee-id"
              />
              <Input
                type="date"
                value={timeCardForm.startDate}
                onChange={(e) => setTimeCardForm(prev => ({ ...prev, startDate: e.target.value }))}
                data-testid="input-timecard-start-date"
              />
              <Input
                type="date"
                value={timeCardForm.endDate}
                onChange={(e) => setTimeCardForm(prev => ({ ...prev, endDate: e.target.value }))}
                data-testid="input-timecard-end-date"
              />
              <Button 
                onClick={handleLoadTimeCard}
                disabled={timeCardMutation.isPending}
                data-testid="button-load-timecard"
              >
                <FileText className="h-4 w-4 mr-2" />
                Load Time Card
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Export All Hours */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Download className="h-5 w-5 mr-2" />
              Export All Hours
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Input
                type="date"
                value={exportForm.startDate}
                onChange={(e) => setExportForm(prev => ({ ...prev, startDate: e.target.value }))}
                data-testid="input-export-start-date"
              />
              <Input
                type="date"
                value={exportForm.endDate}
                onChange={(e) => setExportForm(prev => ({ ...prev, endDate: e.target.value }))}
                data-testid="input-export-end-date"
              />
              <Button 
                onClick={handleExportHours}
                disabled={exportMutation.isPending}
                data-testid="button-export-hours"
              >
                <Download className="h-4 w-4 mr-2" />
                Export to CSV
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Time Card Modal */}
        <Dialog open={showTimeCardModal} onOpenChange={setShowTimeCardModal}>
          <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Time Card Report</DialogTitle>
            </DialogHeader>
            {timeCardData && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="text-xl font-bold">
                    Time Card for {timeCardData.employee.name} ({timeCardData.employee.id})
                  </h3>
                  <p className="text-gray-600">Pay Rate: ${timeCardData.employee.payRate}/hour</p>
                  <p className="text-gray-600">
                    Period: {timeCardData.startDate} to {timeCardData.endDate}
                  </p>
                </div>

                {Object.entries(timeCardData.dailyReport).map(([date, data]: [string, any]) => (
                  <Card key={date}>
                    <CardHeader>
                      <CardTitle className="text-lg">{date}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-3 gap-4 mb-4">
                        <div>
                          <p className="font-semibold">Working Time:</p>
                          <p>{formatDuration(data.workingTime)}</p>
                        </div>
                        <div>
                          <p className="font-semibold">Lunch Break:</p>
                          <p>{formatDuration(data.lunchTime)}</p>
                        </div>
                        <div>
                          <p className="font-semibold">Log Details:</p>
                          <ul className="text-sm">
                            {data.logs.map((log: any, idx: number) => (
                              <li key={idx}>
                                {log.type.replace('-', ' ')} at {formatTimestamp(log.timestamp)}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                <div className="border-t pt-4 text-center">
                  <h3 className="text-xl font-bold text-blue-700">
                    Total Working Hours: {formatDuration(timeCardData.totalWorkingTime)}
                  </h3>
                  <h4 className="text-lg font-bold text-green-700">
                    Total Pay: ${timeCardData.totalPay}
                  </h4>
                  <Button 
                    onClick={() => window.print()} 
                    className="mt-4"
                    data-testid="button-print-timecard"
                  >
                    <Printer className="h-4 w-4 mr-2" />
                    Print Time Card
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6">
      {/* Hidden input for barcode scanning */}
      <input
        ref={hiddenInputRef}
        type="text"
        className="sr-only"
        onKeyDown={handleBarcodeInput}
        autoFocus
        aria-label="Barcode scanner input"
        data-testid="input-hidden-barcode"
      />

      {/* Header */}
      <header className="bg-gradient-to-r from-green-600 to-blue-600 text-white border-b border-border px-6 py-6 -mx-6 -mt-6 mb-6 rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Clock className="h-8 w-8" />
            <div>
              <h1 className="text-2xl font-bold">PUCUDA MFG Employee Clock-In</h1>
              <p className="text-blue-100 text-sm">Scan your employee barcode to clock in/out</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-2">
            <Calendar className="h-4 w-4" />
            <span className="text-sm">{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </header>

      {/* Current Status Display */}
      <Card className="bg-gradient-to-br from-blue-50 to-green-50 border-2 border-blue-200">
        <CardContent className="text-center py-8">
          {currentEmployee ? (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-blue-900">
                Welcome, {currentEmployee.name}!
              </h2>
              <div className="flex items-center justify-center space-x-2">
                {getStatusIcon(currentEmployee.status || 'inactive')}
                <span className="text-lg font-semibold capitalize">
                  {currentEmployee.status || 'inactive'}
                </span>
              </div>
              <p className="text-lg text-gray-700">
                Please scan to {getNextAction(currentEmployee)}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-blue-900">Welcome!</h2>
              <p className="text-lg text-gray-700">Please scan your Employee ID.</p>
            </div>
          )}
          
          {statusMessage && (
            <div className="mt-4 p-4 bg-green-100 border border-green-200 rounded-lg">
              <p className="text-2xl font-bold text-green-700">{statusMessage}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Employee Status Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Users className="h-5 w-5 mr-2" />
            Current Employee Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {typedEmployees.map((employee: ClockEmployee) => (
              <div key={employee.id} className="p-4 border border-gray-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-semibold">{employee.name}</p>
                    <p className="text-sm text-gray-600">{employee.id}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    {getStatusIcon(employee.status || 'inactive')}
                    <span className="text-sm capitalize">{employee.status || 'inactive'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Timer className="h-5 w-5 mr-2" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Employee</TableHead>
                  <TableHead>Action</TableHead>
                  <TableHead>Time</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {typedLogs.slice(0, 10).map((log: any) => {
                  const employee = typedEmployees.find(e => e.id === log.employeeId);
                  return (
                    <TableRow key={log.id}>
                      <TableCell>{employee?.name || log.employeeId}</TableCell>
                      <TableCell className="capitalize">{log.type.replace('-', ' ')}</TableCell>
                      <TableCell>{formatTimestamp(log.timestamp)}</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Instructions */}
      <Card>
        <CardHeader>
          <CardTitle>How to Use</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-gray-900 mb-3">For Employees</h3>
              <ul className="space-y-2 text-sm text-gray-600">
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Scan your employee barcode to clock in
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Scan again to start lunch break
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Scan once more to end lunch
                </li>
                <li className="flex items-center">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                  Final scan to clock out
                </li>
              </ul>
            </div>
            
            
          </div>
        </CardContent>
      </Card>
    </div>
  );
}