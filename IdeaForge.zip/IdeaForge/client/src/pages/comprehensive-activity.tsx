import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity as ActivityIcon, 
  Download, 
  Filter, 
  Search, 
  Calendar,
  User, 
  Package,
  ArrowDownToLine,
  ArrowUpFromLine,
  Clock,
  MapPin,
  FileText,
  AlertTriangle,
  TrendingUp,
  BarChart3,
  CheckCircle2
} from "lucide-react";
import { format, parseISO, startOfDay, endOfDay, subDays } from "date-fns";
import { useAuth } from "@/hooks/useAuth";

interface EnhancedTransaction {
  id: string;
  itemId: string;
  orderId?: string;
  userId: string;
  transactionType: "check-in" | "check-out";
  quantity: number;
  notes?: string;
  reasonCode?: string;
  condition?: string;
  location?: string;
  workOrder?: string;
  department?: string;
  urgency?: string;
  estimatedReturnDate?: string;
  actualReturnDate?: string;
  approvedBy?: string;
  batchNumber?: string;
  serialNumbers?: string[];
  createdAt: string;
  item: {
    id: string;
    sku: string;
    productName: string;
    unitType: string;
  };
  user: {
    id: string;
    firstName: string;
    lastName: string;
    username: string;
    role: string;
    department?: string;
  };
  approver?: {
    id: string;
    firstName: string;
    lastName: string;
    username: string;
  };
}

export default function ComprehensiveActivity() {
  const { user, isLoading } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");
  const [filterType, setFilterType] = useState<"all" | "check-in" | "check-out">("all");
  const [filterUser, setFilterUser] = useState("all");
  const [filterDepartment, setFilterDepartment] = useState("all");
  const [filterUrgency, setFilterUrgency] = useState("all");
  const [filterReasonCode, setFilterReasonCode] = useState("all");
  const [dateRange, setDateRange] = useState("7"); // Last 7 days
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;

  const { data: transactions = [], isLoading: isLoadingTransactions } = useQuery<EnhancedTransaction[]>({
    queryKey: ["/api/transactions/enhanced"],
    enabled: !!user,
  });

  const { data: users = [] } = useQuery<any[]>({
    queryKey: ["/api/users"],
    enabled: !!user,
  });

  if (isLoading || !user) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (user.role !== "admin" && user.role !== "manager") {
    return (
      <div className="space-y-6 p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-muted-foreground">
              You don't have permission to access comprehensive activity reports.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Filter transactions based on criteria
  const filteredTransactions = useMemo(() => {
    let filtered = transactions;

    // Date range filter
    if (dateRange !== "all") {
      const daysBack = parseInt(dateRange);
      const cutoffDate = subDays(startOfDay(new Date()), daysBack);
      filtered = filtered.filter(t => 
        new Date(t.createdAt) >= cutoffDate
      );
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(t => 
        t.item.sku.toLowerCase().includes(query) ||
        t.item.productName.toLowerCase().includes(query) ||
        `${t.user.firstName} ${t.user.lastName}`.toLowerCase().includes(query) ||
        t.user.username.toLowerCase().includes(query) ||
        t.workOrder?.toLowerCase().includes(query) ||
        t.batchNumber?.toLowerCase().includes(query) ||
        t.notes?.toLowerCase().includes(query)
      );
    }

    // Type filter
    if (filterType !== "all") {
      filtered = filtered.filter(t => t.transactionType === filterType);
    }

    // User filter
    if (filterUser !== "all") {
      filtered = filtered.filter(t => t.userId === filterUser);
    }

    // Department filter
    if (filterDepartment !== "all") {
      filtered = filtered.filter(t => t.department === filterDepartment);
    }

    // Urgency filter
    if (filterUrgency !== "all") {
      filtered = filtered.filter(t => t.urgency === filterUrgency);
    }

    // Reason code filter
    if (filterReasonCode !== "all") {
      filtered = filtered.filter(t => t.reasonCode === filterReasonCode);
    }

    return filtered.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }, [transactions, searchQuery, filterType, filterUser, filterDepartment, filterUrgency, filterReasonCode, dateRange]);

  // Pagination
  const totalPages = Math.ceil(filteredTransactions.length / itemsPerPage);
  const paginatedTransactions = filteredTransactions.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Statistics
  const stats = useMemo(() => {
    const total = filteredTransactions.length;
    const checkIns = filteredTransactions.filter(t => t.transactionType === "check-in").length;
    const checkOuts = filteredTransactions.filter(t => t.transactionType === "check-out").length;
    const uniqueUsers = new Set(filteredTransactions.map(t => t.userId)).size;
    const uniqueItems = new Set(filteredTransactions.map(t => t.itemId)).size;
    const totalQuantity = filteredTransactions.reduce((sum, t) => sum + t.quantity, 0);
    
    return {
      total,
      checkIns,
      checkOuts,
      uniqueUsers,
      uniqueItems,
      totalQuantity,
    };
  }, [filteredTransactions]);

  const getTypeIcon = (type: string) => {
    return type === "check-in" ? 
      <ArrowDownToLine className="h-4 w-4 text-green-600" /> :
      <ArrowUpFromLine className="h-4 w-4 text-blue-600" />;
  };

  const getUrgencyBadge = (urgency?: string) => {
    if (!urgency) return null;
    const colors = {
      low: "bg-gray-100 text-gray-800",
      normal: "bg-blue-100 text-blue-800",
      high: "bg-orange-100 text-orange-800",
      critical: "bg-red-100 text-red-800",
    };
    return (
      <Badge className={colors[urgency as keyof typeof colors] || colors.normal}>
        {urgency}
      </Badge>
    );
  };

  const getConditionBadge = (condition?: string) => {
    if (!condition) return null;
    const colors = {
      new: "bg-green-100 text-green-800",
      good: "bg-blue-100 text-blue-800",
      fair: "bg-yellow-100 text-yellow-800",
      damaged: "bg-orange-100 text-orange-800",
      defective: "bg-red-100 text-red-800",
    };
    return (
      <Badge className={colors[condition as keyof typeof colors] || colors.good}>
        {condition}
      </Badge>
    );
  };

  // Get unique values for filters
  const uniqueDepartments = Array.from(new Set(transactions.map(t => t.department).filter(Boolean) as string[]));
  const reasonCodes = ["production", "quality-check", "repair", "inventory-adjustment", "customer-return", "damaged", "maintenance", "transfer", "other"];

  const exportToCSV = () => {
    const headers = [
      "Date/Time", "Type", "User", "Department", "Item SKU", "Product Name", 
      "Quantity", "Unit", "Reason", "Condition", "Urgency", "Location", 
      "Work Order", "Batch Number", "Notes"
    ];

    const csvData = filteredTransactions.map(t => [
      format(parseISO(t.createdAt), "yyyy-MM-dd HH:mm:ss"),
      t.transactionType,
      `${t.user.firstName} ${t.user.lastName} (${t.user.username})`,
      t.department || "",
      t.item.sku,
      t.item.productName,
      t.quantity,
      t.item.unitType,
      t.reasonCode || "",
      t.condition || "",
      t.urgency || "",
      t.location || "",
      t.workOrder || "",
      t.batchNumber || "",
      t.notes || ""
    ]);

    const csvContent = [headers, ...csvData]
      .map(row => row.map(cell => `"${cell}"`).join(","))
      .join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `activity-report-${format(new Date(), "yyyy-MM-dd")}.csv`;
    link.click();
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center">
            <BarChart3 className="h-6 w-6 mr-2 text-blue-600" />
            Comprehensive Activity Reports
          </CardTitle>
        </CardHeader>
      </Card>

      {/* Statistics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total</p>
                <p className="text-2xl font-bold text-primary">{stats.total}</p>
              </div>
              <ActivityIcon className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Check-ins</p>
                <p className="text-2xl font-bold text-green-600">{stats.checkIns}</p>
              </div>
              <ArrowDownToLine className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Check-outs</p>
                <p className="text-2xl font-bold text-blue-600">{stats.checkOuts}</p>
              </div>
              <ArrowUpFromLine className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Users</p>
                <p className="text-2xl font-bold text-purple-600">{stats.uniqueUsers}</p>
              </div>
              <User className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Items</p>
                <p className="text-2xl font-bold text-orange-600">{stats.uniqueItems}</p>
              </div>
              <Package className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Quantity</p>
                <p className="text-2xl font-bold text-teal-600">{stats.totalQuantity}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-teal-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters & Search
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search SKU, product, user, work order..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
                data-testid="input-search"
              />
            </div>

            <Select value={dateRange} onValueChange={setDateRange}>
              <SelectTrigger data-testid="select-date-range">
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Last 24 hours</SelectItem>
                <SelectItem value="7">Last 7 days</SelectItem>
                <SelectItem value="30">Last 30 days</SelectItem>
                <SelectItem value="90">Last 90 days</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterType} onValueChange={(value) => setFilterType(value as "all" | "check-in" | "check-out")}>
              <SelectTrigger data-testid="select-transaction-type">
                <SelectValue placeholder="Transaction Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="check-in">Check-ins</SelectItem>
                <SelectItem value="check-out">Check-outs</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterUser} onValueChange={setFilterUser}>
              <SelectTrigger data-testid="select-user">
                <SelectValue placeholder="User" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Users</SelectItem>
                {users.map((u) => (
                  <SelectItem key={u.id} value={u.id}>
                    {u.firstName} {u.lastName} ({u.username})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Select value={filterDepartment} onValueChange={setFilterDepartment}>
              <SelectTrigger data-testid="select-department">
                <SelectValue placeholder="Department" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Departments</SelectItem>
                {uniqueDepartments.map((dept) => (
                  <SelectItem key={dept} value={dept}>
                    {dept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterUrgency} onValueChange={setFilterUrgency}>
              <SelectTrigger data-testid="select-urgency">
                <SelectValue placeholder="Urgency" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Urgency</SelectItem>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterReasonCode} onValueChange={setFilterReasonCode}>
              <SelectTrigger data-testid="select-reason">
                <SelectValue placeholder="Reason Code" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Reasons</SelectItem>
                {reasonCodes.map((reason) => (
                  <SelectItem key={reason} value={reason}>
                    {reason.replace("-", " ")}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Button 
              onClick={exportToCSV} 
              variant="outline" 
              className="flex items-center"
              data-testid="button-export"
            >
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Activity Report ({filteredTransactions.length} records)
            </span>
            <div className="text-sm text-muted-foreground">
              Page {currentPage} of {totalPages}
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoadingTransactions ? (
            <div className="text-center py-8">Loading transactions...</div>
          ) : paginatedTransactions.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No transactions found matching your criteria.
            </div>
          ) : (
            <>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date/Time</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Item</TableHead>
                      <TableHead>Qty</TableHead>
                      <TableHead>Details</TableHead>
                      <TableHead>Location</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paginatedTransactions.map((transaction) => (
                      <TableRow key={transaction.id}>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <div>
                              <div className="font-medium">
                                {format(parseISO(transaction.createdAt), "MMM dd, yyyy")}
                              </div>
                              <div className="text-sm text-muted-foreground">
                                {format(parseISO(transaction.createdAt), "HH:mm:ss")}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {getTypeIcon(transaction.transactionType)}
                            <span className="font-medium">
                              {transaction.transactionType === "check-in" ? "Check-in" : "Check-out"}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">
                              {transaction.user.firstName} {transaction.user.lastName}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              {transaction.user.username} • {transaction.user.role}
                            </div>
                            {transaction.department && (
                              <div className="text-xs text-muted-foreground">
                                {transaction.department}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div>
                            <div className="font-medium">{transaction.item.sku}</div>
                            <div className="text-sm text-muted-foreground">
                              {transaction.item.productName}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-medium">
                            {transaction.quantity} {transaction.item.unitType}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {transaction.reasonCode && (
                              <Badge variant="outline" className="text-xs">
                                {transaction.reasonCode.replace("-", " ")}
                              </Badge>
                            )}
                            {transaction.workOrder && (
                              <div className="text-xs text-muted-foreground">
                                WO: {transaction.workOrder}
                              </div>
                            )}
                            {transaction.batchNumber && (
                              <div className="text-xs text-muted-foreground">
                                Batch: {transaction.batchNumber}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          {transaction.location && (
                            <div className="flex items-center space-x-1">
                              <MapPin className="h-3 w-3 text-muted-foreground" />
                              <span className="text-sm">{transaction.location}</span>
                            </div>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {getConditionBadge(transaction.condition)}
                            {getUrgencyBadge(transaction.urgency)}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-4">
                  <div className="text-sm text-muted-foreground">
                    Showing {(currentPage - 1) * itemsPerPage + 1} to{" "}
                    {Math.min(currentPage * itemsPerPage, filteredTransactions.length)} of{" "}
                    {filteredTransactions.length} transactions
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                      disabled={currentPage === 1}
                      data-testid="button-prev-page"
                    >
                      Previous
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                      disabled={currentPage === totalPages}
                      data-testid="button-next-page"
                    >
                      Next
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}