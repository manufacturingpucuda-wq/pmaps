import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useOrders, useFulfillOrder, useDeleteOrder, useUpdateOrder } from "@/hooks/use-orders";
import { OrderCard } from "@/components/order-card";
import { CreateOrderModal } from "@/components/create-order-modal";
import { EditOrderModal } from "@/components/edit-order-modal";
import { CustomWorkOrderModal } from "@/components/custom-work-order-modal";
import type { OrderWithItems } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { Plus, SquareCheck, Search, FileText } from "lucide-react";

export default function Orders() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showCustomWorkOrderModal, setShowCustomWorkOrderModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<OrderWithItems | null>(null);

  const { data: orders = [], isLoading } = useOrders();
  const fulfillOrder = useFulfillOrder();
  const deleteOrder = useDeleteOrder();
  const updateOrder = useUpdateOrder();
  const { toast } = useToast();

  const filteredOrders = orders
    .filter(order => {
      if (search && !order.orderNumber.toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      if (statusFilter && statusFilter !== "all" && order.status !== statusFilter) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "oldest": return new Date(a.createdAt!).getTime() - new Date(b.createdAt!).getTime();
        case "status": return a.status.localeCompare(b.status);
        default: return new Date(b.createdAt!).getTime() - new Date(a.createdAt!).getTime();
      }
    });

  const handleFulfillOrder = async (id: string) => {
    try {
      await fulfillOrder.mutateAsync(id);
      toast({
        title: "Success",
        description: "Order fulfilled successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fulfill order",
        variant: "destructive",
      });
    }
  };

  const handleEditOrder = (order: OrderWithItems) => {
    setSelectedOrder(order);
    setShowEditModal(true);
  };

  const handleDeleteOrder = async (id: string) => {
    if (confirm("Are you sure you want to delete this order? This action cannot be undone.")) {
      try {
        await deleteOrder.mutateAsync(id);
        toast({
          title: "Success",
          description: "Order deleted successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete order",
          variant: "destructive",
        });
      }
    }
  };

  const handleStatusChange = async (id: string, status: string) => {
    try {
      await updateOrder.mutateAsync({ id, data: { status: status as any } });
      toast({
        title: "Success",
        description: `Order status updated to ${status.replace('-', ' ')}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      });
    }
  };

  const handleProgressUpdate = async (id: string, progress: number) => {
    try {
      await updateOrder.mutateAsync({ id, data: { completionPercentage: progress } });
      toast({
        title: "Success",
        description: `Progress updated to ${progress}%`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update progress",
        variant: "destructive",
      });
    }
  };

  const handlePriorityChange = async (id: string, priority: string) => {
    try {
      await updateOrder.mutateAsync({ id, data: { priority: priority as any } });
      toast({
        title: "Success",
        description: `Priority updated to ${priority}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update priority",
        variant: "destructive",
      });
    }
  };

  const handleAssignChange = async (id: string, assignee: string) => {
    try {
      await updateOrder.mutateAsync({ id, data: { assignedTo: assignee } });
      toast({
        title: "Success",
        description: `Order assigned to ${assignee}`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update assignment",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <h3 className="text-lg font-semibold text-foreground">Order Management</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                onClick={() => setShowCreateModal(true)}
                className="bg-secondary hover:bg-secondary/90"
                data-testid="button-create-order"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Order
              </Button>
              <Button 
                onClick={() => setShowCustomWorkOrderModal(true)}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-custom-work-order"
              >
                <FileText className="h-4 w-4 mr-2" />
                Custom Work Order
              </Button>
              <Button variant="outline" data-testid="button-bulk-fulfill">
                <SquareCheck className="h-4 w-4 mr-2" />
                Bulk Fulfill
              </Button>
            </div>
          </div>
          
          {/* Filters */}
          <div className="mt-4 grid grid-cols-1 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search Order ID..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-order-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger data-testid="select-order-status-filter">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="in-progress">In Progress</SelectItem>
                <SelectItem value="on-hold">On Hold</SelectItem>
                <SelectItem value="fulfilled">Fulfilled</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
            
            <Input
              type="date"
              className=""
              data-testid="input-order-date-filter"
            />
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger data-testid="select-order-sort">
                <SelectValue placeholder="Newest First" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="newest">Newest First</SelectItem>
                <SelectItem value="oldest">Oldest First</SelectItem>
                <SelectItem value="status">By Status</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Orders List */}
      <div className="space-y-4">
        {isLoading ? (
          <div className="text-center py-8">
            <p className="text-muted-foreground">Loading orders...</p>
          </div>
        ) : filteredOrders.length === 0 ? (
          <Card>
            <CardContent className="text-center py-8">
              <p className="text-muted-foreground">No orders found</p>
            </CardContent>
          </Card>
        ) : (
          filteredOrders.map((order) => (
            <OrderCard 
              key={order.id} 
              order={order} 
              onFulfill={handleFulfillOrder}
              onEdit={handleEditOrder}
              onDelete={handleDeleteOrder}
              onStatusChange={handleStatusChange}
              onProgressUpdate={handleProgressUpdate}
              onPriorityChange={handlePriorityChange}
              onAssignChange={handleAssignChange}
            />
          ))
        )}
      </div>

      {/* Modals */}
      <CreateOrderModal 
        open={showCreateModal} 
        onOpenChange={setShowCreateModal} 
      />
      
      <EditOrderModal
        open={showEditModal}
        onOpenChange={setShowEditModal}
        order={selectedOrder}
      />

      <CustomWorkOrderModal
        open={showCustomWorkOrderModal}
        onOpenChange={setShowCustomWorkOrderModal}
      />
    </div>
  );
}
