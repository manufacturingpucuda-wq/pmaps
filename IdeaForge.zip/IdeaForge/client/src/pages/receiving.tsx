import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Search, PackageOpen, Check, X, AlertTriangle, Edit, Trash2, MoreHorizontal, Calendar, DollarSign, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useReceivingOrders, useCreateReceivingOrder, useUpdateReceivingOrder, useDeleteReceivingOrder, useReceiveItem } from "@/hooks/use-receiving-orders";
import { insertReceivingOrderSchema } from "@shared/schema";

// Update to use shared schema instead of local schema

// Mock data for receiving orders (will be replaced with API data)
const mockReceivingOrders = [
  {
    id: "1",
    poNumber: "PO-2025-001",
    supplierName: "Steel Supply Co.",
    supplierContact: "contact@steelsupply.com",
    expectedDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    actualDate: null,
    status: "pending",
    notes: "Steel beams for production line upgrade",
    createdAt: new Date(),
    items: [
      {
        id: "1",
        itemName: "Steel Beam 20ft",
        expectedQuantity: 50,
        receivedQuantity: 0,
        condition: "good",
      },
      {
        id: "2",
        itemName: "Steel Plate 4x8",
        expectedQuantity: 100,
        receivedQuantity: 0,
        condition: "good",
      },
    ],
  },
  {
    id: "2",
    poNumber: "PO-2025-002",
    supplierName: "Parts Warehouse",
    supplierContact: "orders@partswarehouse.com",
    expectedDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    actualDate: new Date(),
    status: "complete",
    notes: "Monthly parts resupply",
    createdAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    items: [
      {
        id: "3",
        itemName: "Hydraulic Pump",
        expectedQuantity: 5,
        receivedQuantity: 5,
        condition: "good",
      },
    ],
  },
];

// Use shared schema for form validation
type ReceivingOrderFormData = z.infer<typeof insertReceivingOrderSchema>;

const receiveItemSchema = z.object({
  receivedQuantity: z.number().min(0, "Quantity must be positive"),
  condition: z.enum(["good", "damaged", "defective"]),
  lotNumber: z.string().optional(),
  expirationDate: z.string().optional(),
  inspectedBy: z.string().optional(),
  inspectionDate: z.string().optional(),
  warehouseLocation: z.string().optional(),
  unitCost: z.number().optional(),
  notes: z.string().optional(),
});

type ReceiveItemFormData = z.infer<typeof receiveItemSchema>;

export default function Receiving() {
  const { data: receivingOrders = [], isLoading } = useReceivingOrders();
  const createReceivingOrder = useCreateReceivingOrder();
  const updateReceivingOrder = useUpdateReceivingOrder();
  const deleteReceivingOrder = useDeleteReceivingOrder();
  const receiveItem = useReceiveItem();
  
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showReceiveModal, setShowReceiveModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<any>(null);
  const [selectedItem, setSelectedItem] = useState<any>(null);
  const [editingOrder, setEditingOrder] = useState<any>(null);
  const { toast } = useToast();

  const form = useForm<ReceivingOrderFormData>({
    resolver: zodResolver(insertReceivingOrderSchema),
    defaultValues: {
      poNumber: "",
      supplierName: "",
      supplierContact: "",
      supplierAddress: "",
      supplierPhone: "",
      expectedDate: "",
      invoiceNumber: "",
      freight: 0,
      tax: 0,
      carrier: "",
      trackingNumber: "",
      priority: "normal",
      notes: "",
    },
  });

  const receiveForm = useForm<ReceiveItemFormData>({
    resolver: zodResolver(receiveItemSchema),
    defaultValues: {
      receivedQuantity: 0,
      condition: "good",
      lotNumber: "",
      expirationDate: "",
      inspectedBy: "",
      inspectionDate: "",
      warehouseLocation: "",
      unitCost: 0,
      notes: "",
    },
  });

  const filteredOrders = receivingOrders.filter(order => {
    if (search && !order.poNumber.toLowerCase().includes(search.toLowerCase()) && 
        !order.supplierName.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (statusFilter && statusFilter !== "all" && order.status !== statusFilter) {
      return false;
    }
    return true;
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="space-y-4">
          <div className="h-8 bg-gray-200 dark:bg-gray-700 animate-pulse rounded w-1/4"></div>
          <div className="h-4 bg-gray-200 dark:bg-gray-700 animate-pulse rounded w-1/2"></div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="bg-gray-200 dark:bg-gray-700 animate-pulse rounded-lg h-64"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "bg-yellow-600 text-white",
      partial: "bg-blue-600 text-white",
      complete: "bg-green-600 text-white",
      cancelled: "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[status as keyof typeof variants] || "bg-gray-600 text-white"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const getConditionBadge = (condition: string) => {
    const variants = {
      good: "bg-green-600 text-white",
      damaged: "bg-yellow-600 text-white",
      defective: "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[condition as keyof typeof variants] || "bg-gray-600 text-white"}>
        {condition.charAt(0).toUpperCase() + condition.slice(1)}
      </Badge>
    );
  };

  const handleCreateReceivingOrder = async (data: ReceivingOrderFormData) => {
    try {
      await createReceivingOrder.mutateAsync(data);
      toast({
        title: "Success",
        description: "Receiving order created successfully",
      });
      setShowCreateModal(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create receiving order",
        variant: "destructive",
      });
    }
  };

  const handleReceiveItem = (order: any, item: any) => {
    setSelectedOrder(order);
    setSelectedItem(item);
    receiveForm.reset({
      receivedQuantity: item.expectedQuantity - item.receivedQuantity,
      condition: "good",
      lotNumber: "",
      notes: "",
    });
    setShowReceiveModal(true);
  };

  const handleConfirmReceive = async (data: ReceiveItemFormData) => {
    try {
      if (!selectedOrder?.id || !selectedItem?.id) return;
      await receiveItem.mutateAsync({ 
        orderId: selectedOrder.id, 
        itemData: {
          itemId: selectedItem.id,
          receivedQuantity: data.receivedQuantity,
          condition: data.condition,
          lotNumber: data.lotNumber,
          notes: data.notes
        }
      });
      toast({
        title: "Success",
        description: `Received ${data.receivedQuantity} units of ${selectedItem.itemName}`,
      });
      setShowReceiveModal(false);
      setSelectedOrder(null);
      setSelectedItem(null);
      receiveForm.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to receive item",
        variant: "destructive",
      });
    }
  };

  const handleEditOrder = (order: any) => {
    setEditingOrder(order);
    form.reset({
      poNumber: order.poNumber,
      supplierName: order.supplierName,
      supplierContact: order.supplierContact,
      supplierAddress: order.supplierAddress || "",
      supplierPhone: order.supplierPhone || "",
      expectedDate: order.expectedDate ? order.expectedDate.toISOString().split('T')[0] : "",
      invoiceNumber: order.invoiceNumber || "",
      freight: order.freight || 0,
      tax: order.tax || 0,
      carrier: order.carrier || "",
      trackingNumber: order.trackingNumber || "",
      priority: order.priority || "normal",
      notes: order.notes || "",
    });
    setShowEditModal(true);
  };

  const handleUpdateOrder = async (data: ReceivingOrderFormData) => {
    try {
      if (!editingOrder?.id) return;
      await updateReceivingOrder.mutateAsync({ id: editingOrder.id, data });
      toast({
        title: "Success",
        description: "Receiving order updated successfully",
      });
      setShowEditModal(false);
      setEditingOrder(null);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update receiving order",
        variant: "destructive",
      });
    }
  };

  const handleDeleteOrder = async (orderId: string, poNumber: string) => {
    if (confirm(`Are you sure you want to delete receiving order ${poNumber}? This action cannot be undone.`)) {
      try {
        await deleteReceivingOrder.mutateAsync(orderId);
        toast({
          title: "Success",
          description: `Receiving order ${poNumber} deleted successfully`,
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete receiving order",
          variant: "destructive",
        });
      }
    }
  };

  const ReceivingOrderForm = () => (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleCreateReceivingOrder)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="poNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>PO Number</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="PO-2025-003" data-testid="input-po-number" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="supplierName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Supplier Name</FormLabel>
                <FormControl>
                  <Input {...field} data-testid="input-supplier-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="supplierContact"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Supplier Contact</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="contact@supplier.com" data-testid="input-supplier-contact" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="supplierPhone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Supplier Phone</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="(555) 123-4567" data-testid="input-supplier-phone" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="supplierAddress"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Supplier Address</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Complete supplier address..." data-testid="textarea-supplier-address" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="expectedDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expected Delivery Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} data-testid="input-expected-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="low">Low</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="high">High</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="invoiceNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Invoice Number</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="INV-2025-001" data-testid="input-invoice-number" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="carrier"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Carrier</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="FedEx, UPS, etc." data-testid="input-carrier" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="trackingNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tracking Number</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="1Z999AA1234567890" data-testid="input-tracking-number" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="freight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Freight Cost</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    placeholder="0.00" 
                    data-testid="input-freight" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="tax"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Tax Amount</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    placeholder="0.00" 
                    data-testid="input-tax" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Additional notes about this order..." data-testid="textarea-notes" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowCreateModal(false)}
            data-testid="button-cancel-receiving"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-primary hover:bg-primary/90"
            data-testid="button-save-receiving"
          >
            {editingOrder ? "Update Receiving Order" : "Create Receiving Order"}
          </Button>
        </div>
      </form>
    </Form>
  );

  const ReceiveItemForm = () => (
    <Form {...receiveForm}>
      <form onSubmit={receiveForm.handleSubmit(handleConfirmReceive)} className="space-y-4">
        <div className="bg-muted p-4 rounded-lg">
          <h4 className="font-medium mb-2">Item Details</h4>
          <div className="text-sm space-y-1">
            <div>Item: {selectedItem?.itemName}</div>
            <div>Expected: {selectedItem?.expectedQuantity}</div>
            <div>Already Received: {selectedItem?.receivedQuantity}</div>
            <div>Remaining: {selectedItem?.expectedQuantity - selectedItem?.receivedQuantity}</div>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={receiveForm.control}
            name="receivedQuantity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Quantity Received</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    {...field} 
                    onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                    data-testid="input-received-quantity" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={receiveForm.control}
            name="condition"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Condition</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-condition">
                      <SelectValue placeholder="Select condition" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="damaged">Damaged</SelectItem>
                    <SelectItem value="defective">Defective</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={receiveForm.control}
            name="lotNumber"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Lot Number</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="LOT-2025-001" data-testid="input-lot-number" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={receiveForm.control}
            name="expirationDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Expiration Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} data-testid="input-expiration-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={receiveForm.control}
            name="inspectedBy"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Inspected By</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="Inspector name or ID" data-testid="input-inspected-by" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={receiveForm.control}
            name="inspectionDate"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Inspection Date</FormLabel>
                <FormControl>
                  <Input type="date" {...field} data-testid="input-inspection-date" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={receiveForm.control}
            name="warehouseLocation"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Warehouse Location</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="A1-B3, Section 2" data-testid="input-warehouse-location" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={receiveForm.control}
            name="unitCost"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Unit Cost</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    placeholder="0.00" 
                    data-testid="input-unit-cost" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={receiveForm.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Any notes about the received items..." data-testid="textarea-receive-notes" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowReceiveModal(false)}
            data-testid="button-cancel-receive"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-primary hover:bg-primary/90"
            data-testid="button-confirm-receive"
          >
            Confirm Receipt
          </Button>
        </div>
      </form>
    </Form>
  );

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold flex items-center">
              <PackageOpen className="h-6 w-6 mr-2" />
              Receiving
            </CardTitle>
            <Button 
              onClick={() => setShowCreateModal(true)}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-create-receiving"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Receiving Order
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex space-x-4 mb-6">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search receiving orders..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-receiving-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[200px]" data-testid="select-status-filter">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="partial">Partial</SelectItem>
                <SelectItem value="complete">Complete</SelectItem>
                <SelectItem value="cancelled">Cancelled</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Receiving Orders */}
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <Card key={order.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{order.poNumber}</h3>
                      <p className="text-muted-foreground">{order.supplierName}</p>
                      <p className="text-sm text-muted-foreground">
                        Expected: {order.expectedDate?.toLocaleDateString()}
                        {order.actualDate && (
                          <span> | Received: {order.actualDate.toLocaleDateString()}</span>
                        )}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className="text-right">
                        {getStatusBadge(order.status)}
                        {order.status === "pending" && new Date() > (order.expectedDate || new Date()) && (
                          <div className="flex items-center text-red-600 text-sm mt-1">
                            <AlertTriangle className="h-4 w-4 mr-1" />
                            Overdue
                          </div>
                        )}
                      </div>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditOrder(order)}
                          data-testid={`button-edit-order-${order.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteOrder(order.id, order.poNumber)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          data-testid={`button-delete-order-${order.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  {order.notes && (
                    <p className="text-sm text-muted-foreground mb-4">{order.notes}</p>
                  )}

                  {/* Items Table */}
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Item</TableHead>
                          <TableHead>Expected</TableHead>
                          <TableHead>Received</TableHead>
                          <TableHead>Condition</TableHead>
                          <TableHead>Progress</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {order.items.map((item: any) => {
                          const progress = (item.receivedQuantity / item.expectedQuantity) * 100;
                          const isComplete = item.receivedQuantity >= item.expectedQuantity;
                          
                          return (
                            <TableRow key={item.id}>
                              <TableCell className="font-medium">{item.itemName}</TableCell>
                              <TableCell>{item.expectedQuantity}</TableCell>
                              <TableCell>{item.receivedQuantity}</TableCell>
                              <TableCell>{getConditionBadge(item.condition)}</TableCell>
                              <TableCell>
                                <div className="flex items-center space-x-2">
                                  <div className="w-24 bg-muted rounded-full h-2">
                                    <div 
                                      className={`h-2 rounded-full ${isComplete ? 'bg-green-600' : 'bg-blue-600'}`}
                                      style={{ width: `${Math.min(progress, 100)}%` }}
                                    />
                                  </div>
                                  <span className="text-sm">{Math.round(progress)}%</span>
                                </div>
                              </TableCell>
                              <TableCell className="text-right">
                                {!isComplete && order.status !== "cancelled" && (
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleReceiveItem(order, item)}
                                    data-testid={`button-receive-${item.id}`}
                                  >
                                    <PackageOpen className="h-4 w-4 mr-2" />
                                    Receive
                                  </Button>
                                )}
                                {isComplete && (
                                  <div className="flex items-center text-green-600">
                                    <Check className="h-4 w-4 mr-1" />
                                    Complete
                                  </div>
                                )}
                              </TableCell>
                            </TableRow>
                          );
                        })}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Create Receiving Order Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-3xl" data-testid="modal-create-receiving">
          <DialogHeader>
            <DialogTitle>Create New Receiving Order</DialogTitle>
          </DialogHeader>
          <ReceivingOrderForm />
        </DialogContent>
      </Dialog>

      {/* Edit Receiving Order Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-3xl" data-testid="modal-edit-receiving">
          <DialogHeader>
            <DialogTitle>Edit Receiving Order</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateOrder)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="poNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>PO Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="PO-2025-003" data-testid="input-po-number-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="supplierName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Supplier Name</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-supplier-name-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="supplierContact"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Supplier Contact</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="contact@supplier.com" data-testid="input-supplier-contact-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="supplierPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Supplier Phone</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="(555) 123-4567" data-testid="input-supplier-phone-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="supplierAddress"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Supplier Address</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Complete supplier address..." data-testid="textarea-supplier-address-edit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="expectedDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Expected Delivery Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-expected-date-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-priority-edit">
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="normal">Normal</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="invoiceNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Invoice Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="INV-2025-001" data-testid="input-invoice-number-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="carrier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Carrier</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="FedEx, UPS, etc." data-testid="input-carrier-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="trackingNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tracking Number</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="1Z999AA1234567890" data-testid="input-tracking-number-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="freight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Freight Cost</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          placeholder="0.00" 
                          data-testid="input-freight-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="tax"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Tax Amount</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          placeholder="0.00" 
                          data-testid="input-tax-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Additional notes about this order..." data-testid="textarea-notes-edit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowEditModal(false)}
                  data-testid="button-cancel-edit-receiving"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-update-receiving"
                >
                  Update Receiving Order
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Receive Item Modal */}
      <Dialog open={showReceiveModal} onOpenChange={setShowReceiveModal}>
        <DialogContent className="max-w-xl" data-testid="modal-receive-item">
          <DialogHeader>
            <DialogTitle>Receive Item</DialogTitle>
          </DialogHeader>
          <ReceiveItemForm />
        </DialogContent>
      </Dialog>
    </div>
  );
}