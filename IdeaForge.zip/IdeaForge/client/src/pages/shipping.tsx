import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Plus, Search, Truck, Package, FileText, Download, Eye, Edit, Trash2, ClipboardList } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PalletBoxForm } from "@/components/pallet-box-form";
import { PullListForm } from "@/components/pull-list-form";
import { generateShipmentPDF } from "@/lib/pdf-generator";

export default function Shipping() {
  const [shipments, setShipments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showCreatePullListModal, setShowCreatePullListModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showBOLModal, setShowBOLModal] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<any>(null);
  const [editingShipment, setEditingShipment] = useState<any>(null);
  const [formType, setFormType] = useState<"pallet" | "pulllist">("pallet");
  const { toast } = useToast();

  // Load shipments from API
  useEffect(() => {
    const loadShipments = async () => {
      try {
        const response = await fetch("/api/shipments", {
          credentials: "include",
        });
        
        if (response.ok) {
          const data = await response.json();
          setShipments(data);
        } else {
          console.error("Failed to load shipments");
          setShipments([]);
        }
      } catch (error) {
        console.error("Error loading shipments:", error);
        setShipments([]);
      } finally {
        setLoading(false);
      }
    };

    loadShipments();
  }, []);

  const filteredShipments = shipments.filter(shipment => {
    if (search && !shipment.shipmentNumber.toLowerCase().includes(search.toLowerCase()) && 
        !shipment.customerName.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (statusFilter && statusFilter !== "all" && shipment.status !== statusFilter) {
      return false;
    }
    return true;
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "bg-yellow-600 text-white",
      picked: "bg-blue-600 text-white",
      packed: "bg-purple-600 text-white",
      shipped: "bg-green-600 text-white",
      delivered: "bg-emerald-600 text-white",
      returned: "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[status as keyof typeof variants] || "bg-gray-600 text-white"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const handleCreateShipment = async (data: any) => {
    try {
      const response = await fetch("/api/shipments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ ...data, formType: "pallet" }),
      });

      if (!response.ok) {
        throw new Error("Failed to create shipment");
      }

      const newShipment = await response.json();
      
      toast({
        title: "Success",
        description: "Pallet/Box shipment created successfully",
      });
      
      // Add the new shipment to the current list
      setShipments(prev => [newShipment, ...prev]);
    } catch (error) {
      console.error("Error creating shipment:", error);
      toast({
        title: "Error",
        description: "Failed to create shipment",
        variant: "destructive",
      });
    }
  };

  const handleCreatePullList = async (data: any) => {
    try {
      const response = await fetch("/api/shipments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({ ...data, formType: "pulllist" }),
      });

      if (!response.ok) {
        throw new Error("Failed to create pull list");
      }

      const newShipment = await response.json();
      
      toast({
        title: "Success",
        description: "Pull list created successfully",
      });
      
      // Add the new shipment to the current list
      setShipments(prev => [newShipment, ...prev]);
    } catch (error) {
      console.error("Error creating pull list:", error);
      toast({
        title: "Error",
        description: "Failed to create pull list",
        variant: "destructive",
      });
    }
  };

  const handleEditShipment = (shipment: any) => {
    setEditingShipment(shipment);
    setShowEditModal(true);
  };

  const handleUpdateShipment = async (data: any) => {
    try {
      if (!editingShipment?.id) {
        throw new Error("No shipment selected for editing");
      }

      const response = await fetch(`/api/shipments/${editingShipment.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Failed to update shipment");
      }

      const updatedShipment = await response.json();
      
      toast({
        title: "Success",
        description: "Shipment updated successfully",
      });
      setEditingShipment(null);
      
      // Update the shipment in the current list
      setShipments(prev => prev.map(s => s.id === editingShipment.id ? updatedShipment : s));
    } catch (error) {
      console.error("Error updating shipment:", error);
      toast({
        title: "Error",
        description: "Failed to update shipment",
        variant: "destructive",
      });
    }
  };

  const handleDeleteShipment = async (shipmentId: string, shipmentNumber: string) => {
    if (confirm(`Are you sure you want to delete shipment ${shipmentNumber}? This action cannot be undone.`)) {
      try {
        const response = await fetch(`/api/shipments/${shipmentId}`, {
          method: 'DELETE',
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error('Failed to delete shipment');
        }

        toast({
          title: "Success",
          description: `Shipment ${shipmentNumber} deleted successfully`,
        });
        
        // Remove the deleted shipment from the current list
        setShipments(prev => prev.filter(s => s.id !== shipmentId));
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete shipment",
          variant: "destructive",
        });
      }
    }
  };

  const handleGenerateBOL = (shipment: any) => {
    setSelectedShipment(shipment);
    setShowBOLModal(true);
  };

  const generateBOLDocument = (shipment: any) => {
    try {
      generateShipmentPDF(shipment);
      toast({
        title: "PDF Generated",
        description: `Document generated for ${shipment?.shipmentNumber}`,
      });
      setShowBOLModal(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <div>
              <CardTitle className="text-2xl font-bold text-primary">Shipping Management</CardTitle>
              <p className="text-muted-foreground">Manage pallet and box shipments</p>
            </div>
            <div className="flex gap-2">
              <Button 
                onClick={() => setShowCreateModal(true)}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-create-shipment"
              >
                <Package className="h-4 w-4 mr-2" />
                Pallet/Box Form
              </Button>
              <Button 
                onClick={() => setShowCreatePullListModal(true)}
                variant="outline"
                className="border-primary text-primary hover:bg-primary hover:text-white"
                data-testid="button-create-pulllist"
              >
                <ClipboardList className="h-4 w-4 mr-2" />
                Pull List Form
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row gap-4 mb-6">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search shipment number or customer..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-search-shipments"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48" data-testid="select-status-filter">
                <SelectValue placeholder="Filter by Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="picked">Picked</SelectItem>
                <SelectItem value="packed">Packed</SelectItem>
                <SelectItem value="shipped">Shipped</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="returned">Returned</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Shipments Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Shipment #</TableHead>
                  <TableHead>Order/Project</TableHead>
                  <TableHead>Customer/Company</TableHead>
                  <TableHead>Form Type</TableHead>
                  <TableHead>Details</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Completed By</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      Loading shipments...
                    </TableCell>
                  </TableRow>
                ) : filteredShipments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No shipments found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredShipments.map((shipment) => (
                    <TableRow key={shipment.id}>
                      <TableCell className="font-mono">{shipment.shipmentNumber}</TableCell>
                      <TableCell className="font-mono">
                        {shipment.formType === "pulllist" ? shipment.project : shipment.salesOrderNumber}
                      </TableCell>
                      <TableCell>
                        <div className="font-medium">
                          {shipment.formType === "pulllist" ? shipment.company : shipment.customerName}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant={shipment.formType === "pulllist" ? "secondary" : "default"}>
                          {shipment.formType === "pulllist" ? "Pull List" : "Pallet/Box"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {shipment.formType === "pulllist" 
                          ? `${shipment.items?.length || 0} items` 
                          : `${shipment.totalQty} qty, ${shipment.totalWeight} lbs`
                        }
                      </TableCell>
                      <TableCell>{getStatusBadge(shipment.status)}</TableCell>
                      <TableCell>
                        {shipment.formType === "pulllist" ? shipment.pulledBy : shipment.completedBy}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => generateShipmentPDF(shipment)}
                            data-testid={`button-preview-${shipment.id}`}
                            title="Preview PDF"
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleGenerateBOL(shipment)}
                            data-testid={`button-bol-${shipment.id}`}
                            title="Generate BOL"
                          >
                            <FileText className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleEditShipment(shipment)}
                            data-testid={`button-edit-shipment-${shipment.id}`}
                            title="Edit Shipment"
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => handleDeleteShipment(shipment.id, shipment.shipmentNumber)}
                            className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            data-testid={`button-delete-shipment-${shipment.id}`}
                            title="Delete Shipment"
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create Pallet/Box Shipment Form */}
      <PalletBoxForm
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        onSubmit={handleCreateShipment}
        title="Create Pallet/Box Shipment"
      />

      {/* Create Pull List Form */}
      <PullListForm
        isOpen={showCreatePullListModal}
        onClose={() => setShowCreatePullListModal(false)}
        onSubmit={handleCreatePullList}
        title="Create Pull List"
      />

      {/* Edit Forms (Dynamic based on form type) */}
      {editingShipment?.formType === "pulllist" ? (
        <PullListForm
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          onSubmit={handleUpdateShipment}
          editingData={editingShipment}
          title="Edit Pull List"
        />
      ) : (
        <PalletBoxForm
          isOpen={showEditModal}
          onClose={() => setShowEditModal(false)}
          onSubmit={handleUpdateShipment}
          editingData={editingShipment}
          title="Edit Pallet/Box Shipment"
        />
      )}

      {/* BOL Generation Modal */}
      <Dialog open={showBOLModal} onOpenChange={(open) => setShowBOLModal(open)}>
        <DialogContent className="max-w-2xl" data-testid="modal-bol">
          <DialogHeader>
            <DialogTitle className="text-lg leading-none tracking-tight font-medium">Generate Bill of Lading</DialogTitle>
            <DialogDescription>
              Generate a professional bill of lading document for this shipment.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Generating shipment: {selectedShipment?.shipmentNumber}
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Shipment Details:</h4>
              <div className="text-sm space-y-1">
                <div>Customer: {selectedShipment?.customerName}</div>
                <div>Sales Order: {selectedShipment?.salesOrderNumber}</div>
                <div>Total Qty: {selectedShipment?.totalQty}</div>
                <div>Total Weight: {selectedShipment?.totalWeight} lbs</div>
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => setShowBOLModal(false)}
                data-testid="button-cancel-bol"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  generateBOLDocument(selectedShipment);
                  setShowBOLModal(false);
                }}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-generate-bol"
              >
                <Download className="h-4 w-4 mr-2" />
                Generate BOL
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}