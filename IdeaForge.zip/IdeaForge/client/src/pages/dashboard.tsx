import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { DashboardWidgets } from "@/components/widget-system/dashboard-widgets";
import { ActivityPanel } from "@/components/activity-panel";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useState, useRef, useEffect } from "react";
import { useLocation } from "wouter";
import { 
  Search,
  Calendar
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Auto-focus search input for barcode scanning
  useEffect(() => {
    if (searchInputRef.current) {
      searchInputRef.current.focus();
    }
  }, []);

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    
    // Auto-search when barcode is scanned (detect rapid input completion)
    // Look for barcode patterns (6+ alphanumeric characters)
    const trimmedValue = value.trim();
    if (trimmedValue.length >= 6 && /^[A-Za-z0-9]+$/.test(trimmedValue)) {
      setTimeout(() => {
        handleSearch(trimmedValue);
      }, 100); // Small delay to ensure scanner has finished
    }
  };

  const handleSearchKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      const value = (e.target as HTMLInputElement).value.trim();
      if (value) {
        handleSearch(value);
      }
    }
  };

  const handleSearch = (query: string) => {
    const searchTerm = query.toLowerCase();
    
    // Check if it looks like an item SKU/barcode (redirect to inventory)
    if (/^[A-Za-z0-9-_]+$/.test(searchTerm)) {
      toast({
        title: "Searching Inventory",
        description: `Looking for item: ${query}`,
      });
      setLocation(`/inventory?search=${encodeURIComponent(query)}`);
      return;
    }

    // Check if it looks like an order number (redirect to orders)
    if (searchTerm.includes('order') || searchTerm.includes('ord') || /^wo-\d+/i.test(searchTerm)) {
      toast({
        title: "Searching Orders",
        description: `Looking for order: ${query}`,
      });
      setLocation(`/orders?search=${encodeURIComponent(query)}`);
      return;
    }

    // Default: search in documents
    toast({
      title: "Searching Documents",
      description: `Searching for: ${query}`,
    });
    setLocation(`/documents?search=${encodeURIComponent(query)}`);
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <header className="bg-gradient-to-r from-blue-600 to-purple-600 text-white border-b border-border px-6 py-6 -mx-6 -mt-6 mb-6 rounded-lg">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div>
              <h1 className="text-2xl font-bold">Welcome back, {user?.name || 'Admin'}!</h1>
              <p className="text-blue-100 text-sm">Here's what's happening with your warehouse today</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Input
                ref={searchInputRef}
                type="text"
                value={searchQuery}
                onChange={handleSearchInput}
                onKeyPress={handleSearchKeyPress}
                placeholder="Scan barcode or search anything..."
                className="w-80 pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
                data-testid="input-global-search"
                autoComplete="off"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/70" />
            </div>
            <div className="flex items-center space-x-2 bg-white/10 rounded-lg px-3 py-2">
              <Calendar className="h-4 w-4" />
              <span className="text-sm">{new Date().toLocaleDateString()}</span>
            </div>
          </div>
        </div>
      </header>

      {/* Customizable Widget System */}
      <DashboardWidgets />
      
      {/* Activity Panel */}
      <div className="mt-8">
        <ActivityPanel />
      </div>
    </div>
  );
}
