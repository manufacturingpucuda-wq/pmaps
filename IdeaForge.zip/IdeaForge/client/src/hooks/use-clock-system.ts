import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ClockEmployee, InsertClockEmployee, ClockLog, InsertClockLog } from "@shared/schema";

export function useClockEmployees() {
  return useQuery({
    queryKey: ["/api/clock/employees"],
  });
}

export function useClockLogs(employeeId?: string) {
  return useQuery({
    queryKey: ["/api/clock/logs", employeeId],
  });
}

export function useAddClockEmployee() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: InsertClockEmployee) => {
      return await apiRequest("POST", "/api/clock/employees", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clock/employees"] });
    },
  });
}

export function useUpdateClockEmployee() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<ClockEmployee> }) => {
      return await apiRequest("PATCH", `/api/clock/employees/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clock/employees"] });
    },
  });
}

export function useDeleteClockEmployee() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/clock/employees/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clock/employees"] });
    },
  });
}

export function useClockAction() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (employeeId: string) => {
      return await apiRequest("POST", "/api/clock/action", { employeeId });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clock/employees"] });
      queryClient.invalidateQueries({ queryKey: ["/api/clock/logs"] });
    },
  });
}

export function useEmployeeTimeCard() {
  return useMutation({
    mutationFn: async ({ employeeId, startDate, endDate }: { 
      employeeId: string; 
      startDate: string; 
      endDate: string; 
    }) => {
      return await apiRequest("GET", `/api/clock/timecard/${employeeId}?startDate=${startDate}&endDate=${endDate}`);
    },
  });
}

export function useExportAllHours() {
  return useMutation({
    mutationFn: async ({ startDate, endDate }: { startDate: string; endDate: string }) => {
      return await apiRequest("GET", `/api/clock/export?startDate=${startDate}&endDate=${endDate}`);
    },
  });
}