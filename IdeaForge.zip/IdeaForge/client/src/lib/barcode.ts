declare global {
  interface Window {
    JsBarcode: any;
  }
}

export function generateBarcode(element: SVGElement | HTMLCanvasElement, text: string, options?: any) {
  return new Promise((resolve, reject) => {
    // Validate input text
    if (!text || text.trim() === '') {
      reject(new Error('Barcode text cannot be empty'));
      return;
    }
    
    // Dynamically load JsBarcode if not already loaded
    if (typeof window !== 'undefined' && !window.JsBarcode) {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js';
      script.onload = () => {
        try {
          window.JsBarcode(element, text, {
            format: "CODE128",
            width: 2,
            height: 100,
            displayValue: true,
            fontSize: 14,
            ...options
          });
          resolve(element);
        } catch (error) {
          reject(error);
        }
      };
      script.onerror = reject;
      document.head.appendChild(script);
    } else if (window.JsBarcode) {
      try {
        window.JsBarcode(element, text, {
          format: "CODE128",
          width: 2,
          height: 100,
          displayValue: true,
          fontSize: 14,
          ...options
        });
        resolve(element);
      } catch (error) {
        reject(error);
      }
    } else {
      reject(new Error('JsBarcode library not available'));
    }
  });
}
