import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Minus, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const palletBoxItemSchema = z.object({
  qty: z.number().min(0, "Quantity must be positive"),
  length: z.number().min(0, "Length must be positive"),
  width: z.number().min(0, "Width must be positive"),
  height: z.number().min(0, "Height must be positive"),
  weight: z.number().min(0, "Weight must be positive"),
});

const palletBoxFormSchema = z.object({
  salesOrderNumber: z.string().min(1, "Sales order number is required"),
  customerName: z.string().min(1, "Customer name is required"),
  palletBoxItems: z.array(palletBoxItemSchema).min(1, "At least one pallet/box item is required"),
  totalQty: z.number().min(0, "Total quantity must be positive"),
  totalWeight: z.number().min(0, "Total weight must be positive"),
  notes: z.string().optional(),
  completedBy: z.string().min(1, "Completed by is required"),
  completedDate: z.string().min(1, "Completed date is required"),
  supervisor: z.string().min(1, "Supervisor is required"),
}).refine((data) => {
  // Ensure at least one item has valid data
  return data.palletBoxItems.some(item => item.qty > 0 || item.length > 0 || item.width > 0 || item.height > 0 || item.weight > 0);
}, {
  message: "At least one pallet/box item must have valid measurements",
  path: ["palletBoxItems"]
});

type PalletBoxFormData = z.infer<typeof palletBoxFormSchema>;

interface PalletBoxFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: PalletBoxFormData) => Promise<void>;
  editingData?: any;
  title?: string;
}

export function PalletBoxForm({ isOpen, onClose, onSubmit, editingData, title = "Create Pallet/Box Shipment" }: PalletBoxFormProps) {
  const { toast } = useToast();
  
  const form = useForm<PalletBoxFormData>({
    resolver: zodResolver(palletBoxFormSchema),
    defaultValues: {
      salesOrderNumber: editingData?.salesOrderNumber || "",
      customerName: editingData?.customerName || "",
      palletBoxItems: editingData?.palletBoxItems || [
        { qty: 0, length: 0, width: 0, height: 0, weight: 0 }
      ],
      totalQty: editingData?.totalQty || 0,
      totalWeight: editingData?.totalWeight || 0,
      notes: editingData?.notes || "",
      completedBy: editingData?.completedBy || "",
      completedDate: editingData?.completedDate || new Date().toISOString().split('T')[0],
      supervisor: editingData?.supervisor || "",
    },
  });

  const addPalletBoxItem = () => {
    const currentItems = form.getValues('palletBoxItems');
    form.setValue('palletBoxItems', [...currentItems, { qty: 0, length: 0, width: 0, height: 0, weight: 0 }]);
  };

  const removePalletBoxItem = (index: number) => {
    const currentItems = form.getValues('palletBoxItems');
    if (currentItems.length > 1) {
      const newItems = currentItems.filter((_, i) => i !== index);
      form.setValue('palletBoxItems', newItems);
    }
  };

  const calculateTotals = () => {
    const items = form.getValues('palletBoxItems');
    const totalQty = items.reduce((sum, item) => sum + (item.qty || 0), 0);
    const totalWeight = items.reduce((sum, item) => sum + (item.weight || 0), 0);
    form.setValue('totalQty', totalQty);
    form.setValue('totalWeight', totalWeight);
  };

  const handleSubmit = async (data: PalletBoxFormData) => {
    try {
      await onSubmit(data);
      form.reset();
      onClose();
    } catch (error) {
      console.error('Form submission error:', error);
      // Don't close modal on error so user can see what went wrong
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">
            PUCUDA MFG - {title}
          </DialogTitle>
          <DialogDescription className="text-center text-muted-foreground">
            Create and manage pallet/box shipment details with item specifications and totals.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            {/* Header Information */}
            <div className="grid grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg">
              <FormField
                control={form.control}
                name="salesOrderNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">SALES ORDER #</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="SO-2025-001" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">CUSTOMER NAME</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="Customer Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Pallet/Box Items Table */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Pallet/Box Items</h3>
                <Button type="button" onClick={addPalletBoxItem} variant="outline" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Row
                </Button>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-100">
                      <TableHead className="text-center font-bold">PALLET/BOX QTY</TableHead>
                      <TableHead className="text-center font-bold">LENGTH</TableHead>
                      <TableHead className="text-center font-bold">WIDTH</TableHead>
                      <TableHead className="text-center font-bold">HEIGHT</TableHead>
                      <TableHead className="text-center font-bold">PALLET WEIGHT</TableHead>
                      <TableHead className="text-center font-bold">ACTION</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {form.watch('palletBoxItems').map((_, index) => (
                      <TableRow key={index} className="border-b">
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`palletBoxItems.${index}.qty`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => {
                                  field.onChange(parseFloat(e.target.value) || 0);
                                  setTimeout(calculateTotals, 0);
                                }}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`palletBoxItems.${index}.length`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                step="0.1"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`palletBoxItems.${index}.width`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                step="0.1"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`palletBoxItems.${index}.height`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                step="0.1"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`palletBoxItems.${index}.weight`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                step="0.1"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => {
                                  field.onChange(parseFloat(e.target.value) || 0);
                                  setTimeout(calculateTotals, 0);
                                }}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          {form.watch('palletBoxItems').length > 1 && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removePalletBoxItem(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* Totals */}
            <div className="grid grid-cols-2 gap-6 p-4 bg-yellow-50 rounded-lg border-2 border-yellow-200">
              <FormField
                control={form.control}
                name="totalQty"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-bold">TOTAL QTY</FormLabel>
                    <FormControl>
                      <Input {...field} readOnly className="bg-white font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="totalWeight"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-bold">TOTAL WEIGHT</FormLabel>
                    <FormControl>
                      <Input {...field} readOnly className="bg-white font-bold text-center" />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-semibold">NOTES:</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      className="border-2 border-gray-300" 
                      rows={3}
                      placeholder="Special instructions, handling notes, etc..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Signature Fields */}
            <div className="grid grid-cols-3 gap-6 p-4 bg-blue-50 rounded-lg border-2 border-blue-200">
              <FormField
                control={form.control}
                name="completedBy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Completed by:</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="Employee Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="completedDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Date:</FormLabel>
                    <FormControl>
                      <Input {...field} type="date" className="border-2 border-gray-300" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="supervisor"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Supervisor:</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="Supervisor Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Form Validation Errors */}
            {Object.keys(form.formState.errors).length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 mb-2">Please fix the following errors:</h4>
                <ul className="text-sm text-red-700 list-disc list-inside space-y-1">
                  {Object.entries(form.formState.errors).map(([field, error]) => (
                    <li key={field}>
                      <strong>{field}:</strong> {error?.message || 'Invalid value'}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90">
                <Save className="h-4 w-4 mr-2" />
                Save Shipment
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}