import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowDownToLine, ArrowUpFromLine, User, Calendar } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface ItemTransaction {
  id: string;
  itemId: string;
  orderId?: string;
  userId: string;
  transactionType: "check-in" | "check-out";
  quantity: number;
  notes?: string;
  createdAt: string;
  item: {
    id: string;
    sku: string;
    productName: string;
    unitType: string;
  };
  user: {
    id: string;
    name: string;
    employeeBarcode: string;
    role: string;
  };
}

interface ItemTransactionHistoryProps {
  itemId?: string;
  showItemInfo?: boolean;
}

export function ItemTransactionHistory({ itemId, showItemInfo = true }: ItemTransactionHistoryProps) {
  const { data: transactions, isLoading } = useQuery<ItemTransaction[]>({
    queryKey: ["/api/transactions", itemId],
    queryFn: () => {
      const url = itemId ? `/api/transactions?itemId=${itemId}` : "/api/transactions";
      return fetch(url).then((res) => {
        if (!res.ok) throw new Error("Failed to fetch transactions");
        return res.json();
      });
    },
  });

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Transaction History
          </CardTitle>
          <CardDescription>Loading transaction history...</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  if (!transactions || transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Transaction History
          </CardTitle>
          <CardDescription>No transactions found.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Transaction History
        </CardTitle>
        <CardDescription>
          Recent check-ins and check-outs {itemId && "for this item"}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {transactions.map((transaction, index) => (
          <div key={transaction.id}>
            <div className="flex items-start justify-between space-x-4">
              <div className="flex items-center space-x-3">
                <div className={`p-2 rounded-full ${
                  transaction.transactionType === "check-out" 
                    ? "bg-orange-100 text-orange-600 dark:bg-orange-900 dark:text-orange-400"
                    : "bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-400"
                }`}>
                  {transaction.transactionType === "check-out" ? (
                    <ArrowUpFromLine className="h-4 w-4" />
                  ) : (
                    <ArrowDownToLine className="h-4 w-4" />
                  )}
                </div>
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <Badge variant={transaction.transactionType === "check-out" ? "secondary" : "default"}>
                      {transaction.transactionType === "check-out" ? "Checked Out" : "Checked In"}
                    </Badge>
                    <span className="text-sm font-medium">
                      {transaction.quantity} {transaction.item.unitType}
                    </span>
                  </div>
                  {showItemInfo && (
                    <p className="text-sm text-muted-foreground">
                      {transaction.item.sku} - {transaction.item.productName}
                    </p>
                  )}
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <User className="h-3 w-3" />
                    <span>{transaction.user.name}</span>
                    <span>•</span>
                    <span>{format(new Date(transaction.createdAt), "MMM d, yyyy 'at' h:mm a")}</span>
                  </div>
                  {transaction.notes && (
                    <p className="text-sm text-muted-foreground italic">
                      Note: {transaction.notes}
                    </p>
                  )}
                </div>
              </div>
            </div>
            {index < transactions.length - 1 && <Separator className="mt-4" />}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}