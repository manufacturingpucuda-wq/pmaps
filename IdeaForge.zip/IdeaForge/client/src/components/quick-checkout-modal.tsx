import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useQuickCheckout } from "@/hooks/use-inventory";
import { useOrders } from "@/hooks/use-orders";
import { useToast } from "@/hooks/use-toast";
import { checkoutItemSchema, type CheckoutItemRequest, type ItemWithStatus } from "@shared/schema";
import { Textarea } from "@/components/ui/textarea";
import { LogOut } from "lucide-react";

interface QuickCheckoutModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: ItemWithStatus | null;
}

export function QuickCheckoutModal({ open, onOpenChange, item }: QuickCheckoutModalProps) {
  const quickCheckout = useQuickCheckout();
  const { data: orders = [] } = useOrders();
  const { toast } = useToast();

  const pendingOrders = orders.filter(order => order.status === "pending");

  const form = useForm<CheckoutItemRequest>({
    resolver: zodResolver(checkoutItemSchema),
    defaultValues: {
      quantity: 1,
      orderId: undefined,
      condition: "good",
      urgency: "normal",
      location: "",
      workOrder: "",
      department: "",
      batchNumber: "",
      serialNumbers: [],
      notes: "",
    },
  });

  const onSubmit = async (data: CheckoutItemRequest) => {
    if (!item) return;

    try {
      const result = await quickCheckout.mutateAsync({
        itemId: item.id,
        quantity: data.quantity,
        orderId: data.orderId && data.orderId !== "new" ? data.orderId : undefined,
        condition: data.condition || "good",
        urgency: data.urgency || "normal",
        location: data.location,
        workOrder: data.workOrder,
        department: data.department,
        batchNumber: data.batchNumber,
        serialNumbers: data.serialNumbers,
        notes: data.notes,
        reasonCode: data.reasonCode,
        approvedBy: data.approvedBy,
      });

      toast({
        title: "Success",
        description: `${data.quantity} units of ${item.sku} checked out to order ${result.orderNumber}`,
      });
      
      form.reset();
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to checkout item",
        variant: "destructive",
      });
    }
  };

  if (!item) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-3xl mx-4 max-h-[90vh] overflow-y-auto" data-testid="modal-quick-checkout">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-foreground flex items-center">
            <LogOut className="h-5 w-5 mr-2" />
            Quick Checkout
          </DialogTitle>
          <DialogDescription>
            Scan or enter item details to quickly check out items from inventory.
          </DialogDescription>
        </DialogHeader>
        
        <div className="mb-4 p-4 bg-muted rounded-lg">
          <h3 className="font-medium text-foreground">{item.sku}</h3>
          <p className="text-sm text-muted-foreground">{item.productName}</p>
          <div className="flex items-center space-x-2 mt-2">
            <p className="text-sm text-muted-foreground">
              Available Stock: <span className="font-semibold text-foreground">{item.availableStock}</span>
            </p>
            <Badge variant="outline" className="text-xs bg-blue-50 text-blue-700 border-blue-200">
              {item.unitType}
            </Badge>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="condition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Condition</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-condition">
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="damaged">Damaged</SelectItem>
                        <SelectItem value="defective">Defective</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="urgency"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Urgency Level</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-urgency">
                          <SelectValue placeholder="Select urgency" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="normal">Normal</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="critical">Critical</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Warehouse A-1" data-testid="input-location" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="workOrder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Work Order #</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., WO-2024-001" data-testid="input-work-order" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Manufacturing" data-testid="input-department" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="batchNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Batch Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., BATCH-2024-001" data-testid="input-batch-number" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="quantity"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-muted-foreground">
                      Quantity to Checkout
                    </FormLabel>
                    <FormControl>
                      <Input 
                        {...field} 
                        type="number"
                        min="1"
                        max={item.availableStock}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                        className="w-full"
                        data-testid="input-checkout-quantity"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="orderId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-muted-foreground">
                      Order (Optional)
                    </FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-checkout-order">
                          <SelectValue placeholder="Create new order..." />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="new">Create new order...</SelectItem>
                        {pendingOrders.map(order => (
                          <SelectItem key={order.id} value={order.id}>
                            {order.orderNumber} - {order.customer}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Notes</FormLabel>
                  <FormControl>
                    <Textarea
                      {...field}
                      placeholder="Any additional information about this checkout..."
                      className="min-h-[80px]"
                      data-testid="textarea-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex space-x-3 pt-4">
              <Button 
                type="submit" 
                disabled={quickCheckout.isPending}
                className="flex-1 bg-primary hover:bg-primary/90"
                data-testid="button-confirm-checkout"
              >
                {quickCheckout.isPending ? "Checking out..." : `Checkout ${form.watch("quantity")} Unit${form.watch("quantity") > 1 ? "s" : ""}`}
              </Button>
              <Button 
                type="button" 
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1"
                data-testid="button-cancel-checkout"
              >
                Cancel
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}