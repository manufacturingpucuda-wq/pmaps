import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { MoreHorizontal, Settings, X, Move, Maximize2, Minimize2 } from "lucide-react";
import { cn } from "@/lib/utils";

export interface Widget {
  id: string;
  type: 'stats' | 'chart' | 'list' | 'activity' | 'quick-actions';
  title: string;
  size: 'small' | 'medium' | 'large';
  position: { x: number; y: number };
  config: Record<string, any>;
  data?: any;
}

interface WidgetContainerProps {
  widget: Widget;
  onRemove: (id: string) => void;
  onResize: (id: string, size: Widget['size']) => void;
  onMove: (id: string, position: { x: number; y: number }) => void;
  onConfigChange: (id: string, config: Record<string, any>) => void;
  children: React.ReactNode;
  isEditMode?: boolean;
}

export function WidgetContainer({
  widget,
  onRemove,
  onResize,
  onMove,
  onConfigChange,
  children,
  isEditMode = false
}: WidgetContainerProps) {
  const [isDragging, setIsDragging] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);

  const sizeClasses = {
    small: "col-span-1 row-span-1",
    medium: "col-span-2 row-span-1",
    large: "col-span-2 row-span-2"
  };

  const handleDragStart = (e: React.DragEvent) => {
    if (!isEditMode) return;
    setIsDragging(true);
    e.dataTransfer.setData("text/plain", widget.id);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
  };

  const cycleSizes = () => {
    const sizes: Widget['size'][] = ['small', 'medium', 'large'];
    const currentIndex = sizes.indexOf(widget.size);
    const nextIndex = (currentIndex + 1) % sizes.length;
    onResize(widget.id, sizes[nextIndex]);
  };

  return (
    <Card
      className={cn(
        "transition-all duration-200 hover:shadow-md group relative",
        sizeClasses[widget.size],
        isDragging && "opacity-50 rotate-3 scale-105",
        isEditMode && "border-dashed border-2 border-primary/50",
        isExpanded && "z-50 fixed inset-4 w-auto h-auto"
      )}
      draggable={isEditMode}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      data-testid={`widget-${widget.type}-${widget.id}`}
    >
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <CardTitle className="text-sm font-medium">{widget.title}</CardTitle>
            <Badge variant="outline" className="text-xs">
              {widget.type}
            </Badge>
          </div>
          
          <div className="flex items-center space-x-1">
            {isEditMode && (
              <>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  onClick={cycleSizes}
                  data-testid={`button-resize-widget-${widget.id}`}
                >
                  <Maximize2 className="h-3 w-3" />
                </Button>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity cursor-move"
                  data-testid={`button-move-widget-${widget.id}`}
                >
                  <Move className="h-3 w-3" />
                </Button>
              </>
            )}
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  data-testid={`button-widget-menu-${widget.id}`}
                >
                  <MoreHorizontal className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => setIsExpanded(!isExpanded)}>
                  {isExpanded ? (
                    <>
                      <Minimize2 className="h-4 w-4 mr-2" />
                      Minimize
                    </>
                  ) : (
                    <>
                      <Maximize2 className="h-4 w-4 mr-2" />
                      Expand
                    </>
                  )}
                </DropdownMenuItem>
                <DropdownMenuItem>
                  <Settings className="h-4 w-4 mr-2" />
                  Configure
                </DropdownMenuItem>
                {isEditMode && (
                  <DropdownMenuItem 
                    onClick={() => onRemove(widget.id)}
                    className="text-red-600"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Remove
                  </DropdownMenuItem>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        {isExpanded && (
          <div className="absolute top-2 right-2 z-10">
            <Button
              size="sm"
              variant="secondary"
              onClick={() => setIsExpanded(false)}
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
        {children}
      </CardContent>
    </Card>
  );
}