import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BarChart3, 
  Activity, 
  Package, 
  ShoppingCart, 
  TrendingUp,
  List,
  Zap,
  Plus
} from "lucide-react";
import type { Widget } from "./widget-container";

interface WidgetTemplate {
  type: Widget['type'];
  title: string;
  description: string;
  icon: React.ReactNode;
  defaultSize: Widget['size'];
  defaultConfig: Record<string, any>;
  category: 'analytics' | 'inventory' | 'orders' | 'productivity';
}

const widgetTemplates: WidgetTemplate[] = [
  {
    type: 'stats',
    title: 'Inventory Stats',
    description: 'Display key inventory metrics',
    icon: <Package className="h-5 w-5" />,
    defaultSize: 'small',
    defaultConfig: { metric: 'totalItems' },
    category: 'inventory'
  },
  {
    type: 'stats',
    title: 'Order Statistics', 
    description: 'Track order performance',
    icon: <ShoppingCart className="h-5 w-5" />,
    defaultSize: 'small',
    defaultConfig: { metric: 'activeOrders' },
    category: 'orders'
  },
  {
    type: 'chart',
    title: 'Sales Chart',
    description: 'Visual sales data over time',
    icon: <BarChart3 className="h-5 w-5" />,
    defaultSize: 'large',
    defaultConfig: { chartType: 'line', period: '30d' },
    category: 'analytics'
  },
  {
    type: 'chart',
    title: 'Inventory Levels',
    description: 'Stock level trends',
    icon: <TrendingUp className="h-5 w-5" />,
    defaultSize: 'medium',
    defaultConfig: { chartType: 'bar', metric: 'stockLevels' },
    category: 'inventory'
  },
  {
    type: 'activity',
    title: 'Recent Activity',
    description: 'Latest system events',
    icon: <Activity className="h-5 w-5" />,
    defaultSize: 'medium',
    defaultConfig: { limit: 5, showTimestamp: true },
    category: 'productivity'
  },
  {
    type: 'list',
    title: 'Low Stock Items',
    description: 'Items needing attention',
    icon: <List className="h-5 w-5" />,
    defaultSize: 'medium',
    defaultConfig: { type: 'low-stock', threshold: 10, limit: 5 },
    category: 'inventory'
  },
  {
    type: 'list',
    title: 'Recent Orders',
    description: 'Latest customer orders',
    icon: <ShoppingCart className="h-5 w-5" />,
    defaultSize: 'medium',
    defaultConfig: { type: 'recent-orders', limit: 5 },
    category: 'orders'
  },
  {
    type: 'quick-actions',
    title: 'Quick Actions',
    description: 'Common task shortcuts',
    icon: <Zap className="h-5 w-5" />,
    defaultSize: 'small',
    defaultConfig: { actions: ['add-item', 'create-order', 'checkout'] },
    category: 'productivity'
  }
];

interface WidgetLibraryProps {
  onAddWidget: (template: WidgetTemplate) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function WidgetLibrary({ onAddWidget, isOpen, onClose }: WidgetLibraryProps) {
  const categories = Array.from(new Set(widgetTemplates.map(w => w.category)));

  const categoryColors = {
    analytics: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200",
    inventory: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200",
    orders: "bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200",
    productivity: "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200",
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-4xl max-h-[80vh] overflow-hidden">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Widget Library</CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-96">
            {categories.map(category => (
              <div key={category} className="mb-6">
                <h3 className="text-lg font-semibold mb-3 capitalize flex items-center">
                  {category}
                  <Badge 
                    variant="secondary" 
                    className={`ml-2 ${categoryColors[category as keyof typeof categoryColors]}`}
                  >
                    {widgetTemplates.filter(w => w.category === category).length}
                  </Badge>
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {widgetTemplates
                    .filter(template => template.category === category)
                    .map((template, index) => (
                      <Card 
                        key={`${template.type}-${index}`} 
                        className="hover:shadow-md transition-shadow cursor-pointer group"
                        onClick={() => {
                          onAddWidget(template);
                          onClose();
                        }}
                        data-testid={`widget-template-${template.type}-${index}`}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start space-x-3">
                            <div className="p-2 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground transition-colors">
                              {template.icon}
                            </div>
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{template.title}</h4>
                              <p className="text-xs text-muted-foreground mt-1">
                                {template.description}
                              </p>
                              <div className="flex items-center mt-2 space-x-2">
                                <Badge variant="outline" className="text-xs">
                                  {template.defaultSize}
                                </Badge>
                                <Badge variant="outline" className="text-xs">
                                  {template.type}
                                </Badge>
                              </div>
                            </div>
                            <Button size="sm" variant="ghost" className="opacity-0 group-hover:opacity-100 transition-opacity">
                              <Plus className="h-4 w-4" />
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                  ))}
                </div>
              </div>
            ))}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}

export { widgetTemplates, type WidgetTemplate };