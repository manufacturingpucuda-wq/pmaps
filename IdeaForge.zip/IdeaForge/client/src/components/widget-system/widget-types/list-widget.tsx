import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Package, ShoppingCart, AlertTriangle, Clock } from "lucide-react";
import { useInventory } from "@/hooks/use-inventory";
import { useOrders } from "@/hooks/use-orders";
import { formatDistanceToNow } from "date-fns";

interface ListWidgetProps {
  config: {
    type: 'low-stock' | 'recent-orders' | 'top-items';
    limit?: number;
    threshold?: number;
    sortBy?: string;
  };
}

export function ListWidget({ config }: ListWidgetProps) {
  const { data: items } = useInventory();
  const { data: orders } = useOrders();
  
  const renderLowStockItems = () => {
    const lowStockItems = items?.filter((item: any) => 
      item.currentStock <= (config.threshold || 10)
    ).slice(0, config.limit || 5) || [];

    return (
      <ScrollArea className="h-48">
        <div className="space-y-2">
          {lowStockItems.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <Package className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No low stock items</p>
            </div>
          ) : (
            lowStockItems.map((item: any, index: number) => (
              <div 
                key={item.id} 
                className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                data-testid={`low-stock-item-${index}`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.productName}</p>
                  <p className="text-xs text-muted-foreground">{item.sku}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge 
                    variant={item.currentStock === 0 ? "destructive" : "secondary"}
                    className="text-xs"
                  >
                    {item.currentStock} {item.unitType || 'pcs'}
                  </Badge>
                  {item.currentStock === 0 && (
                    <AlertTriangle className="h-4 w-4 text-red-500" />
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    );
  };

  const renderRecentOrders = () => {
    const recentOrders = orders?.slice(0, config.limit || 5) || [];

    return (
      <ScrollArea className="h-48">
        <div className="space-y-2">
          {recentOrders.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              <ShoppingCart className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">No recent orders</p>
            </div>
          ) : (
            recentOrders.map((order, index) => (
              <div 
                key={order.id}
                className="flex items-center justify-between p-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
                data-testid={`recent-order-${index}`}
              >
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium">{order.orderNumber}</p>
                  <p className="text-xs text-muted-foreground">
                    {order.customer || 'Unknown Customer'}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge 
                    variant={
                      order.status === 'fulfilled' ? "default" : 
                      order.status === 'pending' ? "secondary" : "outline"
                    }
                    className="text-xs capitalize"
                  >
                    {order.status}
                  </Badge>
                  <div className="text-xs text-muted-foreground flex items-center">
                    <Clock className="h-3 w-3 mr-1" />
                    {order.createdAt ? formatDistanceToNow(new Date(order.createdAt), { addSuffix: true }) : 'No date'}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    );
  };

  const renderTopItems = () => {
    // Sort items by stock level or other criteria
    const topItems = items?.slice(0, config.limit || 5) || [];

    return (
      <ScrollArea className="h-48">
        <div className="space-y-2">
          {topItems.map((item: any, index: number) => (
            <div 
              key={item.id}
              className="flex items-center justify-between p-2 rounded-lg bg-muted/50"
              data-testid={`top-item-${index}`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-primary">#{index + 1}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{item.productName}</p>
                  <p className="text-xs text-muted-foreground">{item.sku}</p>
                </div>
              </div>
              <Badge variant="outline" className="text-xs">
                {item.currentStock} {item.unitType || 'pcs'}
              </Badge>
            </div>
          ))}
        </div>
      </ScrollArea>
    );
  };

  const renderContent = () => {
    switch (config.type) {
      case 'low-stock':
        return renderLowStockItems();
      case 'recent-orders':
        return renderRecentOrders();
      case 'top-items':
        return renderTopItems();
      default:
        return <div>Unknown list type</div>;
    }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <Badge variant="outline" className="text-xs capitalize">
          {config.type.replace('-', ' ')}
        </Badge>
        {config.limit && (
          <Badge variant="secondary" className="text-xs">
            Top {config.limit}
          </Badge>
        )}
      </div>
      {renderContent()}
    </div>
  );
}