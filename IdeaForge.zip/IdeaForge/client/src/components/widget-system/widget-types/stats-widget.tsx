import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, TrendingDown, Package, ShoppingCart, AlertTriangle } from "lucide-react";
import { useAnalytics } from "@/hooks/use-orders";
import { cn } from "@/lib/utils";

interface StatsWidgetProps {
  config: {
    metric: 'totalItems' | 'activeOrders' | 'lowStockItems' | 'monthlyOrders';
    showTrend?: boolean;
    color?: 'blue' | 'green' | 'yellow' | 'red';
  };
}

const metricConfig = {
  totalItems: {
    label: 'Total Items',
    icon: Package,
    color: 'blue' as const,
    trend: { value: 12, label: 'vs last month' }
  },
  activeOrders: {
    label: 'Active Orders',
    icon: ShoppingCart,
    color: 'green' as const,
    trend: { value: 8, label: 'vs last week' }
  },
  lowStockItems: {
    label: 'Low Stock Items',
    icon: AlertTriangle,
    color: 'yellow' as const,
    trend: { value: -5, label: 'vs last month' }
  },
  monthlyOrders: {
    label: 'Monthly Orders',
    icon: ShoppingCart,
    color: 'green' as const,
    trend: { value: 15, label: 'vs last month' }
  }
};

const colorClasses = {
  blue: "text-blue-600 bg-blue-100 dark:bg-blue-900 dark:text-blue-200",
  green: "text-green-600 bg-green-100 dark:bg-green-900 dark:text-green-200",
  yellow: "text-yellow-600 bg-yellow-100 dark:bg-yellow-900 dark:text-yellow-200",
  red: "text-red-600 bg-red-100 dark:bg-red-900 dark:text-red-200",
};

export function StatsWidget({ config }: StatsWidgetProps) {
  const { data: stats, isLoading } = useAnalytics();
  const [animatedValue, setAnimatedValue] = useState(0);
  
  const metricInfo = metricConfig[config.metric];
  const Icon = metricInfo.icon;
  const color = config.color || metricInfo.color;
  const value = stats?.[config.metric] || 0;
  const trend = metricInfo.trend;

  // Animate the number counting up
  useEffect(() => {
    if (typeof value === 'number') {
      let current = 0;
      const increment = value / 20;
      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setAnimatedValue(value);
          clearInterval(timer);
        } else {
          setAnimatedValue(Math.floor(current));
        }
      }, 50);
      return () => clearInterval(timer);
    }
  }, [value]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-20">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className={cn("p-2 rounded-lg", colorClasses[color])}>
          <Icon className="h-5 w-5" />
        </div>
        {config.showTrend !== false && trend && (
          <div className={cn(
            "flex items-center space-x-1 text-xs px-2 py-1 rounded-full",
            trend.value > 0 
              ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
              : trend.value < 0
              ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
              : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
          )}>
            {trend.value > 0 ? (
              <TrendingUp className="h-3 w-3" />
            ) : (
              <TrendingDown className="h-3 w-3" />
            )}
            <span>{Math.abs(trend.value)}%</span>
          </div>
        )}
      </div>
      
      <div>
        <div className="text-2xl font-bold text-foreground">
          {typeof value === 'number' ? animatedValue.toLocaleString() : value}
        </div>
        <p className="text-sm text-muted-foreground">{metricInfo.label}</p>
        {config.showTrend !== false && trend && (
          <p className="text-xs text-muted-foreground mt-1">{trend.label}</p>
        )}
      </div>
    </div>
  );
}