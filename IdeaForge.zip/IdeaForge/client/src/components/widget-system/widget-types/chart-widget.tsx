import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface ChartWidgetProps {
  config: {
    chartType: 'line' | 'bar' | 'pie';
    period: '7d' | '30d' | '90d';
    metric?: string;
    title?: string;
  };
}

// Sample data - in real app this would come from API
const generateSampleData = (period: string, chartType: string) => {
  const days = period === '7d' ? 7 : period === '30d' ? 30 : 90;
  
  if (chartType === 'pie') {
    return [
      { name: 'In Stock', value: 65, color: '#10B981' },
      { name: 'Low Stock', value: 25, color: '#F59E0B' },
      { name: 'Out of Stock', value: 10, color: '#EF4444' }
    ];
  }
  
  return Array.from({ length: Math.min(days, 15) }, (_, i) => ({
    date: new Date(Date.now() - (days - i) * 24 * 60 * 60 * 1000).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric' 
    }),
    orders: Math.floor(Math.random() * 50) + 20,
    revenue: Math.floor(Math.random() * 5000) + 1000,
    inventory: Math.floor(Math.random() * 100) + 50
  }));
};

export function ChartWidget({ config }: ChartWidgetProps) {
  const data = generateSampleData(config.period, config.chartType);
  
  const chartColors = {
    line: '#3B82F6',
    bar: '#10B981',
    pie: ['#3B82F6', '#10B981', '#F59E0B', '#EF4444']
  };

  const renderChart = () => {
    switch (config.chartType) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="date" fontSize={12} stroke="#6B7280" />
              <YAxis fontSize={12} stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#FFFFFF', 
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="orders" 
                stroke={chartColors.line} 
                strokeWidth={2}
                dot={{ fill: chartColors.line, strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        );
        
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
              <XAxis dataKey="date" fontSize={12} stroke="#6B7280" />
              <YAxis fontSize={12} stroke="#6B7280" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: '#FFFFFF', 
                  border: '1px solid #E5E7EB',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="inventory" 
                fill={chartColors.bar}
                radius={[4, 4, 0, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        );
        
      case 'pie':
        return (
          <div className="flex items-center space-x-4">
            <ResponsiveContainer width="60%" height={150}>
              <PieChart>
                <Pie
                  data={data}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={60}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {data.map((entry: any, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex-1 space-y-2">
              {data.map((entry: any, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <div 
                    className="w-3 h-3 rounded-full" 
                    style={{ backgroundColor: entry.color }}
                  />
                  <span className="text-xs text-muted-foreground">{entry.name}</span>
                  <Badge variant="outline" className="text-xs ml-auto">
                    {entry.value}%
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        );
        
      default:
        return <div>Unsupported chart type</div>;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Badge variant="outline" className="text-xs">
          {config.period} period
        </Badge>
        <Badge variant="secondary" className="text-xs capitalize">
          {config.chartType} chart
        </Badge>
      </div>
      {renderChart()}
    </div>
  );
}