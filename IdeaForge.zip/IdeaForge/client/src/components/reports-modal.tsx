import { useState, useRef } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { FileText, Printer, Package, Activity, Calendar, Download, Eye } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import type { ItemWithStatus, OrderWithItems } from "@shared/schema";

interface ReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function ReportsModal({ isOpen, onClose }: ReportsModalProps) {
  const [selectedReport, setSelectedReport] = useState<string>("inventory");
  const [showPreview, setShowPreview] = useState(false);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);
  const reportRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: items = [] } = useQuery<ItemWithStatus[]>({
    queryKey: ["/api/items"],
    enabled: isOpen,
  });

  const { data: orders = [] } = useQuery<OrderWithItems[]>({
    queryKey: ["/api/orders"],
    enabled: isOpen,
  });

  const { data: transactions = [] } = useQuery<any[]>({
    queryKey: ["/api/transactions"],
    enabled: isOpen,
  });

  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    enabled: isOpen,
  });

  const generateReportPDF = async () => {
    if (!reportRef.current) return;

    try {
      toast({
        title: "Generating Report PDF...",
        description: "Creating your report document",
      });

      const html2pdf = (await import('html2pdf.js' as any)).default;
      
      const opt = {
        margin: 0.5,
        filename: `${selectedReport}-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
          scale: 2,
          useCORS: true,
          allowTaint: true 
        },
        jsPDF: { 
          unit: 'in', 
          format: 'letter', 
          orientation: 'portrait' 
        }
      };

      const pdfData = await html2pdf()
        .set(opt)
        .from(reportRef.current)
        .toPdf()
        .get('pdf');

      const blob = new Blob([pdfData.output('blob')], { type: 'application/pdf' });
      setPdfBlob(blob);
      
      toast({
        title: "Report PDF Generated",
        description: "Your report is ready for preview or download",
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePreview = async () => {
    if (!pdfBlob) {
      await generateReportPDF();
    }
    if (pdfBlob) {
      setShowPreview(true);
    }
  };

  const handleDownload = async () => {
    if (!pdfBlob) {
      await generateReportPDF();
    }
    
    if (pdfBlob) {
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedReport}-report-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Download Started",
        description: "Report PDF has been downloaded",
      });
    }
  };

  const handlePrint = () => {
    if (pdfBlob) {
      const url = URL.createObjectURL(pdfBlob);
      const printWindow = window.open(url, '_blank');
      if (printWindow) {
        printWindow.onload = () => {
          printWindow.print();
        };
      }
      URL.revokeObjectURL(url);
    } else {
      window.print();
    }
  };

  const lowStockItems = items.filter(item => item.currentStock < 10);
  const outOfStockItems = items.filter(item => item.currentStock === 0);
  const activeOrders = orders.filter(order => order.status === "pending");

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Reports & Documents
          </DialogTitle>
          <DialogDescription>
            Generate and print comprehensive reports for your warehouse operations.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex gap-2 no-print">
            <Button onClick={handlePreview} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
              <Eye className="h-4 w-4" />
              Preview PDF
            </Button>
            <Button onClick={handleDownload} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
            <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>

          <div ref={reportRef}>
            <Tabs value={selectedReport} onValueChange={setSelectedReport} className="w-full">
            <TabsList className="grid w-full grid-cols-4 no-print">
              <TabsTrigger value="inventory">Inventory Report</TabsTrigger>
              <TabsTrigger value="orders">Orders Report</TabsTrigger>
              <TabsTrigger value="transactions">Activity Report</TabsTrigger>
              <TabsTrigger value="summary">Summary Report</TabsTrigger>
            </TabsList>

            <TabsContent value="inventory" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Package className="h-5 w-5" />
                    Complete Inventory Report
                  </CardTitle>
                  <CardDescription>
                    Generated on {format(new Date(), "MMMM d, yyyy 'at' h:mm a")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>SKU</TableHead>
                        <TableHead>Product Name</TableHead>
                        <TableHead>Current Stock</TableHead>
                        <TableHead>Available</TableHead>
                        <TableHead>Unit Type</TableHead>
                        <TableHead>Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell className="font-medium">{item.sku}</TableCell>
                          <TableCell>{item.productName}</TableCell>
                          <TableCell>{item.currentStock}</TableCell>
                          <TableCell>{item.availableStock}</TableCell>
                          <TableCell>{item.unitType}</TableCell>
                          <TableCell>
                            <Badge variant={item.status === "available" ? "default" : "secondary"}>
                              {item.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="orders" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Calendar className="h-5 w-5" />
                    Orders Report
                  </CardTitle>
                  <CardDescription>
                    All orders and their fulfillment status
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {orders.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No orders found</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Order ID</TableHead>
                          <TableHead>Customer</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Items</TableHead>
                          <TableHead>Created</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {orders.map((order) => (
                          <TableRow key={order.id}>
                            <TableCell className="font-mono text-sm">{order.id}</TableCell>
                            <TableCell>{order.customer}</TableCell>
                            <TableCell>
                              <Badge variant={order.priority === "urgent" ? "destructive" : "default"}>
                                {order.priority}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant={order.status === "fulfilled" ? "default" : "secondary"}>
                                {order.status}
                              </Badge>
                            </TableCell>
                            <TableCell>{order.items?.length || 0}</TableCell>
                            <TableCell>{order.createdAt ? format(new Date(order.createdAt), "MMM d, yyyy") : "-"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="transactions" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Recent Activity Report
                  </CardTitle>
                  <CardDescription>
                    All check-ins and check-outs with user information
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  {transactions.length === 0 ? (
                    <p className="text-center text-muted-foreground py-8">No transactions found</p>
                  ) : (
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Type</TableHead>
                          <TableHead>Item</TableHead>
                          <TableHead>Quantity</TableHead>
                          <TableHead>User</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Notes</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {transactions.map((transaction) => (
                          <TableRow key={transaction.id}>
                            <TableCell>
                              <Badge variant={transaction.transactionType === "check-out" ? "secondary" : "default"}>
                                {transaction.transactionType === "check-out" ? "Check Out" : "Check In"}
                              </Badge>
                            </TableCell>
                            <TableCell>{transaction.item?.sku}</TableCell>
                            <TableCell>{transaction.quantity}</TableCell>
                            <TableCell>{transaction.user?.name}</TableCell>
                            <TableCell>{format(new Date(transaction.createdAt), "MMM d, h:mm a")}</TableCell>
                            <TableCell className="text-sm">{transaction.notes || "-"}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="summary" className="space-y-4">
              <div className="grid gap-4 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Inventory Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Items:</span>
                      <span className="font-bold">{items.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Available Items:</span>
                      <span className="font-bold text-green-600">
                        {items.filter(i => i.status === "available").length}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span>Low Stock Items:</span>
                      <span className="font-bold text-yellow-600">{lowStockItems.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Out of Stock:</span>
                      <span className="font-bold text-red-600">{outOfStockItems.length}</span>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Orders Summary</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between">
                      <span>Total Orders:</span>
                      <span className="font-bold">{orders.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Active Orders:</span>
                      <span className="font-bold text-blue-600">{activeOrders.length}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Fulfilled Orders:</span>
                      <span className="font-bold text-green-600">
                        {orders.filter(o => o.status === "fulfilled").length}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {lowStockItems.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-yellow-600">Low Stock Alert</CardTitle>
                    <CardDescription>Items that need restocking</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>SKU</TableHead>
                          <TableHead>Product</TableHead>
                          <TableHead>Current Stock</TableHead>
                          <TableHead>Unit Type</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {lowStockItems.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell className="font-medium">{item.sku}</TableCell>
                            <TableCell>{item.productName}</TableCell>
                            <TableCell className="text-red-600 font-bold">{item.currentStock}</TableCell>
                            <TableCell>{item.unitType}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
          </div>
        </div>

        {/* PDF Preview Modal */}
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-4xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Report PDF Preview</DialogTitle>
              <DialogDescription>
                Preview your report before downloading or printing
              </DialogDescription>
            </DialogHeader>
            
            <div className="h-[70vh] border rounded-lg">
              {pdfBlob ? (
                <iframe
                  src={URL.createObjectURL(pdfBlob)}
                  className="w-full h-full"
                  title="PDF Preview"
                />
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <p>Loading PDF preview...</p>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button onClick={handleDownload} className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
              <Button onClick={handlePrint} variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button variant="outline" onClick={() => setShowPreview(false)}>
                Close Preview
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <style>{`
          @media print {
            .no-print {
              display: none !important;
            }
            
            body {
              font-size: 12px;
              line-height: 1.4;
            }
            
            .print-page-break {
              page-break-before: always;
            }
            
            table {
              border-collapse: collapse;
              width: 100%;
            }
            
            th, td {
              border: 1px solid #ddd;
              padding: 8px;
              text-align: left;
            }
            
            th {
              background-color: #f5f5f5;
              font-weight: bold;
            }
          }
        `}</style>
      </DialogContent>
    </Dialog>
  );
}