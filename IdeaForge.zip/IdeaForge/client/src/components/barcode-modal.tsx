import { useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Printer, Download } from "lucide-react";
import type { ItemWithStatus } from "@shared/schema";

declare global {
  interface Window {
    JsBarcode: any;
  }
}

interface BarcodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  item: ItemWithStatus | null;
}

export function BarcodeModal({ isOpen, onClose, item }: BarcodeModalProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const printCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (isOpen && item && canvasRef.current) {
      // Load JsBarcode if not already loaded
      if (!window.JsBarcode) {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js';
        script.onload = () => generateBarcode();
        document.head.appendChild(script);
      } else {
        generateBarcode();
      }
    }
  }, [isOpen, item]);

  const generateBarcode = () => {
    if (!window.JsBarcode || !item || !canvasRef.current) {
      return;
    }

    try {
      const barcodeValue = item.barcode || item.sku || item.id;
      
      // Validate barcode value
      if (!barcodeValue || barcodeValue.trim() === '') {
        console.error('Error generating barcode for item:', item.name || 'Unknown', 'No valid barcode, SKU, or ID found');
        return;
      }
      
      // Generate display barcode
      window.JsBarcode(canvasRef.current, barcodeValue, {
        format: "CODE128",
        width: 2,
        height: 100,
        displayValue: true,
        fontSize: 16,
        margin: 10,
      });

      // Generate print barcode
      if (printCanvasRef.current) {
        window.JsBarcode(printCanvasRef.current, barcodeValue, {
          format: "CODE128",
          width: 3,
          height: 120,
          displayValue: true,
          fontSize: 18,
          margin: 15,
        });
      }
    } catch (error) {
      console.error('Error generating barcode for item:', item.name || 'Unknown', error);
      // Don't show alert, just log the error
    }
  };

  const handlePrint = async () => {
    if (!item) {
      return;
    }

    try {
      // Use the display canvas if print canvas is not available
      const canvas = printCanvasRef.current || canvasRef.current;
      if (!canvas) {
        alert('Barcode not ready for printing. Please wait a moment and try again.');
        return;
      }

      // Check if canvas has content
      const context = canvas.getContext('2d');
      const imageData = context?.getImageData(0, 0, canvas.width, canvas.height);
      const hasContent = imageData?.data.some(pixel => pixel !== 0);
      
      if (!hasContent) {
        alert('Barcode not generated yet. Please wait a moment and try again.');
        return;
      }

      const dataUrl = canvas.toDataURL('image/png', 1.0);

      // Try modern printing approach first
      if (navigator.userAgent.includes('Chrome') || navigator.userAgent.includes('Firefox')) {
        // Create a temporary image element for printing
        const printImg = new Image();
        printImg.onload = () => {
          const printWindow = window.open('', '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
          
          if (!printWindow) {
            alert('Print popup was blocked. Please allow popups for this site and try again.');
            return;
          }

          const printContent = `<!DOCTYPE html>
<html>
<head>
    <title>Barcode - ${item.sku}</title>
    <style>
        @page { margin: 0.5in; }
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 20px;
            display: flex;
            flex-direction: column;
            align-items: center;
            background: white;
            color: black;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
            border-bottom: 2px solid #333;
            padding-bottom: 15px;
        }
        .header h1 {
            margin: 0;
            font-size: 28px;
            color: #2563eb;
            font-weight: bold;
        }
        .header h2 {
            margin: 5px 0 0 0;
            font-size: 18px;
            color: #64748b;
        }
        .item-info {
            margin-bottom: 30px;
            text-align: center;
            background: #f8fafc;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
        }
        .item-info h3 {
            margin: 0 0 15px 0;
            font-size: 20px;
            color: #1e293b;
        }
        .item-info p {
            margin: 8px 0;
            font-size: 14px;
            color: #475569;
        }
        .barcode-container {
            border: 2px solid #000;
            padding: 25px;
            background: white;
            text-align: center;
            border-radius: 8px;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        }
        .barcode-container img {
            max-width: 100%;
            height: auto;
            display: block;
            margin: 0 auto;
        }
        @media print {
            body { padding: 10px; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>PUCUDA MFG</h1>
        <h2>Inventory Barcode Label</h2>
    </div>
    <div class="item-info">
        <h3>${item.productName || 'Unknown Product'}</h3>
        <p><strong>SKU:</strong> ${item.sku}</p>
        <p><strong>Current Stock:</strong> ${item.currentStock || 0} ${item.unitType || 'pieces'}</p>
        ${item.barcode ? `<p><strong>Barcode:</strong> ${item.barcode}</p>` : ''}
    </div>
    <div class="barcode-container">
        <img src="${dataUrl}" alt="Barcode for ${item.sku}" />
    </div>
    <script>
        window.onload = function() {
            setTimeout(function() {
                window.print();
                setTimeout(function() {
                    window.close();
                }, 1500);
            }, 800);
        };
    </script>
</body>
</html>`;

          printWindow.document.write(printContent);
          printWindow.document.close();
        };
        printImg.src = dataUrl;
      } else {
        // Fallback for other browsers
        window.print();
      }

    } catch (error) {
      alert('Failed to print barcode. Error: ' + (error instanceof Error ? error.message : 'Unknown error'));
    }
  };

  const handleDownload = () => {
    if (!canvasRef.current) {
      return;
    }

    try {
      const link = document.createElement('a');
      link.download = `barcode-${item?.sku || 'unknown'}.png`;
      link.href = canvasRef.current.toDataURL('image/png');
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      alert('Failed to download barcode. Please try again.');
    }
  };

  if (!item) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Barcode for {item.sku}</DialogTitle>
          <DialogDescription>
            {item.productName}
          </DialogDescription>
        </DialogHeader>
        
        <div className="flex flex-col items-center space-y-4">
          <div className="border rounded-lg p-4 bg-white">
            <canvas 
              ref={canvasRef} 
              className="max-w-full"
              data-testid="barcode-display"
            />
          </div>
          
          <div className="hidden">
            <canvas ref={printCanvasRef} />
          </div>

          <div className="grid grid-cols-2 gap-2 w-full">
            <Button 
              onClick={handlePrint} 
              variant="outline"
              data-testid="button-print-barcode"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print
            </Button>
            <Button 
              onClick={handleDownload}
              variant="outline"
              data-testid="button-download-barcode"
            >
              <Download className="h-4 w-4 mr-2" />
              Download
            </Button>
          </div>
          
          <div className="text-xs text-muted-foreground text-center">
            <p><strong>SKU:</strong> {item.sku}</p>
            <p><strong>Stock:</strong> {item.currentStock} {item.unitType || 'pieces'}</p>
            {item.barcode && <p><strong>Barcode:</strong> {item.barcode}</p>}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}