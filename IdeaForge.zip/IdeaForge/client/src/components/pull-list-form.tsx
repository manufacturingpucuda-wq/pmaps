import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Minus, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const pullListItemSchema = z.object({
  qtyOrdered: z.number().min(0, "Quantity must be positive"),
  qtyShipped: z.number().min(0, "Quantity must be positive"),
  partNumber: z.string().min(1, "Part number is required"),
  description: z.string().min(1, "Description is required"),
  qtyReturned: z.number().min(0, "Quantity must be positive").optional(),
});

const pullListFormSchema = z.object({
  project: z.string().min(1, "Project is required"),
  date: z.string().min(1, "Date is required"),
  company: z.string().min(1, "Company is required"),
  pullListReceived: z.enum(["yes", "no"]),
  salesOrderNumber: z.string().min(1, "Sales order number is required"),
  items: z.array(pullListItemSchema).min(1, "At least one item is required"),
  pulledBy: z.string().min(1, "Pulled by is required"),
  pulledDate: z.string().min(1, "Pulled date is required"),
  supervisor: z.string().min(1, "Supervisor is required"),
  supervisorDate: z.string().min(1, "Supervisor date is required"),
}).refine((data) => {
  // Ensure at least one item has valid data
  return data.items.some(item => item.partNumber.trim() !== '' && item.description.trim() !== '');
}, {
  message: "At least one item must have a part number and description",
  path: ["items"]
});

type PullListFormData = z.infer<typeof pullListFormSchema>;

interface PullListFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: PullListFormData) => Promise<void>;
  editingData?: any;
  title?: string;
}

export function PullListForm({ isOpen, onClose, onSubmit, editingData, title = "Create Pull List" }: PullListFormProps) {
  const { toast } = useToast();
  
  const form = useForm<PullListFormData>({
    resolver: zodResolver(pullListFormSchema),
    defaultValues: {
      project: editingData?.project || "",
      date: editingData?.date || new Date().toISOString().split('T')[0],
      company: editingData?.company || "",
      pullListReceived: editingData?.pullListReceived || "no",
      salesOrderNumber: editingData?.salesOrderNumber || "",
      items: editingData?.items || [
        { qtyOrdered: 0, qtyShipped: 0, partNumber: "", description: "", qtyReturned: 0 }
      ],
      pulledBy: editingData?.pulledBy || "",
      pulledDate: editingData?.pulledDate || new Date().toISOString().split('T')[0],
      supervisor: editingData?.supervisor || "",
      supervisorDate: editingData?.supervisorDate || new Date().toISOString().split('T')[0],
    },
  });

  const addItem = () => {
    const currentItems = form.getValues('items');
    form.setValue('items', [...currentItems, { qtyOrdered: 0, qtyShipped: 0, partNumber: "", description: "", qtyReturned: 0 }]);
  };

  const removeItem = (index: number) => {
    const currentItems = form.getValues('items');
    if (currentItems.length > 1) {
      const newItems = currentItems.filter((_, i) => i !== index);
      form.setValue('items', newItems);
    }
  };

  const handleSubmit = async (data: PullListFormData) => {
    try {
      await onSubmit(data);
      form.reset();
      onClose();
    } catch (error) {
      console.error('Form submission error:', error);
      // Don't close modal on error so user can see what went wrong
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-7xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-center">
            PUCUDA MFG - {title}
          </DialogTitle>
          <DialogDescription className="text-center text-muted-foreground">
            Create and manage pull list items with ordered, shipped, and returned quantities.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            {/* Header Information */}
            <div className="grid grid-cols-3 gap-6 p-4 bg-gray-50 rounded-lg">
              <FormField
                control={form.control}
                name="project"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Project:</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="Project Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="date"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Date:</FormLabel>
                    <FormControl>
                      <Input {...field} type="date" className="border-2 border-gray-300" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="company"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Company:</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="Company Name" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Pull List Status and Sales Order */}
            <div className="grid grid-cols-2 gap-6 p-4 bg-blue-50 rounded-lg">
              <FormField
                control={form.control}
                name="pullListReceived"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Pull List Received:</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger className="border-2 border-gray-300">
                          <SelectValue placeholder="Select Yes or No" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="yes">Yes</SelectItem>
                        <SelectItem value="no">No</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="salesOrderNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-semibold">Sales Order #:</FormLabel>
                    <FormControl>
                      <Input {...field} className="border-2 border-gray-300" placeholder="SO-2025-001" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            {/* Items Table */}
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Pull List Items</h3>
                <Button type="button" onClick={addItem} variant="outline" size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>
              </div>
              
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-gray-100">
                      <TableHead className="text-center font-bold">QTY ORDERED</TableHead>
                      <TableHead className="text-center font-bold">QTY SHIPPED</TableHead>
                      <TableHead className="text-center font-bold">PART NUMBER</TableHead>
                      <TableHead className="text-center font-bold">DESCRIPTION</TableHead>
                      <TableHead className="text-center font-bold">QTY RETURNED</TableHead>
                      <TableHead className="text-center font-bold">ACTION</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {form.watch('items').map((_, index) => (
                      <TableRow key={index} className="border-b">
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`items.${index}.qtyOrdered`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`items.${index}.qtyShipped`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`items.${index}.partNumber`}
                            render={({ field }) => (
                              <Input
                                className="text-center border-gray-300 font-mono"
                                {...field}
                                placeholder="80R-900-103A"
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`items.${index}.description`}
                            render={({ field }) => (
                              <Input
                                className="border-gray-300"
                                {...field}
                                placeholder="Item description"
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          <FormField
                            control={form.control}
                            name={`items.${index}.qtyReturned`}
                            render={({ field }) => (
                              <Input
                                type="number"
                                min="0"
                                className="text-center border-gray-300"
                                {...field}
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                              />
                            )}
                          />
                        </TableCell>
                        <TableCell>
                          {form.watch('items').length > 1 && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => removeItem(index)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Minus className="h-4 w-4" />
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>

            {/* Signature Fields */}
            <div className="grid grid-cols-2 gap-6 p-4 bg-green-50 rounded-lg border-2 border-green-200">
              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="pulledBy"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-semibold">Pulled by:</FormLabel>
                      <FormControl>
                        <Input {...field} className="border-2 border-gray-300" placeholder="Employee Name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="pulledDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-semibold">Date:</FormLabel>
                      <FormControl>
                        <Input {...field} type="date" className="border-2 border-gray-300" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="space-y-4">
                <FormField
                  control={form.control}
                  name="supervisor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-semibold">Supervisor:</FormLabel>
                      <FormControl>
                        <Input {...field} className="border-2 border-gray-300" placeholder="Supervisor Name" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="supervisorDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-sm font-semibold">Date:</FormLabel>
                      <FormControl>
                        <Input {...field} type="date" className="border-2 border-gray-300" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </div>

            {/* Form Validation Errors */}
            {Object.keys(form.formState.errors).length > 0 && (
              <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                <h4 className="font-semibold text-red-800 mb-2">Please fix the following errors:</h4>
                <ul className="text-sm text-red-700 list-disc list-inside space-y-1">
                  {Object.entries(form.formState.errors).map(([field, error]) => (
                    <li key={field}>
                      <strong>{field}:</strong> {error?.message || 'Invalid value'}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" className="bg-primary hover:bg-primary/90">
                <Save className="h-4 w-4 mr-2" />
                Save Pull List
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}