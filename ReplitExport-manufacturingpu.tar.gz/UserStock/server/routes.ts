import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertInventoryItemSchema, updateInventoryItemSchema, insertCategorySchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Helper function to check user role
  const requireRole = (roles: string[]) => {
    return (req: any, res: any, next: any) => {
      if (!req.user?.claims?.sub) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      // Get user role from database
      storage.getUser(req.user.claims.sub).then(user => {
        if (!user || !roles.includes(user.role)) {
          return res.status(403).json({ message: "Insufficient permissions" });
        }
        req.currentUser = user;
        next();
      }).catch(() => {
        res.status(500).json({ message: "Internal server error" });
      });
    };
  };

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Dashboard routes
  app.get('/api/dashboard/stats', isAuthenticated, async (req: any, res) => {
    try {
      const stats = await storage.getDashboardStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching dashboard stats:", error);
      res.status(500).json({ message: "Failed to fetch dashboard stats" });
    }
  });

  app.get('/api/dashboard/activity', isAuthenticated, async (req: any, res) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const activities = await storage.getRecentActivity(limit);
      res.json(activities);
    } catch (error) {
      console.error("Error fetching recent activity:", error);
      res.status(500).json({ message: "Failed to fetch recent activity" });
    }
  });

  // Inventory routes
  app.get('/api/inventory', isAuthenticated, async (req: any, res) => {
    try {
      const search = req.query.search as string;
      const category = req.query.category as string;
      const status = req.query.status as string;
      const page = parseInt(req.query.page as string) || 1;
      const limit = parseInt(req.query.limit as string) || 10;

      const result = await storage.getInventoryItems({
        search,
        category,
        status,
        page,
        limit,
      });

      res.json(result);
    } catch (error) {
      console.error("Error fetching inventory:", error);
      res.status(500).json({ message: "Failed to fetch inventory" });
    }
  });

  app.get('/api/inventory/:id', isAuthenticated, async (req: any, res) => {
    try {
      const item = await storage.getInventoryItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }
      res.json(item);
    } catch (error) {
      console.error("Error fetching inventory item:", error);
      res.status(500).json({ message: "Failed to fetch inventory item" });
    }
  });

  app.post('/api/inventory', isAuthenticated, requireRole(['admin', 'super-admin']), async (req: any, res) => {
    try {
      const itemData = insertInventoryItemSchema.parse(req.body);
      const newItem = await storage.createInventoryItem({
        ...itemData,
        createdBy: req.user.claims.sub,
      });

      // Log activity
      await storage.logActivity({
        userId: req.user.claims.sub,
        action: 'created',
        entityType: 'inventory_item',
        entityId: newItem.id,
        description: `Created inventory item: ${newItem.name}`,
        metadata: { sku: newItem.sku },
      });

      res.status(201).json(newItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating inventory item:", error);
      res.status(500).json({ message: "Failed to create inventory item" });
    }
  });

  app.put('/api/inventory/:id', isAuthenticated, requireRole(['admin', 'super-admin']), async (req: any, res) => {
    try {
      const itemData = updateInventoryItemSchema.parse(req.body);
      const updatedItem = await storage.updateInventoryItem(req.params.id, itemData);

      // Log activity
      await storage.logActivity({
        userId: req.user.claims.sub,
        action: 'updated',
        entityType: 'inventory_item',
        entityId: updatedItem.id,
        description: `Updated inventory item: ${updatedItem.name}`,
        metadata: { changes: itemData },
      });

      res.json(updatedItem);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error updating inventory item:", error);
      res.status(500).json({ message: "Failed to update inventory item" });
    }
  });

  app.delete('/api/inventory/:id', isAuthenticated, requireRole(['admin', 'super-admin']), async (req: any, res) => {
    try {
      const item = await storage.getInventoryItem(req.params.id);
      if (!item) {
        return res.status(404).json({ message: "Item not found" });
      }

      await storage.deleteInventoryItem(req.params.id);

      // Log activity
      await storage.logActivity({
        userId: req.user.claims.sub,
        action: 'deleted',
        entityType: 'inventory_item',
        entityId: req.params.id,
        description: `Deleted inventory item: ${item.name}`,
        metadata: { sku: item.sku },
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting inventory item:", error);
      res.status(500).json({ message: "Failed to delete inventory item" });
    }
  });

  // Category routes
  app.get('/api/categories', isAuthenticated, async (req: any, res) => {
    try {
      const categories = await storage.getCategories();
      res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      res.status(500).json({ message: "Failed to fetch categories" });
    }
  });

  app.post('/api/categories', isAuthenticated, requireRole(['admin', 'super-admin']), async (req: any, res) => {
    try {
      const categoryData = insertCategorySchema.parse(req.body);
      const newCategory = await storage.createCategory(categoryData);
      res.status(201).json(newCategory);
    } catch (error) {
      if (error instanceof ZodError) {
        return res.status(400).json({ message: "Validation error", errors: error.errors });
      }
      console.error("Error creating category:", error);
      res.status(500).json({ message: "Failed to create category" });
    }
  });

  // User management routes (Admin+ only)
  app.get('/api/users', isAuthenticated, requireRole(['admin', 'super-admin']), async (req: any, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });

  app.put('/api/users/:id/role', isAuthenticated, requireRole(['super-admin']), async (req: any, res) => {
    try {
      const { role } = req.body;
      if (!['user', 'admin', 'super-admin'].includes(role)) {
        return res.status(400).json({ message: "Invalid role" });
      }

      const updatedUser = await storage.updateUserRole(req.params.id, role);
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ message: "Failed to update user role" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
