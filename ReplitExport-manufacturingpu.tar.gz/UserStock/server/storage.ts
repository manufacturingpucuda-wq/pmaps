import {
  users,
  categories,
  inventoryItems,
  activityLogs,
  type User,
  type UpsertUser,
  type Category,
  type InsertCategory,
  type InventoryItem,
  type InsertInventoryItem,
  type UpdateInventoryItem,
  type ActivityLog,
  type InsertActivityLog,
  type InventoryItemWithCategory,
  type DashboardStats,
} from "@shared/schema";
import { db } from "./db";
import { eq, sql, desc, asc, like, and, or, count } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Inventory operations
  getInventoryItems(options?: {
    search?: string;
    category?: string;
    status?: string;
    page?: number;
    limit?: number;
  }): Promise<{ items: InventoryItemWithCategory[]; total: number }>;
  getInventoryItem(id: string): Promise<InventoryItemWithCategory | undefined>;
  createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem>;
  updateInventoryItem(id: string, item: UpdateInventoryItem): Promise<InventoryItem>;
  deleteInventoryItem(id: string): Promise<void>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  createCategory(category: InsertCategory): Promise<Category>;
  
  // Dashboard operations
  getDashboardStats(): Promise<DashboardStats>;
  getRecentActivity(limit?: number): Promise<ActivityLog[]>;
  
  // Activity logging
  logActivity(activity: InsertActivityLog): Promise<ActivityLog>;
  
  // User management (Admin only)
  getAllUsers(): Promise<User[]>;
  updateUserRole(userId: string, role: string): Promise<User>;
}

export class DatabaseStorage implements IStorage {
  // User operations (IMPORTANT: mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Inventory operations
  async getInventoryItems(options: {
    search?: string;
    category?: string;
    status?: string;
    page?: number;
    limit?: number;
  } = {}): Promise<{ items: InventoryItemWithCategory[]; total: number }> {
    const { search, category, status, page = 1, limit = 10 } = options;
    const offset = (page - 1) * limit;

    let whereConditions = [];
    
    if (search) {
      whereConditions.push(
        or(
          like(inventoryItems.name, `%${search}%`),
          like(inventoryItems.sku, `%${search}%`),
          like(inventoryItems.description, `%${search}%`)
        )
      );
    }
    
    if (category) {
      whereConditions.push(eq(inventoryItems.categoryId, category));
    }
    
    if (status) {
      whereConditions.push(eq(inventoryItems.status, status as any));
    }

    const whereClause = whereConditions.length > 0 ? and(...whereConditions) : undefined;

    const [items, totalResult] = await Promise.all([
      db
        .select({
          id: inventoryItems.id,
          name: inventoryItems.name,
          sku: inventoryItems.sku,
          description: inventoryItems.description,
          categoryId: inventoryItems.categoryId,
          unitPrice: inventoryItems.unitPrice,
          currentStock: inventoryItems.currentStock,
          minStock: inventoryItems.minStock,
          maxStock: inventoryItems.maxStock,
          supplier: inventoryItems.supplier,
          location: inventoryItems.location,
          shelf: inventoryItems.shelf,
          status: inventoryItems.status,
          createdBy: inventoryItems.createdBy,
          createdAt: inventoryItems.createdAt,
          updatedAt: inventoryItems.updatedAt,
          category: {
            id: categories.id,
            name: categories.name,
            description: categories.description,
            createdAt: categories.createdAt,
            updatedAt: categories.updatedAt,
          },
        })
        .from(inventoryItems)
        .leftJoin(categories, eq(inventoryItems.categoryId, categories.id))
        .where(whereClause)
        .orderBy(desc(inventoryItems.updatedAt))
        .limit(limit)
        .offset(offset),
      
      db
        .select({ count: count() })
        .from(inventoryItems)
        .where(whereClause)
        .then(result => result[0].count)
    ]);

    return {
      items: items.map(item => ({
        ...item,
        category: item.category?.id ? item.category : undefined,
      })),
      total: totalResult
    };
  }

  async getInventoryItem(id: string): Promise<InventoryItemWithCategory | undefined> {
    const [item] = await db
      .select({
        id: inventoryItems.id,
        name: inventoryItems.name,
        sku: inventoryItems.sku,
        description: inventoryItems.description,
        categoryId: inventoryItems.categoryId,
        unitPrice: inventoryItems.unitPrice,
        currentStock: inventoryItems.currentStock,
        minStock: inventoryItems.minStock,
        maxStock: inventoryItems.maxStock,
        supplier: inventoryItems.supplier,
        location: inventoryItems.location,
        shelf: inventoryItems.shelf,
        status: inventoryItems.status,
        createdBy: inventoryItems.createdBy,
        createdAt: inventoryItems.createdAt,
        updatedAt: inventoryItems.updatedAt,
        category: {
          id: categories.id,
          name: categories.name,
          description: categories.description,
          createdAt: categories.createdAt,
          updatedAt: categories.updatedAt,
        },
        createdByUser: {
          id: users.id,
          email: users.email,
          firstName: users.firstName,
          lastName: users.lastName,
          profileImageUrl: users.profileImageUrl,
          role: users.role,
          createdAt: users.createdAt,
          updatedAt: users.updatedAt,
        },
      })
      .from(inventoryItems)
      .leftJoin(categories, eq(inventoryItems.categoryId, categories.id))
      .leftJoin(users, eq(inventoryItems.createdBy, users.id))
      .where(eq(inventoryItems.id, id));

    if (!item) return undefined;

    return {
      ...item,
      category: item.category?.id ? item.category : undefined,
      createdBy: item.createdByUser?.id ? item.createdByUser : undefined,
    };
  }

  async createInventoryItem(item: InsertInventoryItem): Promise<InventoryItem> {
    // Determine status based on stock levels
    let status: "in-stock" | "low-stock" | "out-of-stock" = "in-stock";
    if (item.currentStock === 0) {
      status = "out-of-stock";
    } else if (item.currentStock <= item.minStock) {
      status = "low-stock";
    }

    const [newItem] = await db
      .insert(inventoryItems)
      .values({
        ...item,
        status,
      })
      .returning();

    return newItem;
  }

  async updateInventoryItem(id: string, item: UpdateInventoryItem): Promise<InventoryItem> {
    let updateData = { ...item, updatedAt: new Date() };

    // Update status if stock levels changed
    if (item.currentStock !== undefined || item.minStock !== undefined) {
      const currentItem = await this.getInventoryItem(id);
      if (currentItem) {
        const newCurrentStock = item.currentStock ?? currentItem.currentStock;
        const newMinStock = item.minStock ?? currentItem.minStock;
        
        let status: "in-stock" | "low-stock" | "out-of-stock" = "in-stock";
        if (newCurrentStock === 0) {
          status = "out-of-stock";
        } else if (newCurrentStock <= newMinStock) {
          status = "low-stock";
        }
        
        updateData = { ...updateData, status };
      }
    }

    const [updatedItem] = await db
      .update(inventoryItems)
      .set(updateData)
      .where(eq(inventoryItems.id, id))
      .returning();

    return updatedItem;
  }

  async deleteInventoryItem(id: string): Promise<void> {
    await db.delete(inventoryItems).where(eq(inventoryItems.id, id));
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories).orderBy(asc(categories.name));
  }

  async createCategory(category: InsertCategory): Promise<Category> {
    const [newCategory] = await db
      .insert(categories)
      .values(category)
      .returning();
    return newCategory;
  }

  // Dashboard operations
  async getDashboardStats(): Promise<DashboardStats> {
    const [totalItemsResult, lowStockResult, totalValueResult, categoriesResult] = await Promise.all([
      db.select({ count: count() }).from(inventoryItems),
      db.select({ count: count() }).from(inventoryItems).where(eq(inventoryItems.status, "low-stock")),
      db.select({ 
        total: sql<string>`COALESCE(SUM(${inventoryItems.currentStock} * ${inventoryItems.unitPrice}), 0)` 
      }).from(inventoryItems),
      db.select({ count: count() }).from(categories),
    ]);

    return {
      totalItems: totalItemsResult[0].count,
      lowStockCount: lowStockResult[0].count,
      totalValue: `$${parseFloat(totalValueResult[0].total).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`,
      categoriesCount: categoriesResult[0].count,
    };
  }

  async getRecentActivity(limit = 10): Promise<ActivityLog[]> {
    return await db
      .select()
      .from(activityLogs)
      .orderBy(desc(activityLogs.createdAt))
      .limit(limit);
  }

  // Activity logging
  async logActivity(activity: InsertActivityLog): Promise<ActivityLog> {
    const [newActivity] = await db
      .insert(activityLogs)
      .values(activity)
      .returning();
    return newActivity;
  }

  // User management (Admin only)
  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(asc(users.firstName), asc(users.lastName));
  }

  async updateUserRole(userId: string, role: string): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set({ role: role as any, updatedAt: new Date() })
      .where(eq(users.id, userId))
      .returning();
    return updatedUser;
  }
}

export const storage = new DatabaseStorage();
