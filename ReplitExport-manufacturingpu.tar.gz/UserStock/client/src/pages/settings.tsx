import { useEffect, useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  Settings as SettingsIcon, 
  Database, 
  Bell, 
  Mail, 
  Shield,
  Save,
  Download,
  Upload
} from "lucide-react";

export default function Settings() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [settings, setSettings] = useState({
    // System Settings
    systemName: "Pucuda Manufacturing",
    defaultCurrency: "USD",
    timezone: "UTC",
    dateFormat: "MM/DD/YYYY",
    
    // Notifications
    lowStockAlerts: true,
    outOfStockAlerts: true,
    emailNotifications: true,
    alertThreshold: 10,
    
    // Security
    sessionTimeout: 60,
    passwordExpiry: 90,
    twoFactorAuth: false,
    
    // Backup
    autoBackup: true,
    backupFrequency: "daily",
    retentionPeriod: 30,
  });

  const isSuperAdmin = user && user.role === 'super-admin';

  // Redirect if not authenticated or not super admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !isSuperAdmin)) {
      toast({
        title: "Unauthorized",
        description: "You need super admin privileges to access this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, isSuperAdmin, toast]);

  const handleSettingChange = (key: string, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const handleSaveSettings = () => {
    toast({
      title: "Settings Saved",
      description: "System settings have been updated successfully.",
    });
    // TODO: Implement actual settings save functionality
  };

  const handleBackupNow = () => {
    toast({
      title: "Backup Started",
      description: "System backup is being created. You'll be notified when complete.",
    });
    // TODO: Implement actual backup functionality
  };

  const handleRestoreBackup = () => {
    toast({
      title: "Restore Initiated",
      description: "Please select a backup file to restore from.",
    });
    // TODO: Implement actual restore functionality
  };

  const handleTestEmail = () => {
    toast({
      title: "Test Email Sent",
      description: "A test notification has been sent to your email address.",
    });
    // TODO: Implement actual email test functionality
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="animate-spin w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full"></div>
          <span className="text-gray-700 font-medium">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="System Settings" 
          subtitle="Configure system-wide settings and preferences"
        />
        
        <div className="flex-1 overflow-auto">
          <div className="p-6 space-y-6">
            {/* General Settings */}
            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <SettingsIcon className="w-5 h-5 text-gray-600" />
                  <CardTitle className="text-lg font-semibold text-gray-900">General Settings</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="systemName">System Name</Label>
                    <Input
                      id="systemName"
                      value={settings.systemName}
                      onChange={(e) => handleSettingChange('systemName', e.target.value)}
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="defaultCurrency">Default Currency</Label>
                    <Select 
                      value={settings.defaultCurrency} 
                      onValueChange={(value) => handleSettingChange('defaultCurrency', value)}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="USD">USD - US Dollar</SelectItem>
                        <SelectItem value="EUR">EUR - Euro</SelectItem>
                        <SelectItem value="GBP">GBP - British Pound</SelectItem>
                        <SelectItem value="CAD">CAD - Canadian Dollar</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select 
                      value={settings.timezone} 
                      onValueChange={(value) => handleSettingChange('timezone', value)}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="UTC">UTC</SelectItem>
                        <SelectItem value="EST">EST - Eastern Time</SelectItem>
                        <SelectItem value="PST">PST - Pacific Time</SelectItem>
                        <SelectItem value="CET">CET - Central European Time</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="dateFormat">Date Format</Label>
                    <Select 
                      value={settings.dateFormat} 
                      onValueChange={(value) => handleSettingChange('dateFormat', value)}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                        <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                        <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Bell className="w-5 h-5 text-gray-600" />
                  <CardTitle className="text-lg font-semibold text-gray-900">Notification Settings</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="lowStockAlerts">Low Stock Alerts</Label>
                      <p className="text-sm text-gray-500">Get notified when items reach minimum stock levels</p>
                    </div>
                    <Switch
                      id="lowStockAlerts"
                      checked={settings.lowStockAlerts}
                      onCheckedChange={(checked) => handleSettingChange('lowStockAlerts', checked)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="outOfStockAlerts">Out of Stock Alerts</Label>
                      <p className="text-sm text-gray-500">Get notified when items are completely out of stock</p>
                    </div>
                    <Switch
                      id="outOfStockAlerts"
                      checked={settings.outOfStockAlerts}
                      onCheckedChange={(checked) => handleSettingChange('outOfStockAlerts', checked)}
                    />
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <Label htmlFor="emailNotifications">Email Notifications</Label>
                      <p className="text-sm text-gray-500">Receive notifications via email</p>
                    </div>
                    <Switch
                      id="emailNotifications"
                      checked={settings.emailNotifications}
                      onCheckedChange={(checked) => handleSettingChange('emailNotifications', checked)}
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="alertThreshold">Alert Threshold (%)</Label>
                    <Input
                      id="alertThreshold"
                      type="number"
                      min="1"
                      max="50"
                      value={settings.alertThreshold}
                      onChange={(e) => handleSettingChange('alertThreshold', parseInt(e.target.value))}
                      className="mt-1"
                    />
                    <p className="text-sm text-gray-500 mt-1">Trigger alerts when stock is below this percentage of minimum</p>
                  </div>
                  
                  <div className="flex items-end">
                    <Button variant="outline" onClick={handleTestEmail}>
                      <Mail className="w-4 h-4 mr-2" />
                      Send Test Email
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Security Settings */}
            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Shield className="w-5 h-5 text-gray-600" />
                  <CardTitle className="text-lg font-semibold text-gray-900">Security Settings</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
                    <Input
                      id="sessionTimeout"
                      type="number"
                      min="15"
                      max="480"
                      value={settings.sessionTimeout}
                      onChange={(e) => handleSettingChange('sessionTimeout', parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="passwordExpiry">Password Expiry (days)</Label>
                    <Input
                      id="passwordExpiry"
                      type="number"
                      min="30"
                      max="365"
                      value={settings.passwordExpiry}
                      onChange={(e) => handleSettingChange('passwordExpiry', parseInt(e.target.value))}
                      className="mt-1"
                    />
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
                    <p className="text-sm text-gray-500">Require 2FA for all admin users</p>
                  </div>
                  <Switch
                    id="twoFactorAuth"
                    checked={settings.twoFactorAuth}
                    onCheckedChange={(checked) => handleSettingChange('twoFactorAuth', checked)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Backup Settings */}
            <Card className="border-gray-200">
              <CardHeader>
                <div className="flex items-center space-x-2">
                  <Database className="w-5 h-5 text-gray-600" />
                  <CardTitle className="text-lg font-semibold text-gray-900">Backup & Recovery</CardTitle>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="autoBackup">Automatic Backups</Label>
                    <p className="text-sm text-gray-500">Automatically create system backups</p>
                  </div>
                  <Switch
                    id="autoBackup"
                    checked={settings.autoBackup}
                    onCheckedChange={(checked) => handleSettingChange('autoBackup', checked)}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <Label htmlFor="backupFrequency">Backup Frequency</Label>
                    <Select 
                      value={settings.backupFrequency} 
                      onValueChange={(value) => handleSettingChange('backupFrequency', value)}
                      disabled={!settings.autoBackup}
                    >
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="hourly">Hourly</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label htmlFor="retentionPeriod">Retention Period (days)</Label>
                    <Input
                      id="retentionPeriod"
                      type="number"
                      min="7"
                      max="365"
                      value={settings.retentionPeriod}
                      onChange={(e) => handleSettingChange('retentionPeriod', parseInt(e.target.value))}
                      className="mt-1"
                      disabled={!settings.autoBackup}
                    />
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-center space-x-4">
                  <Button onClick={handleBackupNow} className="bg-primary-500 hover:bg-primary-600">
                    <Download className="w-4 h-4 mr-2" />
                    Backup Now
                  </Button>
                  
                  <Button variant="outline" onClick={handleRestoreBackup}>
                    <Upload className="w-4 h-4 mr-2" />
                    Restore Backup
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Save Button */}
            <div className="flex justify-end">
              <Button onClick={handleSaveSettings} size="lg" className="bg-primary-500 hover:bg-primary-600">
                <Save className="w-4 h-4 mr-2" />
                Save All Settings
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
