import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart3, 
  TrendingUp, 
  FolderOutput, 
  Calendar,
  DollarSign,
  Package,
  AlertTriangle
} from "lucide-react";

export default function Reports() {
  const { user, isAuthenticated, isLoading } = useAuth();
  const { toast } = useToast();
  const [dateRange, setDateRange] = useState("30");
  const [reportType, setReportType] = useState("inventory");

  const isAdmin = user && (user.role === 'admin' || user.role === 'super-admin');

  // Redirect if not authenticated or not admin
  useEffect(() => {
    if (!isLoading && (!isAuthenticated || !isAdmin)) {
      toast({
        title: "Unauthorized",
        description: "You need admin privileges to access this page.",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, isAdmin, toast]);

  const { data: stats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    retry: false,
    enabled: isAuthenticated && isAdmin,
  });

  const { data: inventoryData, isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/inventory"],
    retry: false,
    enabled: isAuthenticated && isAdmin,
  });

  const handleExportReport = () => {
    toast({
      title: "Export Started",
      description: "Your report is being generated and will be downloaded shortly.",
    });
    // TODO: Implement actual export functionality
  };

  const generateReport = () => {
    toast({
      title: "Report Generated",
      description: `${reportType} report for the last ${dateRange} days has been generated.`,
    });
    // TODO: Implement actual report generation
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="animate-spin w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full"></div>
          <span className="text-gray-700 font-medium">Loading...</span>
        </div>
      </div>
    );
  }

  const lowStockItems = inventoryData?.items?.filter((item: any) => item.status === 'low-stock') || [];
  const outOfStockItems = inventoryData?.items?.filter((item: any) => item.status === 'out-of-stock') || [];

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="Reports & Analytics" 
          subtitle="Generate detailed inventory reports and insights"
        />
        
        <div className="flex-1 overflow-auto">
          <div className="p-6 space-y-6">
            {/* Report Controls */}
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Generate Reports</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
                    <Select value={reportType} onValueChange={setReportType}>
                      <SelectTrigger className="w-48">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="inventory">Inventory Summary</SelectItem>
                        <SelectItem value="low-stock">Low Stock Report</SelectItem>
                        <SelectItem value="value">Inventory Valuation</SelectItem>
                        <SelectItem value="activity">Activity Report</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Date Range</label>
                    <Select value={dateRange} onValueChange={setDateRange}>
                      <SelectTrigger className="w-32">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7">Last 7 days</SelectItem>
                        <SelectItem value="30">Last 30 days</SelectItem>
                        <SelectItem value="90">Last 90 days</SelectItem>
                        <SelectItem value="365">Last year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="flex items-end space-x-2">
                    <Button onClick={generateReport} className="bg-primary-500 hover:bg-primary-600">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Generate Report
                    </Button>
                    
                    <Button variant="outline" onClick={handleExportReport}>
                      <FolderOutput className="w-4 h-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Items</p>
                      <p className="text-3xl font-bold text-gray-900 mt-2">
                        {statsLoading ? <Skeleton className="h-8 w-16" /> : stats?.totalItems || 0}
                      </p>
                      <p className="text-sm text-green-600 mt-1">
                        <TrendingUp className="w-3 h-3 inline mr-1" />
                        +5.2% from last month
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center">
                      <Package className="w-6 h-6 text-blue-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Total Value</p>
                      <p className="text-3xl font-bold text-gray-900 mt-2">
                        {statsLoading ? <Skeleton className="h-8 w-20" /> : stats?.totalValue || '$0'}
                      </p>
                      <p className="text-sm text-green-600 mt-1">
                        <TrendingUp className="w-3 h-3 inline mr-1" />
                        +12.3% from last month
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center">
                      <DollarSign className="w-6 h-6 text-green-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Low Stock Items</p>
                      <p className="text-3xl font-bold text-gray-900 mt-2">
                        {inventoryLoading ? <Skeleton className="h-8 w-12" /> : lowStockItems.length}
                      </p>
                      <p className="text-sm text-amber-600 mt-1">
                        <AlertTriangle className="w-3 h-3 inline mr-1" />
                        Requires attention
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center">
                      <AlertTriangle className="w-6 h-6 text-amber-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-gray-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Out of Stock</p>
                      <p className="text-3xl font-bold text-gray-900 mt-2">
                        {inventoryLoading ? <Skeleton className="h-8 w-12" /> : outOfStockItems.length}
                      </p>
                      <p className="text-sm text-red-600 mt-1">
                        <AlertTriangle className="w-3 h-3 inline mr-1" />
                        Critical items
                      </p>
                    </div>
                    <div className="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center">
                      <AlertTriangle className="w-6 h-6 text-red-500" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Low Stock Alert Table */}
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Low Stock Alerts</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead className="bg-gray-50 border-b border-gray-200">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Item
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Current Stock
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Minimum Stock
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Status
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Suggested Action
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {inventoryLoading ? (
                        [...Array(3)].map((_, i) => (
                          <tr key={i}>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Skeleton className="h-4 w-32" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Skeleton className="h-4 w-12" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Skeleton className="h-4 w-12" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Skeleton className="h-6 w-20 rounded-full" />
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Skeleton className="h-4 w-24" />
                            </td>
                          </tr>
                        ))
                      ) : lowStockItems.length > 0 ? (
                        lowStockItems.map((item: any) => (
                          <tr key={item.id} className="hover:bg-gray-50 transition-colors">
                            <td className="px-6 py-4 whitespace-nowrap">
                              <div className="text-sm font-medium text-gray-900">{item.name}</div>
                              <div className="text-sm text-gray-500">SKU: {item.sku}</div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.currentStock}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.minStock}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <Badge className="bg-amber-100 text-amber-800 hover:bg-amber-100">
                                Low Stock
                              </Badge>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                              Reorder {item.minStock * 2 - item.currentStock} units
                            </td>
                          </tr>
                        ))
                      ) : (
                        <tr>
                          <td colSpan={5} className="px-6 py-12 text-center">
                            <div className="flex flex-col items-center">
                              <AlertTriangle className="w-12 h-12 text-gray-300 mb-4" />
                              <p className="text-gray-500 text-lg font-medium">No low stock alerts</p>
                              <p className="text-gray-400 text-sm">All items are adequately stocked</p>
                            </div>
                          </td>
                        </tr>
                      )}
                    </tbody>
                  </table>
                </div>
              </CardContent>
            </Card>

            {/* Category Breakdown */}
            <Card className="border-gray-200">
              <CardHeader>
                <CardTitle className="text-lg font-semibold text-gray-900">Inventory by Category</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {inventoryLoading ? (
                    [...Array(3)].map((_, i) => (
                      <div key={i} className="p-4 bg-gray-50 rounded-lg">
                        <Skeleton className="h-6 w-24 mb-2" />
                        <Skeleton className="h-8 w-12 mb-1" />
                        <Skeleton className="h-4 w-32" />
                      </div>
                    ))
                  ) : (
                    <>
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-900">Electronics</h4>
                        <p className="text-2xl font-bold text-blue-800 mt-1">
                          {inventoryData?.items?.filter((item: any) => item.category?.name?.toLowerCase().includes('electronics')).length || 0}
                        </p>
                        <p className="text-sm text-blue-600">Items in category</p>
                      </div>
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <h4 className="font-medium text-purple-900">Furniture</h4>
                        <p className="text-2xl font-bold text-purple-800 mt-1">
                          {inventoryData?.items?.filter((item: any) => item.category?.name?.toLowerCase().includes('furniture')).length || 0}
                        </p>
                        <p className="text-sm text-purple-600">Items in category</p>
                      </div>
                      <div className="p-4 bg-green-50 rounded-lg">
                        <h4 className="font-medium text-green-900">Supplies</h4>
                        <p className="text-2xl font-bold text-green-800 mt-1">
                          {inventoryData?.items?.filter((item: any) => item.category?.name?.toLowerCase().includes('supplies')).length || 0}
                        </p>
                        <p className="text-sm text-green-600">Items in category</p>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
