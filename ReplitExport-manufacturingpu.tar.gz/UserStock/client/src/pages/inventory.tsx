import { useState, useCallback } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/top-bar";
import InventoryTable from "@/components/inventory/inventory-table";
import { useDebounce } from "@/hooks/use-debounce";

export default function Inventory() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);

  const debouncedSearch = useDebounce(search, 500);

  const { data: inventoryData, isLoading: inventoryLoading } = useQuery({
    queryKey: ["/api/inventory", { search: debouncedSearch, category, status, page, limit: 10 }],
    queryFn: async ({ queryKey }) => {
      const [, params] = queryKey as [string, any];
      const searchParams = new URLSearchParams();
      
      Object.entries(params).forEach(([key, value]) => {
        if (value) searchParams.append(key, value.toString());
      });
      
      const response = await fetch(`/api/inventory?${searchParams.toString()}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        if (response.status === 401) {
          throw new Error("401: Unauthorized");
        }
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    retry: false,
  });

  const handleSearch = useCallback((query: string) => {
    setSearch(query);
    setPage(1);
  }, []);

  const handleCategoryFilter = useCallback((categoryValue: string) => {
    setCategory(categoryValue);
    setPage(1);
  }, []);

  const handleStatusFilter = useCallback((statusValue: string) => {
    setStatus(statusValue);
    setPage(1);
  }, []);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="flex items-center space-x-3">
          <div className="animate-spin w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full"></div>
          <span className="text-gray-700 font-medium">Loading...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar />
      
      <main className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="Inventory Management" 
          subtitle="Manage your inventory items and stock levels"
          onSearch={handleSearch}
        />
        
        <div className="flex-1 overflow-auto">
          <div className="p-6">
            <InventoryTable 
              data={inventoryData} 
              isLoading={inventoryLoading}
              showAddButton={true}
              title="All Inventory Items"
              subtitle="Complete list of your inventory with search and filtering"
              onCategoryFilter={handleCategoryFilter}
              onStatusFilter={handleStatusFilter}
            />
          </div>
        </div>
      </main>
    </div>
  );
}
