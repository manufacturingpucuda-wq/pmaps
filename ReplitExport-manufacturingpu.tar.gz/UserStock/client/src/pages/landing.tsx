import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Boxes, Users, Shield, BarChart3 } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
                <Boxes className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-semibold text-gray-900">Pucuda Manufacturing</span>
            </div>
            
            <Button onClick={() => window.location.href = '/api/login'} className="bg-primary-500 hover:bg-primary-600">
              Sign In
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl sm:text-5xl font-bold text-gray-900 mb-6">
            Professional Inventory Management
            <span className="block text-primary-500">With Role-Based Access</span>
          </h1>
          <p className="text-xl text-gray-600 mb-8 max-w-2xl mx-auto">
            Streamline your inventory operations with our comprehensive management system. 
            Built for teams with different access levels and responsibilities.
          </p>
          <Button 
            size="lg" 
            onClick={() => window.location.href = '/api/login'}
            className="bg-primary-500 hover:bg-primary-600 text-lg px-8 py-4"
          >
            Get Started Now
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Everything You Need to Manage Inventory
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Powerful features designed for modern businesses with role-based access control
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center mb-4">
                  <Boxes className="w-6 h-6 text-blue-500" />
                </div>
                <CardTitle>Inventory Management</CardTitle>
                <CardDescription>
                  Complete CRUD operations for inventory items with real-time stock tracking and low stock alerts.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-purple-500" />
                </div>
                <CardTitle>Multi-User Support</CardTitle>
                <CardDescription>
                  Role-based access control with Users, Admins, and Super Admins having different permission levels.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-green-50 rounded-lg flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-green-500" />
                </div>
                <CardTitle>Secure Access</CardTitle>
                <CardDescription>
                  Enterprise-grade security with proper authentication and authorization controls.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-amber-50 rounded-lg flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-amber-500" />
                </div>
                <CardTitle>Analytics & Reports</CardTitle>
                <CardDescription>
                  Comprehensive dashboard with statistics, recent activity, and detailed reporting capabilities.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-red-50 rounded-lg flex items-center justify-center mb-4">
                  <Boxes className="w-6 h-6 text-red-500" />
                </div>
                <CardTitle>Stock Alerts</CardTitle>
                <CardDescription>
                  Automated notifications for low stock levels and out-of-stock items to prevent stockouts.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="border-gray-200">
              <CardHeader>
                <div className="w-12 h-12 bg-indigo-50 rounded-lg flex items-center justify-center mb-4">
                  <Users className="w-6 h-6 text-indigo-500" />
                </div>
                <CardTitle>User Management</CardTitle>
                <CardDescription>
                  Administrative tools for managing users, roles, and permissions across your organization.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-primary-50">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Transform Your Inventory Management?
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Join thousands of businesses using Pucuda Manufacturing to streamline their operations
          </p>
          <Button 
            size="lg" 
            onClick={() => window.location.href = '/api/login'}
            className="bg-primary-500 hover:bg-primary-600 text-lg px-8 py-4"
          >
            Start Your Free Trial
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center">
            <div className="flex items-center space-x-3">
              <div className="w-6 h-6 bg-primary-500 rounded-lg flex items-center justify-center">
                <Boxes className="w-4 h-4 text-white" />
              </div>
              <span className="text-lg font-semibold text-gray-900">Pucuda Manufacturing</span>
            </div>
          </div>
          <p className="text-center text-gray-500 mt-4">
            © 2024 Pucuda Manufacturing. Professional inventory management solution.
          </p>
        </div>
      </footer>
    </div>
  );
}
