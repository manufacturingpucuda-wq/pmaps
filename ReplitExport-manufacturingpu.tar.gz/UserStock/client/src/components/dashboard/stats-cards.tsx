import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Boxes, TriangleAlert, DollarSign, Tags } from "lucide-react";
import type { DashboardStats } from "@shared/schema";

interface StatsCardsProps {
  stats?: DashboardStats;
  isLoading: boolean;
}

export default function StatsCards({ stats, isLoading }: StatsCardsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="border-gray-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <Skeleton className="h-4 w-20" />
                  <Skeleton className="h-8 w-16" />
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-12 w-12 rounded-lg" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const cards = [
    {
      title: "Total Items",
      value: stats?.totalItems?.toLocaleString() || "0",
      change: "+5.2%",
      changeType: "positive" as const,
      icon: Boxes,
      iconColor: "text-blue-500",
      iconBg: "bg-blue-50",
    },
    {
      title: "Low Stock",
      value: stats?.lowStockCount?.toString() || "0",
      change: "Needs attention",
      changeType: "warning" as const,
      icon: TriangleAlert,
      iconColor: "text-amber-500",
      iconBg: "bg-amber-50",
    },
    {
      title: "Total Value",
      value: stats?.totalValue || "$0",
      change: "+12.3%",
      changeType: "positive" as const,
      icon: DollarSign,
      iconColor: "text-green-500",
      iconBg: "bg-green-50",
    },
    {
      title: "Categories",
      value: stats?.categoriesCount?.toString() || "0",
      change: "Active categories",
      changeType: "neutral" as const,
      icon: Tags,
      iconColor: "text-purple-500",
      iconBg: "bg-purple-50",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card) => (
        <Card key={card.title} className="border-gray-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">{card.title}</p>
                <p className="text-3xl font-bold text-gray-900 mt-2">{card.value}</p>
                <p className={`text-sm mt-1 ${
                  card.changeType === 'positive' ? 'text-green-600' :
                  card.changeType === 'warning' ? 'text-red-600' :
                  'text-gray-500'
                }`}>
                  {card.changeType === 'positive' && (
                    <i className="fas fa-arrow-up text-xs mr-1" />
                  )}
                  {card.changeType === 'warning' && (
                    <TriangleAlert className="w-3 h-3 inline mr-1" />
                  )}
                  <span>{card.change}</span>
                </p>
              </div>
              <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                <card.icon className={`w-6 h-6 ${card.iconColor}`} />
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
