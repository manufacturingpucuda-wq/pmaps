import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import AddItemModal from "@/components/inventory/add-item-modal";
import { Plus, Upload, FolderOutput } from "lucide-react";

export default function QuickActions() {
  const { user } = useAuth();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const isAdmin = user && (user.role === 'admin' || user.role === 'super-admin');

  const handleExportReport = () => {
    // TODO: Implement export functionality
    console.log("Export report");
  };

  const handleBulkUpload = () => {
    // TODO: Implement bulk upload functionality
    console.log("Bulk upload");
  };

  return (
    <>
      <div className="lg:col-span-1">
        <Card className="border-gray-200">
          <CardHeader>
            <CardTitle className="text-lg font-semibold text-gray-900">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {isAdmin && (
              <>
                <Button
                  onClick={() => setIsAddModalOpen(true)}
                  className="w-full justify-start space-x-3 bg-primary-50 text-primary-700 hover:bg-primary-100 border-0"
                  variant="outline"
                >
                  <Plus className="w-4 h-4" />
                  <span className="font-medium">Add New Item</span>
                </Button>
                
                <Button
                  onClick={handleBulkUpload}
                  variant="outline"
                  className="w-full justify-start space-x-3 bg-gray-50 text-gray-700 hover:bg-gray-100"
                >
                  <Upload className="w-4 h-4" />
                  <span className="font-medium">Bulk Upload</span>
                </Button>
              </>
            )}

            <Button
              onClick={handleExportReport}
              variant="outline"
              className="w-full justify-start space-x-3 bg-gray-50 text-gray-700 hover:bg-gray-100"
            >
              <FolderOutput className="w-4 h-4" />
              <span className="font-medium">Export Report</span>
            </Button>
          </CardContent>
        </Card>
      </div>

      <AddItemModal 
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
      />
    </>
  );
}
