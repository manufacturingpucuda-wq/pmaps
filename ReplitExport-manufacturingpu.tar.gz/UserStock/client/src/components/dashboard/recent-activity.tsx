import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Plus, TriangleAlert, Edit } from "lucide-react";
import type { ActivityLog } from "@shared/schema";

interface RecentActivityProps {
  activities?: ActivityLog[];
  isLoading: boolean;
}

export default function RecentActivity({ activities, isLoading }: RecentActivityProps) {
  if (isLoading) {
    return (
      <div className="lg:col-span-2">
        <Card className="border-gray-200">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg font-semibold text-gray-900">Recent Activity</CardTitle>
              <Skeleton className="h-8 w-16" />
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-start space-x-3">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div className="flex-1 space-y-1">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  const getActivityIcon = (action: string) => {
    switch (action) {
      case 'created':
        return <Plus className="w-3 h-3 text-green-500" />;
      case 'updated':
        return <Edit className="w-3 h-3 text-blue-500" />;
      case 'deleted':
        return <TriangleAlert className="w-3 h-3 text-red-500" />;
      default:
        return <Plus className="w-3 h-3 text-gray-500" />;
    }
  };

  const getActivityIconBg = (action: string) => {
    switch (action) {
      case 'created':
        return 'bg-green-50';
      case 'updated':
        return 'bg-blue-50';
      case 'deleted':
        return 'bg-red-50';
      default:
        return 'bg-gray-50';
    }
  };

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes} minutes ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)} hours ago`;
    return `${Math.floor(diffInMinutes / 1440)} days ago`;
  };

  return (
    <div className="lg:col-span-2">
      <Card className="border-gray-200">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">Recent Activity</CardTitle>
            <Button variant="link" className="text-sm text-primary-600 hover:text-primary-700 font-medium p-0">
              View All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {activities && activities.length > 0 ? (
            activities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className={`w-8 h-8 ${getActivityIconBg(activity.action)} rounded-full flex items-center justify-center flex-shrink-0`}>
                  {getActivityIcon(activity.action)}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900">
                    {activity.description}
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    {activity.createdAt ? formatTimeAgo(activity.createdAt) : 'Unknown time'}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-500">No recent activity</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
