import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  Boxes,
  BarChart3,
  Users,
  Settings,
  ChartPie,
  LogOut,
} from "lucide-react";

interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {
  const { user } = useAuth();
  const [location] = useLocation();

  const isAdmin = user && (user.role === 'admin' || user.role === 'super-admin');
  const isSuperAdmin = user && user.role === 'super-admin';

  const navigation = [
    { name: "Dashboard", href: "/", icon: ChartPie, current: location === "/" },
    { name: "Inventory", href: "/inventory", icon: Boxes, current: location === "/inventory" },
    ...(isAdmin ? [
      { name: "Reports", href: "/reports", icon: BarChart3, current: location === "/reports" },
      { name: "User Management", href: "/users", icon: Users, current: location === "/users" },
    ] : []),
    ...(isSuperAdmin ? [
      { name: "System Settings", href: "/settings", icon: Settings, current: location === "/settings" },
    ] : []),
  ];

  const userInitials = user ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || 'U' : 'U';
  const userName = user ? `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.email || 'User' : 'User';
  const userRole = user && user.role === 'super-admin' ? 'Super Admin' : 
                   user && user.role === 'admin' ? 'Admin' : 'User';

  return (
    <aside className={cn("w-64 bg-white shadow-sm border-r border-gray-200 flex flex-col", className)}>
      {/* Logo Section */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary-500 rounded-lg flex items-center justify-center">
            <Boxes className="w-5 h-5 text-white" />
          </div>
          <span className="text-xl font-semibold text-gray-900">Pucuda Manufacturing</span>
        </div>
      </div>

      {/* User Role Badge */}
      <div className="px-6 py-4 bg-primary-50 border-b border-gray-200">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-primary-100 rounded-full flex items-center justify-center">
            <span className="text-primary-600 text-sm font-medium">{userInitials}</span>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">{userName}</p>
            <p className="text-xs text-primary-600 font-medium">{userRole}</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 px-4 py-6 space-y-2">
        {navigation.map((item) => (
          <Link key={item.name} href={item.href}>
            <a
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors",
                item.current
                  ? "bg-primary-50 text-primary-700"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </a>
          </Link>
        ))}
      </nav>

      {/* User Actions */}
      <div className="p-4 border-t border-gray-200">
        <Button
          variant="ghost"
          onClick={() => window.location.href = '/api/logout'}
          className="w-full justify-start space-x-2 text-gray-600 hover:text-gray-900"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out</span>
        </Button>
      </div>
    </aside>
  );
}
