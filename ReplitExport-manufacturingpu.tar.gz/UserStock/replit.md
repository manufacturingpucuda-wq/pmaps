# Overview

Pucuda Manufacturing is a professional inventory management system built with React, Express, and PostgreSQL. The application provides role-based access control with three user tiers (user, admin, super-admin) and comprehensive inventory tracking capabilities. It features a modern web interface built with shadcn/ui components and implements Replit's authentication system for secure user management.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client-side application is built using React with TypeScript and follows a component-based architecture:
- **Framework**: React 18 with TypeScript for type safety
- **Routing**: Wouter for client-side routing with role-based route protection
- **State Management**: TanStack React Query for server state management and caching
- **UI Framework**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Form Handling**: React Hook Form with Zod validation schemas
- **Build Tool**: Vite for fast development and optimized production builds

## Backend Architecture
The server follows a RESTful API design pattern with Express.js:
- **Framework**: Express.js with TypeScript for the REST API
- **Database ORM**: Drizzle ORM with type-safe queries and migrations
- **Authentication**: Replit's OpenID Connect (OIDC) authentication system
- **Session Management**: Express sessions with PostgreSQL session store
- **API Structure**: Modular route handlers with middleware for authentication and authorization
- **Error Handling**: Centralized error handling with proper HTTP status codes

## Database Design
PostgreSQL database with Drizzle ORM providing type-safe database operations:
- **Users Table**: Stores user profiles with role-based permissions (user/admin/super-admin)
- **Categories Table**: Product categorization system
- **Inventory Items Table**: Core inventory data with relationships to categories
- **Activity Logs Table**: Audit trail for all inventory operations
- **Sessions Table**: Required for Replit Auth session persistence

## Role-Based Access Control
Three-tier permission system:
- **User**: Read-only access to inventory data
- **Admin**: Full inventory management, user management, and reporting capabilities
- **Super Admin**: All admin privileges plus system settings and configuration

## Authentication Flow
Integrates Replit's authentication system:
- **OIDC Integration**: Uses Replit's OpenID Connect for secure authentication
- **Session Management**: PostgreSQL-backed sessions with configurable TTL
- **Automatic User Creation**: First-time users are automatically registered with default 'user' role
- **Route Protection**: Middleware-based authentication checks on all protected endpoints

# External Dependencies

## Database Services
- **Neon Database**: PostgreSQL hosting service for production database
- **connect-pg-simple**: PostgreSQL session store for Express sessions

## Authentication Services
- **Replit Auth**: OpenID Connect authentication provider
- **Passport.js**: Authentication middleware with OIDC strategy

## UI and Styling
- **Radix UI**: Headless UI component primitives for accessibility
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Lucide React**: Icon library for consistent iconography
- **shadcn/ui**: Pre-built component library based on Radix UI

## Development Tools
- **TypeScript**: Static type checking across frontend and backend
- **Zod**: Runtime validation and type inference for forms and API data
- **Drizzle Kit**: Database migration and schema management tools
- **ESBuild**: Fast JavaScript bundler for production builds

## Data Fetching and State
- **TanStack React Query**: Server state management with caching and synchronization
- **React Hook Form**: Form state management with validation
- **date-fns**: Date utility library for formatting and manipulation