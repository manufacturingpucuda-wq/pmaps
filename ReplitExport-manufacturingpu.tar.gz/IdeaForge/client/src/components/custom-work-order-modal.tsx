import { useState } from "react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { Plus, Minus, FileText, Calendar, User, Package, DollarSign, Clock } from "lucide-react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

const customWorkOrderSchema = z.object({
  title: z.string().min(1, "Work order title is required"),
  description: z.string().min(1, "Description is required"),
  priority: z.enum(["low", "standard", "high", "urgent"]),
  category: z.enum(["production", "maintenance", "shipping", "receiving", "custom"]),
  estimatedHours: z.number().min(0.1, "Estimated hours must be greater than 0"),
  estimatedCost: z.number().min(0, "Cost must be positive"),
  dueDate: z.string().optional(),
  assignedTo: z.string().optional(),
  materials: z.array(z.object({
    description: z.string().min(1, "Material description required"),
    quantity: z.number().min(1, "Quantity must be at least 1"),
    unitType: z.string().min(1, "Unit type required"),
    estimatedCost: z.number().min(0, "Cost must be positive"),
  })),
  tasks: z.array(z.object({
    description: z.string().min(1, "Task description required"),
    estimatedHours: z.number().min(0.1, "Hours must be greater than 0"),
    assignedTo: z.string().optional(),
  })),
  specialInstructions: z.string().optional(),
  safetyRequirements: z.string().optional(),
});

type CustomWorkOrderFormData = z.infer<typeof customWorkOrderSchema>;

interface CustomWorkOrderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CustomWorkOrderModal({ open, onOpenChange }: CustomWorkOrderModalProps) {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const totalSteps = 4;

  const form = useForm<CustomWorkOrderFormData>({
    resolver: zodResolver(customWorkOrderSchema),
    defaultValues: {
      title: "",
      description: "",
      priority: "standard",
      category: "production",
      estimatedHours: 1,
      estimatedCost: 0,
      dueDate: "",
      assignedTo: "",
      materials: [{ description: "", quantity: 1, unitType: "pieces", estimatedCost: 0 }],
      tasks: [{ description: "", estimatedHours: 1, assignedTo: "" }],
      specialInstructions: "",
      safetyRequirements: "",
    },
  });

  const { fields: materialFields, append: appendMaterial, remove: removeMaterial } = useFieldArray({
    control: form.control,
    name: "materials",
  });

  const { fields: taskFields, append: appendTask, remove: removeTask } = useFieldArray({
    control: form.control,
    name: "tasks",
  });

  // Fetch real users from database
  const { data: users = [] } = useQuery({
    queryKey: ["/api/users"],
    select: (data: any[]) => data.map((user: any) => ({ id: user.id, name: `${user.firstName} ${user.lastName}` }))
  });
  
  const queryClient = useQueryClient();
  
  const createWorkOrderMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("/api/work-orders", "POST", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/work-orders"] });
    },
  });

  const onSubmit = async (data: CustomWorkOrderFormData) => {
    try {
      // Calculate total estimated cost
      const materialsCost = data.materials.reduce((sum, material) => sum + (material.estimatedCost * material.quantity), 0);
      const totalCost = materialsCost + data.estimatedCost;
      
      // Prepare data for backend
      const workOrderData = {
        title: data.title,
        description: data.description,
        priority: data.priority,
        category: data.category,
        estimatedHours: data.estimatedHours.toString(),
        estimatedCost: totalCost.toString(),
        dueDate: data.dueDate ? new Date(data.dueDate).toISOString() : null,
        assignedTo: data.assignedTo || null,
        materials: data.materials,
        tasks: data.tasks,
        specialInstructions: data.specialInstructions || null,
        safetyRequirements: data.safetyRequirements || null,
      };
      
      await createWorkOrderMutation.mutateAsync(workOrderData);
      
      toast({
        title: "Success",
        description: `Work order "${data.title}" created successfully`,
      });
      
      form.reset();
      setCurrentStep(1);
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to create work order",
        variant: "destructive",
      });
    }
  };

  const getPriorityBadge = (priority: string) => {
    const variants = {
      low: "bg-gray-600 text-white",
      standard: "bg-blue-600 text-white",
      high: "bg-orange-600 text-white",
      urgent: "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[priority as keyof typeof variants]}>
        {priority.charAt(0).toUpperCase() + priority.slice(1)}
      </Badge>
    );
  };

  const getCategoryBadge = (category: string) => {
    const variants = {
      production: "bg-green-600 text-white",
      maintenance: "bg-yellow-600 text-white",
      shipping: "bg-blue-600 text-white",
      receiving: "bg-purple-600 text-white",
      custom: "bg-gray-600 text-white",
    };
    return (
      <Badge className={variants[category as keyof typeof variants]}>
        {category.charAt(0).toUpperCase() + category.slice(1)}
      </Badge>
    );
  };

  const nextStep = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Basic Information
            </h3>
            
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Work Order Title</FormLabel>
                  <FormControl>
                    <Input {...field} placeholder="Enter descriptive title" data-testid="input-wo-title" />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Describe the work to be performed: What specific problem needs solving? What are the objectives and expected outcomes? Include scope, timeline expectations, and success criteria." 
                      rows={4} 
                      data-testid="textarea-wo-description" 
                    />
                  </FormControl>
                  <p className="text-sm text-muted-foreground">Provide clear details to help assignees understand the full scope of work</p>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-wo-category">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="production">Production - Manufacturing & Assembly</SelectItem>
                        <SelectItem value="maintenance">Maintenance - Equipment & Facility</SelectItem>
                        <SelectItem value="shipping">Shipping - Outbound Operations</SelectItem>
                        <SelectItem value="receiving">Receiving - Inbound Operations</SelectItem>
                        <SelectItem value="quality">Quality - Inspection & Testing</SelectItem>
                        <SelectItem value="custom">Custom - Special Projects</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-wo-priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="low">Low - Complete when convenient</SelectItem>
                        <SelectItem value="standard">Standard - Normal priority</SelectItem>
                        <SelectItem value="high">High - Important, expedite completion</SelectItem>
                        <SelectItem value="urgent">Urgent - Stop other work, complete immediately</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold flex items-center">
              <Calendar className="h-5 w-5 mr-2" />
              Scheduling & Assignment
            </h3>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due Date (Optional)</FormLabel>
                    <FormControl>
                      <Input type="datetime-local" {...field} data-testid="input-wo-due-date" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="assignedTo"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assign To (Optional)</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-wo-assigned-to">
                          <SelectValue placeholder="Select worker" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="unassigned">Unassigned</SelectItem>
                        {users.map((user) => (
                          <SelectItem key={user.id} value={user.id}>
                            {user.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="estimatedHours"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Estimated Hours</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.5"
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        data-testid="input-wo-hours" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="estimatedCost"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Labor Cost ($)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        step="0.01"
                        {...field} 
                        onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                        data-testid="input-wo-cost" 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold flex items-center">
                <Package className="h-5 w-5 mr-2" />
                Materials & Tasks
              </h3>
            </div>

            {/* Materials Section */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-base">Required Materials</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => appendMaterial({ description: "", quantity: 1, unitType: "pieces", estimatedCost: 0 })}
                    data-testid="button-add-material"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Material
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {materialFields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-12 gap-2 items-end">
                    <div className="col-span-4">
                      <FormField
                        control={form.control}
                        name={`materials.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Description</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="e.g., Steel bolts M12x50, Hydraulic oil SAE 10W-30, Safety harnesses class A" data-testid={`input-material-desc-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-2">
                      <FormField
                        control={form.control}
                        name={`materials.${index}.quantity`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Qty</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                {...field} 
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 1)}
                                data-testid={`input-material-qty-${index}`} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-2">
                      <FormField
                        control={form.control}
                        name={`materials.${index}.unitType`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Unit</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-material-unit-${index}`}>
                                  <SelectValue placeholder="Select unit" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="pieces">Pieces</SelectItem>
                                <SelectItem value="boxes">Boxes</SelectItem>
                                <SelectItem value="pounds">Pounds</SelectItem>
                                <SelectItem value="kilograms">Kilograms</SelectItem>
                                <SelectItem value="gallons">Gallons</SelectItem>
                                <SelectItem value="liters">Liters</SelectItem>
                                <SelectItem value="feet">Feet</SelectItem>
                                <SelectItem value="meters">Meters</SelectItem>
                                <SelectItem value="hours">Hours</SelectItem>
                                <SelectItem value="sets">Sets</SelectItem>
                                <SelectItem value="rolls">Rolls</SelectItem>
                                <SelectItem value="sheets">Sheets</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-3">
                      <FormField
                        control={form.control}
                        name={`materials.${index}.estimatedCost`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Cost Each ($)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.01"
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                                data-testid={`input-material-cost-${index}`} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-1">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeMaterial(index)}
                        disabled={materialFields.length === 1}
                        data-testid={`button-remove-material-${index}`}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Tasks Section */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-base">Work Tasks</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => appendTask({ description: "", estimatedHours: 1, assignedTo: "" })}
                    data-testid="button-add-task"
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Add Task
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {taskFields.map((field, index) => (
                  <div key={field.id} className="grid grid-cols-12 gap-2 items-end">
                    <div className="col-span-6">
                      <FormField
                        control={form.control}
                        name={`tasks.${index}.description`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Task Description</FormLabel>
                            <FormControl>
                              <Input {...field} placeholder="e.g., Inspect conveyor belt for damage, Replace worn bearings on motor assembly, Test equipment functionality and calibrate" data-testid={`input-task-desc-${index}`} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-2">
                      <FormField
                        control={form.control}
                        name={`tasks.${index}.estimatedHours`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Hours</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                step="0.5"
                                {...field} 
                                onChange={(e) => field.onChange(parseFloat(e.target.value) || 1)}
                                data-testid={`input-task-hours-${index}`} 
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-3">
                      <FormField
                        control={form.control}
                        name={`tasks.${index}.assignedTo`}
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel className="text-sm">Assigned To</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid={`select-task-assigned-${index}`}>
                                  <SelectValue placeholder="Select worker" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="unassigned">Unassigned</SelectItem>
                                {users.map((user) => (
                                  <SelectItem key={user.id} value={user.id}>
                                    {user.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    <div className="col-span-1">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeTask(index)}
                        disabled={taskFields.length === 1}
                        data-testid={`button-remove-task-${index}`}
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        );

      case 4:
        return (
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Special Requirements & Review</h3>

            <FormField
              control={form.control}
              name="specialInstructions"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Special Instructions</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Special procedures: coordination with other departments, quality standards (ISO/OSHA), environmental conditions, specialized equipment needs, vendor coordination requirements..." 
                      rows={3} 
                      data-testid="textarea-special-instructions" 
                    />
                  </FormControl>
                  <p className="text-sm text-muted-foreground">Optional: Add any specific instructions that aren't covered elsewhere</p>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="safetyRequirements"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Safety Requirements</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Safety requirements: Required PPE (hard hat, safety glasses, steel-toed boots, gloves), lockout/tagout procedures, confined space entry permits, chemical hazards (MSDS sheets), hot work permits, fall protection..." 
                      rows={3} 
                      data-testid="textarea-safety-requirements" 
                    />
                  </FormControl>
                  <p className="text-sm text-muted-foreground">Specify all safety measures and protective equipment needed</p>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Work Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span>Title:</span>
                  <span className="font-medium">{form.watch("title") || "Not specified"}</span>
                </div>
                <div className="flex justify-between">
                  <span>Category:</span>
                  {form.watch("category") && getCategoryBadge(form.watch("category"))}
                </div>
                <div className="flex justify-between">
                  <span>Priority:</span>
                  {form.watch("priority") && getPriorityBadge(form.watch("priority"))}
                </div>
                <div className="flex justify-between">
                  <span>Estimated Hours:</span>
                  <span className="font-medium flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    {form.watch("estimatedHours")} hrs
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Materials Count:</span>
                  <span className="font-medium">{materialFields.length} items</span>
                </div>
                <div className="flex justify-between">
                  <span>Tasks Count:</span>
                  <span className="font-medium">{taskFields.length} tasks</span>
                </div>
                <div className="flex justify-between font-semibold text-lg border-t pt-2">
                  <span>Total Estimated Cost:</span>
                  <span className="flex items-center">
                    <DollarSign className="h-4 w-4 mr-1" />
                    {(form.watch("estimatedCost") + 
                      form.watch("materials").reduce((sum, material) => 
                        sum + (material.estimatedCost * material.quantity), 0)
                    ).toFixed(2)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-custom-work-order">
        <DialogHeader>
          <DialogTitle className="flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Create Custom Work Order
          </DialogTitle>
          <DialogDescription>
            Create a detailed custom work order with materials, tasks, and assignments.
          </DialogDescription>
          
          {/* Progress Indicator */}
          <div className="flex items-center space-x-2 mt-4">
            {Array.from({ length: totalSteps }, (_, i) => (
              <div
                key={i}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  i + 1 === currentStep
                    ? "bg-primary text-white"
                    : i + 1 < currentStep
                    ? "bg-green-600 text-white"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
          <div className="text-sm text-muted-foreground">
            Step {currentStep} of {totalSteps}
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            {renderStepContent()}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  onOpenChange(false);
                  setCurrentStep(1);
                  form.reset();
                }}
                data-testid="button-cancel-custom-wo"
              >
                Cancel
              </Button>

              <div className="flex space-x-2">
                {currentStep > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    onClick={prevStep}
                    data-testid="button-prev-step"
                  >
                    Previous
                  </Button>
                )}
                
                {currentStep < totalSteps ? (
                  <Button
                    type="button"
                    onClick={nextStep}
                    className="bg-primary hover:bg-primary/90"
                    data-testid="button-next-step"
                  >
                    Next
                  </Button>
                ) : (
                  <Button
                    type="submit"
                    className="bg-primary hover:bg-primary/90"
                    data-testid="button-create-custom-wo"
                  >
                    Create Work Order
                  </Button>
                )}
              </div>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}