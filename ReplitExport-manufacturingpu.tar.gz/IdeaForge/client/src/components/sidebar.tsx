import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { ThemeToggle } from "@/components/theme-toggle";
import pucudaLogo from "@/assets/pucuda-logo.png";
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  CheckCircle, 
  BarChart, 
  Factory,
  Menu,
  Users,
  Truck,
  PackageOpen,
  Search,
  Settings,
  LogOut,
  TrendingUp,
  FileText,
  Clock,
  Receipt
} from "lucide-react";

import puclogo_bug from "@assets/puclogo-bug.png";

const allNavigation = [
  { name: "Dashboard", href: "/", icon: LayoutDashboard, adminOnly: false },
  { name: "Inventory", href: "/inventory", icon: Package, adminOnly: false },
  { name: "Orders", href: "/orders", icon: ShoppingCart, adminOnly: false },
  { name: "Time Clock", href: "/time-clock", icon: Clock, adminOnly: false },
  { name: "Users", href: "/users", icon: Users, adminOnly: true },
  { name: "Shipping", href: "/shipping", icon: Truck, adminOnly: false },
  { name: "Receiving", href: "/receiving", icon: PackageOpen, adminOnly: false },
  { name: "Documents", href: "/documents", icon: Search, adminOnly: false },
  { name: "Invoices", href: "/invoices", icon: Receipt, adminOnly: false },
  { name: "Checkout", href: "/checkout", icon: CheckCircle, adminOnly: false },
  { name: "Reports", href: "/reports", icon: BarChart, adminOnly: false },
  { name: "Activity", href: "/activity", icon: TrendingUp, adminOnly: true },
  { name: "Activity Reports", href: "/comprehensive-activity", icon: FileText, adminOnly: false },
  { name: "Settings", href: "/settings", icon: Settings, adminOnly: true },
];

export function Sidebar() {
  const [location] = useLocation();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const { logout, isLoggingOut, user } = useAuth();
  const { toast } = useToast();

  return (
    <>
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setIsMobileOpen(!isMobileOpen)}
          data-testid="button-mobile-menu"
        >
          <Menu className="h-4 w-4" />
        </Button>
      </div>
      {/* Sidebar */}
      <aside 
        className={cn(
          "w-64 bg-card border-r border-border sidebar-transition flex flex-col",
          "fixed lg:relative z-40 h-full",
          isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header */}
        <div className="p-6 border-b border-border">
          <div className="flex items-center space-x-3">
            <div className="w-12 h-12 flex items-center justify-center">
              <img 
                src={puclogo_bug} 
                alt="PUCUDA Manufacturing" 
                className="w-12 h-12 object-contain"
              />
            </div>
            <div>
              <h1 className="text-lg font-extrabold text-[#ed8821]">P-MAPS </h1>
              <p className="text-xs text-[#148222]">Pucuda Manufacturing </p>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-4 space-y-2">
          {allNavigation
            .filter(item => !item.adminOnly || (user && user.role === "admin"))
            .map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.name} href={item.href}>
                <Button
                  variant={isActive ? "default" : "ghost"}
                  className={cn(
                    "w-full justify-start space-x-3",
                    isActive && "bg-primary text-primary-foreground",
                    !isActive && "text-muted-foreground hover:text-foreground hover:bg-elevated"
                  )}
                  onClick={() => setIsMobileOpen(false)}
                  data-testid={`nav-${item.name.toLowerCase()}`}
                >
                  <item.icon className="h-4 w-4" />
                  <span>{item.name}</span>
                </Button>
              </Link>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-4 border-t border-border">
          {user && (
            <div className="mb-3 text-xs text-muted-foreground">
              <p>Logged in as: <span className="text-foreground font-medium">{user.name}</span></p>
              <p>Role: <span className="text-foreground">{user.role}</span></p>
            </div>
          )}
          
          {/* Theme Toggle */}
          <div className="mb-3 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Theme:</span>
            <ThemeToggle />
          </div>
          
          <Button
            variant="outline"
            className="w-full mb-3 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950"
            onClick={async () => {
              if (confirm("Are you sure you want to logout?")) {
                try {
                  await logout();
                } catch (error) {
                  toast({
                    title: "Logout failed",
                    description: "Please try again",
                    variant: "destructive",
                  });
                }
              }
            }}
            disabled={isLoggingOut}
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4 mr-2" />
            {isLoggingOut ? "Logging out..." : "Logout"}
          </Button>
          <div className="text-xs text-muted-foreground">
            <p>System Status: <span className="text-green-400">Online</span></p>
            <p className="mt-1">
              Last Updated: <span id="last-update">{new Date().toLocaleTimeString()}</span>
            </p>
          </div>
        </div>
      </aside>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={() => setIsMobileOpen(false)}
        />
      )}
    </>
  );
}
