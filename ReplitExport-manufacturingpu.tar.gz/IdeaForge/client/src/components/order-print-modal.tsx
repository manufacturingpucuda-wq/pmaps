import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Printer, X } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import type { OrderWithItems } from '@shared/schema';
import { formatDistanceToNow } from 'date-fns';

interface OrderPrintModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: OrderWithItems | null;
}

export function OrderPrintModal({ open, onOpenChange, order }: OrderPrintModalProps) {
  const { toast } = useToast();

  const handlePrint = () => {
    if (!order) return;

    const printContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Order ${order.orderNumber}</title>
          <style>
            @page { margin: 0.5in; }
            body {
              font-family: 'Arial', sans-serif;
              margin: 0;
              padding: 20px;
              background: white;
              color: black;
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
              border-bottom: 2px solid #333;
              padding-bottom: 15px;
            }
            .header h1 {
              margin: 0;
              font-size: 28px;
              color: #2563eb;
              font-weight: bold;
            }
            .header h2 {
              margin: 5px 0 0 0;
              font-size: 18px;
              color: #64748b;
            }
            .order-info {
              display: grid;
              grid-template-columns: 1fr 1fr;
              gap: 20px;
              margin-bottom: 30px;
            }
            .info-section {
              background: #f8fafc;
              padding: 15px;
              border-radius: 8px;
              border: 1px solid #e2e8f0;
            }
            .info-section h3 {
              margin: 0 0 10px 0;
              font-size: 14px;
              color: #1e293b;
              text-transform: uppercase;
              letter-spacing: 0.5px;
            }
            .info-section p {
              margin: 5px 0;
              font-size: 16px;
              color: #475569;
            }
            .items-section {
              margin-bottom: 30px;
            }
            .items-section h3 {
              margin: 0 0 15px 0;
              font-size: 18px;
              color: #1e293b;
            }
            .items-table {
              width: 100%;
              border-collapse: collapse;
              border: 1px solid #e2e8f0;
            }
            .items-table th,
            .items-table td {
              padding: 12px;
              text-align: left;
              border-bottom: 1px solid #e2e8f0;
            }
            .items-table th {
              background: #f1f5f9;
              font-weight: 600;
              color: #334155;
            }
            .items-table tr:nth-child(even) {
              background: #f8fafc;
            }
            .status-badge {
              display: inline-block;
              padding: 4px 8px;
              border-radius: 4px;
              font-size: 12px;
              font-weight: 500;
              text-transform: uppercase;
            }
            .status-pending { background: #fef3c7; color: #92400e; }
            .status-in-progress { background: #dbeafe; color: #1d4ed8; }
            .status-fulfilled { background: #d1fae5; color: #065f46; }
            .priority-standard { background: #f1f5f9; color: #475569; }
            .priority-high { background: #fef3c7; color: #92400e; }
            .priority-urgent { background: #fecaca; color: #991b1b; }
            @media print {
              body { padding: 10px; }
              .no-print { display: none; }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>PUCUDA MFG</h1>
            <h2>Order Fulfillment Sheet</h2>
          </div>
          
          <div class="order-info">
            <div class="info-section">
              <h3>Order Information</h3>
              <p><strong>Order Number:</strong> ${order.orderNumber}</p>
              <p><strong>Customer:</strong> ${order.customer}</p>
              <p><strong>Status:</strong> <span class="status-badge status-${order.status}">${order.status.toUpperCase()}</span></p>
              <p><strong>Priority:</strong> <span class="status-badge priority-${order.priority}">${order.priority.toUpperCase()}</span></p>
            </div>
            
            <div class="info-section">
              <h3>Order Details</h3>
              <p><strong>Created:</strong> ${order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Unknown'}</p>
              <p><strong>Assigned To:</strong> ${order.assignedTo || 'Unassigned'}</p>
              <p><strong>Progress:</strong> ${order.completionPercentage}%</p>
              <p><strong>Notes:</strong> ${order.notes || 'None'}</p>
            </div>
          </div>
          
          <div class="items-section">
            <h3>Items to Pick (${order.items.length} items)</h3>
            <table class="items-table">
              <thead>
                <tr>
                  <th>SKU</th>
                  <th>Product Name</th>
                  <th>Quantity</th>
                  <th>Unit Type</th>
                  <th>Location</th>
                  <th>✓ Picked</th>
                </tr>
              </thead>
              <tbody>
                ${order.items.map(orderItem => `
                  <tr>
                    <td><strong>${orderItem.item.sku}</strong></td>
                    <td>${orderItem.item.productName}</td>
                    <td><strong>${orderItem.quantity}</strong></td>
                    <td>${orderItem.item.unitType}</td>
                    <td>${orderItem.item.location || 'N/A'}</td>
                    <td style="width: 60px; text-align: center;">☐</td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
          
          <div style="margin-top: 40px; border-top: 1px solid #e2e8f0; padding-top: 20px;">
            <p style="text-align: center; color: #64748b; font-size: 12px;">
              Printed on ${new Date().toLocaleDateString()} | PUCUDA Manufacturing Inventory System
            </p>
          </div>
          
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                setTimeout(function() {
                  window.close();
                }, 1500);
              }, 800);
            };
          </script>
        </body>
      </html>
    `;

    try {
      const printWindow = window.open('', '_blank', 'width=800,height=600,scrollbars=yes,resizable=yes');
      
      if (!printWindow) {
        toast({
          title: 'Print Blocked',
          description: 'Please allow popups for this site and try again.',
          variant: 'destructive',
        });
        return;
      }

      printWindow.document.write(printContent);
      printWindow.document.close();
      
      toast({
        title: 'Order Sent to Printer',
        description: `Order ${order.orderNumber} pick sheet has been sent to the printer.`,
      });
      
      onOpenChange(false);
    } catch (error) {
      toast({
        title: 'Print Failed',
        description: 'Failed to print order. Please try again.',
        variant: 'destructive',
      });
    }
  };

  if (!order) return null;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'in-progress': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'fulfilled': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold flex items-center gap-2">
            <Printer className="h-5 w-5" />
            Print Order {order.orderNumber}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Order Summary */}
          <Card>
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Customer</p>
                  <p className="font-medium">{order.customer}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Created</p>
                  <p className="font-medium">{order.createdAt ? new Date(order.createdAt).toLocaleDateString() : 'Unknown'}</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Status</p>
                  <Badge className={getStatusColor(order.status)}>
                    {order.status.toUpperCase()}
                  </Badge>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Priority</p>
                  <Badge className={getPriorityColor(order.priority)}>
                    {order.priority.toUpperCase()}
                  </Badge>
                </div>
              </div>
              
              {order.notes && (
                <div className="mt-4">
                  <p className="text-sm text-muted-foreground">Notes</p>
                  <p className="text-sm">{order.notes}</p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Items Preview */}
          <div>
            <h3 className="font-medium mb-3">Items to Pick ({order.items.length})</h3>
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {order.items.map((orderItem, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-sm">{orderItem.item.sku}</p>
                    <p className="text-xs text-muted-foreground">{orderItem.item.productName}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-sm">{orderItem.quantity} {orderItem.item.unitType}</p>
                    <p className="text-xs text-muted-foreground">
                      {orderItem.item.location || 'No location'}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="flex justify-end gap-3">
            <Button
              variant="outline"
              onClick={() => onOpenChange(false)}
              data-testid="button-cancel-print"
            >
              <X className="h-4 w-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={handlePrint}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-confirm-print"
            >
              <Printer className="h-4 w-4 mr-2" />
              Print Pick Sheet
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}