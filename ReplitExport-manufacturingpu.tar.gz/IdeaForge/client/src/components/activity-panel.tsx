import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useActivity } from '@/hooks/use-activity';
import { useToast } from '@/hooks/use-toast';
import { Undo2, Clock, Trash2, User, Package, ShoppingCart } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

export function ActivityPanel() {
  const { activities, undoActivity, clearActivities } = useActivity();
  const { toast } = useToast();
  const [isUndoing, setIsUndoing] = useState<string | null>(null);

  const handleUndo = async (activityId: string) => {
    setIsUndoing(activityId);
    try {
      const success = await undoActivity(activityId);
      if (success) {
        toast({
          title: 'Action Undone',
          description: 'The action has been successfully reversed.',
        });
      } else {
        toast({
          title: 'Undo Failed',
          description: 'Unable to undo this action.',
          variant: 'destructive',
        });
      }
    } finally {
      setIsUndoing(null);
    }
  };

  const getEntityIcon = (entityType: string) => {
    switch (entityType) {
      case 'user': return <User className="h-4 w-4" />;
      case 'item': return <Package className="h-4 w-4" />;
      case 'order': return <ShoppingCart className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action.toLowerCase()) {
      case 'create': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'update': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'delete': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  if (activities.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Recent Activity
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center text-muted-foreground py-6">
            No recent activity to display
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Recent Activity ({activities.length})
          </CardTitle>
          {activities.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={clearActivities}
              className="text-muted-foreground"
              data-testid="button-clear-activity"
            >
              <Trash2 className="h-4 w-4 mr-2" />
              Clear All
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {activities.map((activity, index) => (
              <div key={activity.id}>
                <div className="flex items-start justify-between gap-3 p-3 rounded-lg bg-muted/50">
                  <div className="flex items-start gap-3 flex-1">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-background border">
                      {getEntityIcon(activity.entityType)}
                    </div>
                    
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <Badge className={getActionColor(activity.action)}>
                          {activity.action}
                        </Badge>
                        <Badge variant="outline">
                          {activity.entityType}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                        </span>
                      </div>
                      
                      <p className="text-sm text-foreground leading-relaxed">
                        {activity.description}
                      </p>
                    </div>
                  </div>

                  {activity.canUndo && activity.undoAction && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleUndo(activity.id)}
                      disabled={isUndoing === activity.id}
                      className="shrink-0"
                      data-testid={`button-undo-${activity.id}`}
                    >
                      <Undo2 className="h-4 w-4 mr-2" />
                      {isUndoing === activity.id ? 'Undoing...' : 'Undo'}
                    </Button>
                  )}
                </div>
                
                {index < activities.length - 1 && <Separator className="my-2" />}
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}