import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  Plus, 
  Package, 
  ShoppingCart, 
  BarChart3, 
  Download,
  Upload,
  Settings,
  Zap
} from "lucide-react";
import { Link } from "wouter";

interface QuickAction {
  title: string;
  description: string;
  icon: React.ReactNode;
  href?: string;
  onClick?: () => void;
  color: "blue" | "green" | "purple" | "orange";
}

const colorClasses = {
  blue: "bg-blue-50 text-blue-600 hover:bg-blue-100 dark:bg-blue-900/20 dark:text-blue-400 dark:hover:bg-blue-900/30",
  green: "bg-green-50 text-green-600 hover:bg-green-100 dark:bg-green-900/20 dark:text-green-400 dark:hover:bg-green-900/30",
  purple: "bg-purple-50 text-purple-600 hover:bg-purple-100 dark:bg-purple-900/20 dark:text-purple-400 dark:hover:bg-purple-900/30",
  orange: "bg-orange-50 text-orange-600 hover:bg-orange-100 dark:bg-orange-900/20 dark:text-orange-400 dark:hover:bg-orange-900/30",
};

export function QuickActions() {
  const actions: QuickAction[] = [
    {
      title: "Add New Item",
      description: "Add products to inventory",
      icon: <Plus className="h-5 w-5" />,
      href: "/inventory/add",
      color: "blue",
    },
    {
      title: "Create Order",
      description: "Start new order process",
      icon: <ShoppingCart className="h-5 w-5" />,
      href: "/orders/new",
      color: "green",
    },
    {
      title: "View Analytics",
      description: "Check performance metrics",
      icon: <BarChart3 className="h-5 w-5" />,
      href: "/analytics",
      color: "purple",
    },
    {
      title: "Export Data",
      description: "Download inventory reports",
      icon: <Download className="h-5 w-5" />,
      onClick: () => {
        // TODO: Implement export functionality
        alert("Export feature coming soon!");
      },
      color: "orange",
    },
    {
      title: "Import Items",
      description: "Bulk upload inventory",
      icon: <Upload className="h-5 w-5" />,
      onClick: () => {
        // TODO: Implement import functionality
        alert("Import feature coming soon!");
      },
      color: "blue",
    },
    {
      title: "System Settings",
      description: "Configure system preferences",
      icon: <Settings className="h-5 w-5" />,
      href: "/settings",
      color: "green",
    },
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Zap className="h-5 w-5 text-yellow-500" />
          <span>Quick Actions</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-4">
          {actions.map((action, index) => (
            <div key={index}>
              {action.href ? (
                <Link href={action.href}>
                  <Button
                    variant="ghost"
                    className={`w-full h-auto p-4 flex flex-col items-center space-y-2 ${colorClasses[action.color]} transition-all duration-200 hover:scale-105`}
                    data-testid={`button-quick-action-${action.title.toLowerCase().replace(/\s+/g, '-')}`}
                  >
                    {action.icon}
                    <div className="text-center">
                      <div className="font-medium text-sm">{action.title}</div>
                      <div className="text-xs opacity-75">{action.description}</div>
                    </div>
                  </Button>
                </Link>
              ) : (
                <Button
                  variant="ghost"
                  onClick={action.onClick}
                  className={`w-full h-auto p-4 flex flex-col items-center space-y-2 ${colorClasses[action.color]} transition-all duration-200 hover:scale-105`}
                  data-testid={`button-quick-action-${action.title.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  {action.icon}
                  <div className="text-center">
                    <div className="font-medium text-sm">{action.title}</div>
                    <div className="text-xs opacity-75">{action.description}</div>
                  </div>
                </Button>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}