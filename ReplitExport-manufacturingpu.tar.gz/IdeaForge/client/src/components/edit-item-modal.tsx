import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useUpdateItem } from "@/hooks/use-inventory";
import { useToast } from "@/hooks/use-toast";
import { updateItemSchema, type UpdateItem, type ItemWithStatus } from "@shared/schema";
import { useEffect } from "react";

interface EditItemModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: ItemWithStatus | null;
}

export function EditItemModal({ open, onOpenChange, item }: EditItemModalProps) {
  const updateItem = useUpdateItem();
  const { toast } = useToast();

  const form = useForm<UpdateItem>({
    resolver: zodResolver(updateItemSchema),
    defaultValues: {
      sku: "",
      productName: "",
      currentStock: 0,
      barcode: "",
    },
  });

  // Reset form when item changes
  useEffect(() => {
    if (item && open) {
      form.reset({
        sku: item.sku,
        productName: item.productName,
        currentStock: item.currentStock,
        unitType: item.unitType,
        barcode: item.barcode || "",
      });
    }
  }, [item, open, form]);

  const onSubmit = async (data: UpdateItem) => {
    if (!item) return;
    
    try {
      await updateItem.mutateAsync({ id: item.id, data });
      toast({
        title: "Success",
        description: "Item updated successfully",
      });
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update item",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-md mx-4" data-testid="modal-edit-item">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-foreground">
            Edit Item: {item?.sku}
          </DialogTitle>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="sku"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    SKU
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      className="w-full"
                      data-testid="input-edit-item-sku"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="productName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Product Name
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      className="w-full"
                      data-testid="input-edit-item-name"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="barcode"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Barcode
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      value={field.value || ""}
                      className="w-full"
                      data-testid="input-edit-item-barcode"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="unitType"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Unit of Measure
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      value={field.value || ""}
                      placeholder="e.g., pieces, boxes, liters, kg"
                      className="w-full"
                      data-testid="input-edit-item-unit-type"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="currentStock"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Current Stock
                  </FormLabel>
                  <FormControl>
                    <Input 
                      type="number"
                      {...field}
                      value={field.value || ""}
                      onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                      className="w-full"
                      data-testid="input-edit-item-stock"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel-edit"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={updateItem.isPending}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-save-edit"
              >
                {updateItem.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}