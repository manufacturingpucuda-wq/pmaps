import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Package, 
  ShoppingCart, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  User
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface ActivityItem {
  id: string;
  type: 'order_created' | 'order_fulfilled' | 'item_added' | 'low_stock' | 'user_login';
  title: string;
  description: string;
  timestamp: Date;
  user?: string;
  metadata?: Record<string, any>;
}

interface ActivityFeedProps {
  activities: ActivityItem[];
  className?: string;
}

const activityIcons = {
  order_created: ShoppingCart,
  order_fulfilled: CheckCircle,
  item_added: Package,
  low_stock: AlertTriangle,
  user_login: User,
};

const activityColors = {
  order_created: "bg-blue-100 text-blue-600 dark:bg-blue-900 dark:text-blue-300",
  order_fulfilled: "bg-green-100 text-green-600 dark:bg-green-900 dark:text-green-300",
  item_added: "bg-purple-100 text-purple-600 dark:bg-purple-900 dark:text-purple-300",
  low_stock: "bg-yellow-100 text-yellow-600 dark:bg-yellow-900 dark:text-yellow-300",
  user_login: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300",
};

export function ActivityFeed({ activities, className }: ActivityFeedProps) {
  return (
    <Card className={className}>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Clock className="h-5 w-5" />
          <span>Recent Activity</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Clock className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>No recent activity</p>
          </div>
        ) : (
          activities.map((activity) => {
            const Icon = activityIcons[activity.type];
            return (
              <div key={activity.id} className="flex items-start space-x-4 group">
                <div className={`p-2 rounded-full ${activityColors[activity.type]} transition-transform group-hover:scale-110`}>
                  <Icon className="h-4 w-4" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-sm font-medium text-foreground truncate">
                      {activity.title}
                    </p>
                    <Badge variant="outline" className="text-xs">
                      {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">
                    {activity.description}
                  </p>
                  {activity.user && (
                    <div className="flex items-center space-x-2">
                      <Avatar className="h-6 w-6">
                        <AvatarFallback className="text-xs">
                          {activity.user.slice(0, 2).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <span className="text-xs text-muted-foreground">{activity.user}</span>
                    </div>
                  )}
                </div>
              </div>
            );
          })
        )}
      </CardContent>
    </Card>
  );
}