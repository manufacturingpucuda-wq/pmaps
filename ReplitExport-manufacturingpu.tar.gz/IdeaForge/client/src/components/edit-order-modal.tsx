import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { useUpdateOrder } from "@/hooks/use-orders";
import { useToast } from "@/hooks/use-toast";
import { updateOrderSchema, type UpdateOrder, type OrderWithItems } from "@shared/schema";
import { useEffect } from "react";

interface EditOrderModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  order: OrderWithItems | null;
}

export function EditOrderModal({ open, onOpenChange, order }: EditOrderModalProps) {
  const updateOrder = useUpdateOrder();
  const { toast } = useToast();

  const form = useForm<UpdateOrder>({
    resolver: zodResolver(updateOrderSchema),
    defaultValues: {
      orderNumber: "",
      customer: "",
      priority: "standard",
      assignedTo: "",
      completionPercentage: 0,
      notes: "",
    },
  });

  // Reset form when order changes
  useEffect(() => {
    if (order && open) {
      form.reset({
        orderNumber: order.orderNumber,
        customer: order.customer,
        priority: order.priority,
        assignedTo: order.assignedTo || "",
        completionPercentage: order.completionPercentage || 0,
        notes: order.notes || "",
      });
    }
  }, [order, open, form]);

  const onSubmit = async (data: UpdateOrder) => {
    if (!order) return;
    
    try {
      await updateOrder.mutateAsync({ id: order.id, data });
      toast({
        title: "Success",
        description: "Order updated successfully",
      });
      onOpenChange(false);
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update order",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="w-full max-w-md mx-4" data-testid="modal-edit-order">
        <DialogHeader>
          <DialogTitle className="text-lg font-semibold text-foreground">
            Edit Order: {order?.orderNumber}
          </DialogTitle>
          <DialogDescription>
            Update order details including priority, assignment, and completion status.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="orderNumber"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Order Number
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      className="w-full"
                      data-testid="input-edit-order-number"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="customer"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Customer
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      className="w-full"
                      data-testid="input-edit-order-customer"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-muted-foreground">
                      Priority
                    </FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-edit-order-priority">
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="standard">Standard</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                        <SelectItem value="urgent">Urgent</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="completionPercentage"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="text-sm font-medium text-muted-foreground">
                      Completion %
                    </FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        min="0"
                        max="100"
                        {...field}
                        value={field.value || ""}
                        onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        className="w-full"
                        data-testid="input-edit-order-completion"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="assignedTo"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Assigned To
                  </FormLabel>
                  <FormControl>
                    <Input 
                      {...field} 
                      value={field.value || ""}
                      placeholder="Enter employee name"
                      className="w-full"
                      data-testid="input-edit-order-assigned"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-muted-foreground">
                    Notes
                  </FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      value={field.value || ""}
                      placeholder="Order notes..."
                      className="w-full resize-none"
                      rows={3}
                      data-testid="textarea-edit-order-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => onOpenChange(false)}
                data-testid="button-cancel-edit-order"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={updateOrder.isPending}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-save-edit-order"
              >
                {updateOrder.isPending ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}