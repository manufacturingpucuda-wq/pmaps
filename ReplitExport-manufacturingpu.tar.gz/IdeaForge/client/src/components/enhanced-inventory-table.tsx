import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Edit, 
  Barcode, 
  Trash2, 
  MoreHorizontal, 
  Search, 
  Filter,
  Download,
  Eye,
  Package
} from "lucide-react";
import type { ItemWithStatus } from "@shared/schema";
import { cn } from "@/lib/utils";

interface EnhancedInventoryTableProps {
  items: ItemWithStatus[];
  isLoading: boolean;
  onDelete: (id: string) => void;
  onShowBarcode: (item: ItemWithStatus) => void;
  onEdit?: (item: ItemWithStatus) => void;
  searchTerm?: string;
  onSearchChange?: (term: string) => void;
}

export function EnhancedInventoryTable({ 
  items, 
  isLoading, 
  onDelete, 
  onShowBarcode, 
  onEdit,
  searchTerm = "",
  onSearchChange
}: EnhancedInventoryTableProps) {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [sortField, setSortField] = useState<string>("productName");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const toggleSelectAll = () => {
    if (selectedItems.size === items.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(items.map(item => item.id)));
    }
  };

  const toggleSelectItem = (id: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const getStatusBadge = (item: ItemWithStatus) => {
    const lowStockThreshold = 10;
    const outOfStock = item.currentStock === 0;
    const lowStock = item.currentStock <= lowStockThreshold && !outOfStock;
    
    if (outOfStock) {
      return <Badge variant="destructive" className="animate-pulse">Out of Stock</Badge>;
    }
    if (lowStock) {
      return <Badge variant="secondary" className="bg-yellow-500 text-white">Low Stock</Badge>;
    }
    return <Badge variant="default" className="bg-green-500 text-white">In Stock</Badge>;
  };

  const sortedItems = [...items].sort((a, b) => {
    const aValue = a[sortField as keyof ItemWithStatus];
    const bValue = b[sortField as keyof ItemWithStatus];
    
    const comparison = String(aValue).localeCompare(String(bValue));
    return sortDirection === "asc" ? comparison : -comparison;
  });

  const filteredItems = sortedItems.filter(item =>
    item.productName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    item.sku.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            <span className="ml-3 text-muted-foreground">Loading inventory...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      {/* Enhanced Header */}
      <div className="border-b bg-muted/50 p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Package className="h-5 w-5 text-primary" />
            <h3 className="text-lg font-semibold">Inventory Items</h3>
            <Badge variant="outline">{filteredItems.length} items</Badge>
          </div>
          
          {selectedItems.size > 0 && (
            <div className="flex items-center space-x-2">
              <Badge variant="secondary">{selectedItems.size} selected</Badge>
              <Button size="sm" variant="destructive" onClick={() => {
                selectedItems.forEach(id => onDelete(id));
                setSelectedItems(new Set());
              }}>
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Selected
              </Button>
            </div>
          )}
        </div>
        
        {/* Search and Filters */}
        <div className="flex items-center space-x-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or SKU..."
              value={searchTerm}
              onChange={(e) => onSearchChange?.(e.target.value)}
              className="pl-10"
              data-testid="input-inventory-search"
            />
          </div>
          <Button variant="outline" size="sm">
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <CardContent className="p-0">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader className="bg-muted/30">
              <TableRow>
                <TableHead className="w-12">
                  <Checkbox
                    checked={selectedItems.size === filteredItems.length && filteredItems.length > 0}
                    onCheckedChange={toggleSelectAll}
                    data-testid="checkbox-select-all"
                  />
                </TableHead>
                <TableHead className="font-semibold">SKU</TableHead>
                <TableHead className="font-semibold">Product Name</TableHead>
                <TableHead className="font-semibold">Current Stock</TableHead>
                <TableHead className="font-semibold">Unit Type</TableHead>
                <TableHead className="font-semibold">Status</TableHead>
                <TableHead className="font-semibold">Barcode</TableHead>
                <TableHead className="w-24 font-semibold">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredItems.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={8} className="text-center py-12">
                    <Package className="h-12 w-12 mx-auto mb-4 text-muted-foreground opacity-50" />
                    <p className="text-muted-foreground">
                      {searchTerm ? "No items match your search" : "No inventory items found"}
                    </p>
                  </TableCell>
                </TableRow>
              ) : (
                filteredItems.map((item, index) => (
                  <TableRow 
                    key={item.id} 
                    className={cn(
                      "hover:bg-muted/50 transition-colors",
                      selectedItems.has(item.id) && "bg-primary/5"
                    )}
                    data-testid={`row-inventory-item-${index}`}
                  >
                    <TableCell>
                      <Checkbox
                        checked={selectedItems.has(item.id)}
                        onCheckedChange={() => toggleSelectItem(item.id)}
                        data-testid={`checkbox-item-${index}`}
                      />
                    </TableCell>
                    <TableCell className="font-mono font-medium text-primary">
                      {item.sku}
                    </TableCell>
                    <TableCell className="font-medium max-w-xs truncate">
                      {item.productName}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center space-x-2">
                        <span className={cn(
                          "font-semibold",
                          item.currentStock === 0 
                            ? "text-red-600" 
                            : item.currentStock <= 10 
                            ? "text-yellow-600" 
                            : "text-green-600"
                        )}>
                          {item.currentStock}
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline" className="text-xs">
                        {item.unitType || 'pieces'}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {getStatusBadge(item)}
                    </TableCell>
                    <TableCell>
                      {item.barcode ? (
                        <Badge variant="secondary" className="font-mono text-xs">
                          {item.barcode}
                        </Badge>
                      ) : (
                        <span className="text-muted-foreground text-xs">No barcode</span>
                      )}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button 
                            variant="ghost" 
                            size="sm"
                            className="h-8 w-8 p-0 hover:bg-muted"
                            data-testid={`button-actions-${index}`}
                          >
                            <MoreHorizontal className="h-4 w-4" />
                            <span className="sr-only">Open menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-48">
                          <DropdownMenuItem onClick={() => onShowBarcode(item)}>
                            <Barcode className="h-4 w-4 mr-2" />
                            Show Barcode
                          </DropdownMenuItem>
                          {onEdit && (
                            <DropdownMenuItem onClick={() => onEdit(item)}>
                              <Edit className="h-4 w-4 mr-2" />
                              Edit Item
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuItem onClick={() => onDelete(item.id)} className="text-red-600">
                            <Trash2 className="h-4 w-4 mr-2" />
                            Delete Item
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}