import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Bot, Send, User, X, Minimize2, Maximize2, HelpCircle, Package, Truck, ClipboardList, BarChart3, Settings } from "lucide-react";

interface Message {
  id: string;
  content: string;
  sender: "user" | "assistant";
  timestamp: Date;
  suggestions?: string[];
}

interface AssistantProps {
  isOpen: boolean;
  onToggle: () => void;
  onClose: () => void;
}

// Knowledge base for warehouse operations
const knowledgeBase = {
  inventory: {
    keywords: ["inventory", "stock", "item", "product", "add", "create", "update", "edit", "delete", "remove", "barcode", "sku"],
    responses: [
      "To add new inventory items, go to the Inventory page and click 'Add New Item'. Fill in the SKU, product name, stock quantity, and other details.",
      "You can scan barcodes to quickly find items. Use the barcode scanner on any inventory page.",
      "To check stock levels, visit the Inventory page where you'll see current stock, reserved stock, and availability status.",
      "Low stock items are automatically highlighted in red. You can set reorder points for each item.",
      "To edit an item, click the edit button next to any inventory item and update the information."
    ]
  },
  orders: {
    keywords: ["order", "checkout", "customer", "fulfill", "ship", "work order", "create order"],
    responses: [
      "To create a new order, use the 'Create Order' button and select items for your customer.",
      "For complex projects, use 'Custom Work Order' to add detailed tasks, materials, and scheduling.",
      "You can check out items to existing orders or create new ones during the checkout process.",
      "Track order progress on the Orders page where you can see status, completion percentage, and assigned workers.",
      "Orders can be marked as fulfilled once all items are ready for shipment."
    ]
  },
  transactions: {
    keywords: ["check-in", "check-out", "transaction", "history", "track", "who", "user", "return", "log"],
    responses: [
      "All inventory transactions are tracked with user accountability. You can see who checked items in or out.",
      "To check items back in, use the check-in feature and specify the quantity being returned.",
      "Transaction history shows complete details: user, date, time, quantity, and notes for every item movement.",
      "You can add notes to transactions to explain the reason for check-in or check-out operations."
    ]
  },
  reports: {
    keywords: ["report", "analytics", "print", "summary", "data", "statistics", "export"],
    responses: [
      "Access comprehensive reports through the Reports button on the dashboard.",
      "Available reports include: Inventory Summary, Order History, Transaction Log, and System Analytics.",
      "All reports can be printed directly or viewed on screen with real-time data.",
      "Use the Fillable Forms feature for printable warehouse documents like inventory count sheets."
    ]
  },
  system: {
    keywords: ["help", "login", "user", "scan", "barcode scanner", "settings", "how to", "guide"],
    responses: [
      "Login by scanning your employee ID barcode - no buttons or forms needed, just scan and you're in.",
      "The system tracks who performs each action for complete accountability.",
      "Use barcode scanners throughout the system for quick item lookup and transaction processing.",
      "Your role (admin/manager/worker) determines what features you can access.",
      "For technical issues, check that barcode scanners are properly connected and focused on input fields."
    ]
  }
};

// Quick action suggestions
const quickActions = [
  { label: "How to add inventory?", icon: Package },
  { label: "Create a work order", icon: ClipboardList },
  { label: "Check item history", icon: BarChart3 },
  { label: "Print reports", icon: HelpCircle },
  { label: "Checkout process", icon: Truck },
  { label: "System settings", icon: Settings }
];

export function AIAssistant({ isOpen, onToggle, onClose }: AssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      content: "Hello! I'm your warehouse assistant. I can help you with inventory management, order processing, reports, and system guidance. What would you like to know?",
      sender: "assistant",
      timestamp: new Date(),
      suggestions: ["How to add inventory?", "Create a work order", "Check item history", "Print reports"]
    }
  ]);
  const [input, setInput] = useState("");
  const [isMinimized, setIsMinimized] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeQuery = (query: string): { category: string; confidence: number; response: string } => {
    const lowerQuery = query.toLowerCase();
    let bestMatch = { category: "general", confidence: 0, response: "" };

    // Check each knowledge category
    Object.entries(knowledgeBase).forEach(([category, data]) => {
      const matchedKeywords = data.keywords.filter(keyword => 
        lowerQuery.includes(keyword.toLowerCase())
      );
      
      if (matchedKeywords.length > 0) {
        const confidence = matchedKeywords.length / data.keywords.length;
        if (confidence > bestMatch.confidence) {
          bestMatch = {
            category,
            confidence,
            response: data.responses[Math.floor(Math.random() * data.responses.length)]
          };
        }
      }
    });

    // Fallback responses for general queries
    if (bestMatch.confidence === 0) {
      const generalResponses = [
        "I can help you with inventory management, order processing, transaction tracking, and system guidance. What specific task would you like help with?",
        "Try asking about: adding inventory items, creating orders, checking transaction history, or printing reports.",
        "I'm here to guide you through warehouse operations. What would you like to learn about?"
      ];
      bestMatch.response = generalResponses[Math.floor(Math.random() * generalResponses.length)];
    }

    return bestMatch;
  };

  const generateSuggestions = (category: string): string[] => {
    const suggestions: Record<string, string[]> = {
      inventory: ["How to edit items?", "Set reorder points", "Scan barcodes", "Check stock levels"],
      orders: ["Track order progress", "Fulfill orders", "Add items to order", "Work order details"],
      transactions: ["View transaction history", "Check-in items", "User accountability", "Add transaction notes"],
      reports: ["Print inventory report", "Export data", "View analytics", "Fillable forms"],
      system: ["Barcode scanner setup", "User permissions", "Login issues", "System features"],
      general: ["How to add inventory?", "Create a work order", "Print reports", "Check item history"]
    };
    
    return suggestions[category] || suggestions.general;
  };

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      content: input,
      sender: "user",
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    // Analyze query and generate response
    const analysis = analyzeQuery(input);
    const suggestions = generateSuggestions(analysis.category);

    setTimeout(() => {
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        content: analysis.response,
        sender: "assistant",
        timestamp: new Date(),
        suggestions: suggestions.slice(0, 4)
      };
      setMessages(prev => [...prev, assistantMessage]);
    }, 1000);

    setInput("");
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    handleSend();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Card className={`w-96 shadow-2xl border-2 border-blue-200 transition-all duration-300 ${isMinimized ? 'h-16' : 'h-[600px]'}`}>
        <CardHeader className="pb-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg flex items-center">
              <Bot className="h-5 w-5 mr-2" />
              Warehouse Assistant
              <Badge variant="secondary" className="ml-2 bg-white/20 text-white">
                AI Powered
              </Badge>
            </CardTitle>
            <div className="flex space-x-1">
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
                onClick={() => setIsMinimized(!isMinimized)}
              >
                {isMinimized ? <Maximize2 className="h-3 w-3" /> : <Minimize2 className="h-3 w-3" />}
              </Button>
              <Button 
                size="sm" 
                variant="ghost" 
                className="h-6 w-6 p-0 text-white hover:bg-white/20"
                onClick={onClose}
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
          </div>
        </CardHeader>

        {!isMinimized && (
          <CardContent className="p-0 flex flex-col h-[540px]">
            {/* Messages */}
            <ScrollArea className="flex-1 p-4">
              <div className="space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div className={`flex items-start space-x-2 max-w-[80%] ${message.sender === "user" ? "flex-row-reverse space-x-reverse" : ""}`}>
                      <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                        message.sender === "user" 
                          ? "bg-blue-500 text-white" 
                          : "bg-gradient-to-r from-purple-500 to-blue-500 text-white"
                      }`}>
                        {message.sender === "user" ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
                      </div>
                      <div className={`p-3 rounded-lg ${
                        message.sender === "user"
                          ? "bg-blue-500 text-white rounded-br-sm"
                          : "bg-gray-100 text-gray-800 rounded-bl-sm"
                      }`}>
                        <p className="text-sm">{message.content}</p>
                        <span className="text-xs opacity-70 mt-1 block">
                          {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* Suggestions */}
                {messages.length > 0 && messages[messages.length - 1].sender === "assistant" && messages[messages.length - 1].suggestions && (
                  <div className="flex flex-wrap gap-2 mt-4">
                    {messages[messages.length - 1].suggestions!.map((suggestion, index) => (
                      <Button
                        key={index}
                        size="sm"
                        variant="outline"
                        className="text-xs h-7 px-2 bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
                        onClick={() => handleSuggestionClick(suggestion)}
                      >
                        {suggestion}
                      </Button>
                    ))}
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
            </ScrollArea>

            {/* Quick Actions */}
            <div className="px-4 py-2 border-t bg-gray-50">
              <p className="text-xs text-gray-500 mb-2">Quick Actions:</p>
              <div className="flex flex-wrap gap-1">
                {quickActions.slice(0, 4).map((action, index) => (
                  <Button
                    key={index}
                    size="sm"
                    variant="ghost"
                    className="text-xs h-6 px-2 text-gray-600 hover:bg-blue-100"
                    onClick={() => handleSuggestionClick(action.label)}
                  >
                    <action.icon className="h-3 w-3 mr-1" />
                    {action.label}
                  </Button>
                ))}
              </div>
            </div>

            {/* Input */}
            <div className="p-4 border-t">
              <div className="flex space-x-2">
                <Input
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  placeholder="Ask me about warehouse operations..."
                  className="flex-1 text-sm"
                  data-testid="input-ai-assistant"
                />
                <Button onClick={handleSend} size="sm" className="px-3">
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </div>
  );
}