import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { WidgetContainer, type Widget } from "./widget-container";
import { WidgetLibrary, widgetTemplates, type WidgetTemplate } from "./widget-library";
import { StatsWidget } from "./widget-types/stats-widget";
import { ChartWidget } from "./widget-types/chart-widget";
import { ListWidget } from "./widget-types/list-widget";
import { ActivityFeed } from "../activity-feed";
import { QuickActions } from "../quick-actions";
import { Plus, Settings, RotateCcw, Save } from "lucide-react";
import { cn } from "@/lib/utils";

interface DashboardWidgetsProps {
  className?: string;
}

const defaultWidgets: Widget[] = [
  {
    id: '1',
    type: 'stats',
    title: 'Total Items',
    size: 'small',
    position: { x: 0, y: 0 },
    config: { metric: 'totalItems' }
  },
  {
    id: '2',
    type: 'stats', 
    title: 'Active Orders',
    size: 'small',
    position: { x: 1, y: 0 },
    config: { metric: 'activeOrders' }
  },
  {
    id: '3',
    type: 'chart',
    title: 'Sales Trend',
    size: 'large',
    position: { x: 0, y: 1 },
    config: { chartType: 'line', period: '30d' }
  },
  {
    id: '4',
    type: 'list',
    title: 'Low Stock Items',
    size: 'medium',
    position: { x: 2, y: 0 },
    config: { type: 'low-stock', limit: 5, threshold: 10 }
  }
];

export function DashboardWidgets({ className }: DashboardWidgetsProps) {
  const [widgets, setWidgets] = useState<Widget[]>(() => {
    const saved = localStorage.getItem('dashboard-widgets');
    return saved ? JSON.parse(saved) : defaultWidgets;
  });
  const [isEditMode, setIsEditMode] = useState(false);
  const [showLibrary, setShowLibrary] = useState(false);

  // Save widgets to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('dashboard-widgets', JSON.stringify(widgets));
  }, [widgets]);

  const addWidget = (template: WidgetTemplate) => {
    const newWidget: Widget = {
      id: Date.now().toString(),
      type: template.type,
      title: template.title,
      size: template.defaultSize,
      position: { x: 0, y: 0 },
      config: template.defaultConfig
    };
    setWidgets(prev => [...prev, newWidget]);
  };

  const removeWidget = (id: string) => {
    setWidgets(prev => prev.filter(w => w.id !== id));
  };

  const resizeWidget = (id: string, size: Widget['size']) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, size } : w
    ));
  };

  const moveWidget = (id: string, position: { x: number; y: number }) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, position } : w
    ));
  };

  const configureWidget = (id: string, config: Record<string, any>) => {
    setWidgets(prev => prev.map(w => 
      w.id === id ? { ...w, config: { ...w.config, ...config } } : w
    ));
  };

  const resetToDefault = () => {
    setWidgets(defaultWidgets);
    setIsEditMode(false);
  };

  const renderWidget = (widget: Widget) => {
    switch (widget.type) {
      case 'stats':
        return <StatsWidget config={{...widget.config, metric: widget.config.metric || 'totalItems'}} />;
      case 'chart':
        return <ChartWidget config={{...widget.config, chartType: widget.config.chartType || 'line', period: widget.config.period || '30d'}} />;
      case 'list':
        return <ListWidget config={{...widget.config, type: widget.config.type || 'low-stock'}} />;
      case 'activity':
        // Generate sample activity data
        const sampleActivities = [
          {
            id: '1',
            type: 'order_created' as const,
            title: 'New Order Created',
            description: 'Order #12345 created for Customer ABC',
            timestamp: new Date(Date.now() - 30 * 60 * 1000),
            user: 'System'
          }
        ];
        return <ActivityFeed activities={sampleActivities} className="h-full" />;
      case 'quick-actions':
        return <QuickActions />;
      default:
        return <div>Unknown widget type: {widget.type}</div>;
    }
  };

  return (
    <div className={cn("space-y-6", className)}>
      {/* Widget Controls */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <h2 className="text-lg font-semibold">Dashboard</h2>
          <Badge variant={isEditMode ? "default" : "outline"}>
            {isEditMode ? "Edit Mode" : "View Mode"}
          </Badge>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowLibrary(true)}
            data-testid="button-add-widget"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Widget
          </Button>
          
          <Button
            variant={isEditMode ? "default" : "outline"}
            size="sm"
            onClick={() => setIsEditMode(!isEditMode)}
            data-testid="button-edit-mode"
          >
            <Settings className="h-4 w-4 mr-2" />
            {isEditMode ? "Done" : "Edit"}
          </Button>
          
          {isEditMode && (
            <Button
              variant="outline"
              size="sm"
              onClick={resetToDefault}
              data-testid="button-reset-widgets"
            >
              <RotateCcw className="h-4 w-4 mr-2" />
              Reset
            </Button>
          )}
        </div>
      </div>

      {/* Widget Grid */}
      <div 
        className={cn(
          "grid auto-rows-fr gap-6",
          "grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4",
          isEditMode && "p-4 border-2 border-dashed border-primary/30 rounded-lg bg-primary/5"
        )}
        data-testid="widget-grid"
      >
        {widgets.length === 0 ? (
          <Card className="col-span-full">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Plus className="h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Widgets</h3>
              <p className="text-muted-foreground text-center mb-4">
                Add widgets to customize your dashboard
              </p>
              <Button onClick={() => setShowLibrary(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Your First Widget
              </Button>
            </CardContent>
          </Card>
        ) : (
          widgets.map(widget => (
            <WidgetContainer
              key={widget.id}
              widget={widget}
              onRemove={removeWidget}
              onResize={resizeWidget}
              onMove={moveWidget}
              onConfigChange={configureWidget}
              isEditMode={isEditMode}
            >
              {renderWidget(widget)}
            </WidgetContainer>
          ))
        )}
      </div>

      {/* Edit Mode Helper */}
      {isEditMode && (
        <Card className="border-primary">
          <CardContent className="p-4">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-primary rounded-full"></div>
                <span className="text-sm font-medium">Edit Mode Active</span>
              </div>
              <div className="text-sm text-muted-foreground">
                • Drag widgets to reorder • Click resize button to change size • Use menu to remove widgets
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Widget Library Modal */}
      <WidgetLibrary
        isOpen={showLibrary}
        onClose={() => setShowLibrary(false)}
        onAddWidget={addWidget}
      />
    </div>
  );
}