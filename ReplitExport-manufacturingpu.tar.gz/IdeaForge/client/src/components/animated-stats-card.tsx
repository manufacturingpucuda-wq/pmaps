import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface AnimatedStatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: {
    value: number;
    label: string;
  };
  color?: "blue" | "green" | "yellow" | "red";
  delay?: number;
}

export function AnimatedStatsCard({ 
  title, 
  value, 
  icon, 
  trend, 
  color = "blue",
  delay = 0
}: AnimatedStatsCardProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [animatedValue, setAnimatedValue] = useState(0);

  const colorClasses = {
    blue: "from-blue-500 to-blue-600 text-blue-100",
    green: "from-green-500 to-green-600 text-green-100", 
    yellow: "from-yellow-500 to-yellow-600 text-yellow-100",
    red: "from-red-500 to-red-600 text-red-100",
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
      
      // Animate number counting
      if (typeof value === 'number') {
        let current = 0;
        const increment = value / 30;
        const counter = setInterval(() => {
          current += increment;
          if (current >= value) {
            setAnimatedValue(value);
            clearInterval(counter);
          } else {
            setAnimatedValue(Math.floor(current));
          }
        }, 50);
      }
    }, delay);

    return () => clearTimeout(timer);
  }, [value, delay]);

  return (
    <Card className={cn(
      "overflow-hidden transition-all duration-700 hover:shadow-lg hover:-translate-y-1",
      isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-4"
    )}>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
          {title}
          <div className={cn(
            "p-2 rounded-lg bg-gradient-to-r",
            colorClasses[color]
          )}>
            {icon}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="flex items-baseline space-x-3">
          <div className="text-3xl font-bold text-foreground">
            {typeof value === 'number' ? animatedValue.toLocaleString() : value}
          </div>
          {trend && (
            <div className={cn(
              "text-xs px-2 py-1 rounded-full",
              trend.value > 0 
                ? "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200"
                : trend.value < 0
                ? "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200"
                : "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200"
            )}>
              {trend.value > 0 ? "+" : ""}{trend.value}% {trend.label}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}