import React, { useState, useRef } from "react";
import { useForm } from "react-hook-form";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { FileText, Printer, Calendar, User, Package, Download, Eye, Save } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

interface FillableFormsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface InventoryCountForm {
  date: string;
  countedBy: string;
  department: string;
  notes: string;
  items: Array<{
    sku: string;
    description: string;
    expectedQty: number;
    actualQty: number;
    variance: number;
  }>;
}

interface ReceivingForm {
  date: string;
  receivedBy: string;
  supplier: string;
  poNumber: string;
  notes: string;
  items: Array<{
    sku: string;
    description: string;
    quantityReceived: number;
    condition: string;
  }>;
}

export function FillableFormsModal({ isOpen, onClose }: FillableFormsModalProps) {
  const [selectedForm, setSelectedForm] = useState<string>("inventory-count");
  const [showPreview, setShowPreview] = useState(false);
  const [pdfBlob, setPdfBlob] = useState<Blob | null>(null);
  const formRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // State for table inputs
  const [tableInputs, setTableInputs] = useState<Record<string, string>>({});

  // Handle table input changes
  const handleTableInputChange = (name: string, value: string) => {
    setTableInputs(prev => ({
      ...prev,
      [name]: value
    }));
    // Clear PDF blob when data changes
    setPdfBlob(null);
  };

  // Reset form data when modal opens/closes
  React.useEffect(() => {
    if (!isOpen) {
      setTableInputs({});
      setPdfBlob(null);
      setShowPreview(false);
    }
  }, [isOpen]);

  const inventoryForm = useForm<InventoryCountForm>({
    defaultValues: {
      date: format(new Date(), "yyyy-MM-dd"),
      countedBy: "",
      department: "",
      notes: "",
      items: [],
    },
  });

  const receivingForm = useForm<ReceivingForm>({
    defaultValues: {
      date: format(new Date(), "yyyy-MM-dd"),
      receivedBy: "",
      supplier: "",
      poNumber: "",
      notes: "",
      items: [],
    },
  });

  const addInventoryItem = () => {
    const currentItems = inventoryForm.getValues("items");
    inventoryForm.setValue("items", [
      ...currentItems,
      { sku: "", description: "", expectedQty: 0, actualQty: 0, variance: 0 }
    ]);
  };

  const addReceivingItem = () => {
    const currentItems = receivingForm.getValues("items");
    receivingForm.setValue("items", [
      ...currentItems,
      { sku: "", description: "", quantityReceived: 0, condition: "Good" }
    ]);
  };

  const generatePDF = async () => {
    if (!formRef.current) return;

    try {
      toast({
        title: "Generating PDF...",
        description: "Creating fillable PDF document",
      });

      // Dynamic import to avoid bundling issues
      const html2pdf = (await import('html2pdf.js' as any)).default;
      
      // Get form data to create fillable content
      const formData = selectedForm === "inventory-count" 
        ? inventoryForm.getValues() 
        : receivingForm.getValues();

      // Clone the form element for PDF generation
      const element = formRef.current.cloneNode(true) as HTMLElement;
      
      // Fill in the form values in the cloned element
      const inputs = element.querySelectorAll('input, textarea, select');
      inputs.forEach((input: any) => {
        if (input.name) {
          // Check table inputs first, then form data
          const value = tableInputs[input.name] || formData[input.name as keyof typeof formData];
          if (value) {
            input.value = value;
            input.setAttribute('value', value);
          }
        }
      });

      // Configure PDF options for fillable forms
      const opt = {
        margin: 0.5,
        filename: `${selectedForm}-${format(new Date(), 'yyyy-MM-dd')}.pdf`,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { 
          scale: 2,
          useCORS: true,
          allowTaint: true 
        },
        jsPDF: { 
          unit: 'in', 
          format: 'letter', 
          orientation: 'portrait',
          compress: true
        }
      };

      // Generate PDF
      const pdfData = await html2pdf()
        .set(opt)
        .from(element)
        .toPdf()
        .get('pdf');

      // Create blob for preview and download
      const blob = new Blob([pdfData.output('blob')], { type: 'application/pdf' });
      setPdfBlob(blob);
      
      toast({
        title: "PDF Generated",
        description: "Document is ready for preview or download",
      });
    } catch (error) {
      console.error('Error generating PDF:', error);
      toast({
        title: "Error",
        description: "Failed to generate PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handlePreview = async () => {
    if (!pdfBlob) {
      await generatePDF();
    }
    if (pdfBlob) {
      setShowPreview(true);
    }
  };

  const handleDownload = async () => {
    if (!pdfBlob) {
      await generatePDF();
    }
    
    if (pdfBlob) {
      const url = URL.createObjectURL(pdfBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${selectedForm}-${format(new Date(), 'yyyy-MM-dd')}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Download Started",
        description: "PDF file has been downloaded",
      });
    }
  };

  const handlePrint = () => {
    if (pdfBlob) {
      const url = URL.createObjectURL(pdfBlob);
      const printWindow = window.open(url, '_blank');
      if (printWindow) {
        printWindow.onload = () => {
          printWindow.print();
        };
      }
      URL.revokeObjectURL(url);
    } else {
      window.print();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="no-print">
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Fillable Forms & Documents
          </DialogTitle>
          <DialogDescription>
            Fill out and print warehouse operation forms.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Form Type Selector */}
          <div className="flex gap-2 no-print">
            <Button
              variant={selectedForm === "inventory-count" ? "default" : "outline"}
              onClick={() => setSelectedForm("inventory-count")}
              size="sm"
            >
              Inventory Count Sheet
            </Button>
            <Button
              variant={selectedForm === "receiving" ? "default" : "outline"}
              onClick={() => setSelectedForm("receiving")}
              size="sm"
            >
              Receiving Form
            </Button>
            <Button
              variant={selectedForm === "work-order" ? "default" : "outline"}
              onClick={() => setSelectedForm("work-order")}
              size="sm"
            >
              Work Order Form
            </Button>
          </div>

          <div className="flex gap-2 no-print">
            <Button onClick={handlePreview} className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700">
              <Eye className="h-4 w-4" />
              Preview PDF
            </Button>
            <Button onClick={handleDownload} className="flex items-center gap-2 bg-green-600 hover:bg-green-700">
              <Download className="h-4 w-4" />
              Download PDF
            </Button>
            <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
              <Printer className="h-4 w-4" />
              Print
            </Button>
            <Button variant="outline" onClick={onClose}>
              Close
            </Button>
          </div>

          <div ref={formRef}>
            {/* Inventory Count Sheet */}
            {selectedForm === "inventory-count" && (
              <Card className="print-form">
                <CardHeader>
                  <div className="text-center space-y-2">
                    <h1 className="text-2xl font-bold">PUCUDA MFG</h1>
                    <h2 className="text-xl">INVENTORY COUNT SHEET</h2>
                    <Separator />
                  </div>
                </CardHeader>
              <CardContent>
                <Form {...inventoryForm}>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <FormField
                      control={inventoryForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-count-date" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={inventoryForm.control}
                      name="countedBy"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Counted By</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Employee name" data-testid="input-counted-by" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={inventoryForm.control}
                      name="department"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Department</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Department/Area" data-testid="input-department" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <h3 className="font-semibold">Items to Count</h3>
                      <Button 
                        type="button" 
                        onClick={addInventoryItem} 
                        size="sm"
                        className="no-print"
                        data-testid="button-add-count-item"
                      >
                        Add Item
                      </Button>
                    </div>

                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-300 p-2">SKU</th>
                          <th className="border border-gray-300 p-2">Description</th>
                          <th className="border border-gray-300 p-2">Expected</th>
                          <th className="border border-gray-300 p-2">Actual Count</th>
                          <th className="border border-gray-300 p-2">Variance</th>
                        </tr>
                      </thead>
                      <tbody>
                        {/* Fillable rows for manual entry */}
                        {Array.from({ length: 15 }).map((_, index) => (
                          <tr key={index}>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-8 text-sm" 
                                name={`item_sku_${index}`}
                                value={tableInputs[`item_sku_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`item_sku_${index}`, e.target.value)}
                                placeholder="SKU"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-8 text-sm" 
                                name={`item_desc_${index}`}
                                value={tableInputs[`item_desc_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`item_desc_${index}`, e.target.value)}
                                placeholder="Description"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-8 text-sm" 
                                type="number" 
                                name={`expected_${index}`}
                                value={tableInputs[`expected_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`expected_${index}`, e.target.value)}
                                placeholder="0"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-8 text-sm" 
                                type="number" 
                                name={`actual_${index}`}
                                value={tableInputs[`actual_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`actual_${index}`, e.target.value)}
                                placeholder="0"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-8 text-sm" 
                                type="number" 
                                name={`variance_${index}`}
                                value={tableInputs[`variance_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`variance_${index}`, e.target.value)}
                                placeholder="0"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <FormField
                      control={inventoryForm.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Notes</FormLabel>
                          <FormControl>
                            <Textarea 
                              {...field} 
                              placeholder="Any discrepancies, damages, or special notes..."
                              className="min-h-[100px]"
                              data-testid="textarea-count-notes"
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4 pt-6">
                      <div>
                        <p className="font-semibold mb-2">Counted By:</p>
                        <div className="border-b border-black w-full h-6"></div>
                        <p className="text-sm text-gray-500 mt-1">Signature & Date</p>
                      </div>
                      <div>
                        <p className="font-semibold mb-2">Verified By:</p>
                        <div className="border-b border-black w-full h-6"></div>
                        <p className="text-sm text-gray-500 mt-1">Signature & Date</p>
                      </div>
                    </div>
                  </div>
                </Form>
              </CardContent>
            </Card>
          )}

          {/* Receiving Form */}
          {selectedForm === "receiving" && (
            <Card className="print-form">
              <CardHeader>
                <div className="text-center space-y-2">
                  <h1 className="text-2xl font-bold">PUCUDA MFG</h1>
                  <h2 className="text-xl">RECEIVING REPORT</h2>
                  <Separator />
                </div>
              </CardHeader>
              <CardContent>
                <Form {...receivingForm}>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <FormField
                      control={receivingForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date Received</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-receive-date" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={receivingForm.control}
                      name="receivedBy"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Received By</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Employee name" data-testid="input-received-by" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={receivingForm.control}
                      name="supplier"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Supplier</FormLabel>
                          <FormControl>
                            <Input {...field} placeholder="Supplier name" data-testid="input-supplier" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={receivingForm.control}
                    name="poNumber"
                    render={({ field }) => (
                      <FormItem className="mb-6">
                        <FormLabel>PO Number</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Purchase order number" data-testid="input-po-number" />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <div className="space-y-4">
                    <h3 className="font-semibold">Items Received</h3>

                    <table className="w-full border-collapse border border-gray-300">
                      <thead>
                        <tr className="bg-gray-50">
                          <th className="border border-gray-300 p-2">SKU</th>
                          <th className="border border-gray-300 p-2">Description</th>
                          <th className="border border-gray-300 p-2">Qty Received</th>
                          <th className="border border-gray-300 p-2">Condition</th>
                          <th className="border border-gray-300 p-2">Notes</th>
                        </tr>
                      </thead>
                      <tbody>
                        {/* Fillable rows for manual entry */}
                        {Array.from({ length: 12 }).map((_, index) => (
                          <tr key={index}>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-10 text-sm" 
                                name={`receive_sku_${index}`}
                                value={tableInputs[`receive_sku_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`receive_sku_${index}`, e.target.value)}
                                placeholder="SKU"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-10 text-sm" 
                                name={`receive_desc_${index}`}
                                value={tableInputs[`receive_desc_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`receive_desc_${index}`, e.target.value)}
                                placeholder="Description"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-10 text-sm" 
                                type="number" 
                                name={`receive_qty_${index}`}
                                value={tableInputs[`receive_qty_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`receive_qty_${index}`, e.target.value)}
                                placeholder="0"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-10 text-sm" 
                                name={`receive_condition_${index}`}
                                value={tableInputs[`receive_condition_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`receive_condition_${index}`, e.target.value)}
                                placeholder="Good"
                              />
                            </td>
                            <td className="border border-gray-300 p-1">
                              <Input 
                                className="border-0 h-10 text-sm" 
                                name={`receive_notes_${index}`}
                                value={tableInputs[`receive_notes_${index}`] || ''}
                                onChange={(e) => handleTableInputChange(`receive_notes_${index}`, e.target.value)}
                                placeholder="Notes"
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    <div className="grid grid-cols-2 gap-4 pt-6">
                      <div>
                        <p className="font-semibold mb-2">Received By:</p>
                        <div className="border-b border-black w-full h-6"></div>
                        <p className="text-sm text-gray-500 mt-1">Signature & Date</p>
                      </div>
                      <div>
                        <p className="font-semibold mb-2">Approved By:</p>
                        <div className="border-b border-black w-full h-6"></div>
                        <p className="text-sm text-gray-500 mt-1">Signature & Date</p>
                      </div>
                    </div>
                  </div>
                </Form>
              </CardContent>
            </Card>
          )}

          {/* Work Order Form */}
          {selectedForm === "work-order" && (
            <Card className="print-form">
              <CardHeader>
                <div className="text-center space-y-2">
                  <h1 className="text-2xl font-bold">PUCUDA MFG</h1>
                  <h2 className="text-xl">WORK ORDER</h2>
                  <Separator />
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Work Order Header */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div>
                      <label className="font-semibold">Work Order #:</label>
                      <div className="border-b border-black w-full h-6 mt-1"></div>
                    </div>
                    <div>
                      <label className="font-semibold">Date:</label>
                      <div className="border-b border-black w-full h-6 mt-1"></div>
                    </div>
                    <div>
                      <label className="font-semibold">Priority:</label>
                      <div className="flex gap-4 mt-2">
                        <label><input type="checkbox" /> Standard</label>
                        <label><input type="checkbox" /> High</label>
                        <label><input type="checkbox" /> Urgent</label>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div>
                      <label className="font-semibold">Customer:</label>
                      <div className="border-b border-black w-full h-6 mt-1"></div>
                    </div>
                    <div>
                      <label className="font-semibold">Requested By:</label>
                      <div className="border-b border-black w-full h-6 mt-1"></div>
                    </div>
                    <div>
                      <label className="font-semibold">Due Date:</label>
                      <div className="border-b border-black w-full h-6 mt-1"></div>
                    </div>
                  </div>
                </div>

                {/* Work Description */}
                <div>
                  <label className="font-semibold block mb-2">Work Description:</label>
                  <div className="border border-gray-300 min-h-[100px] p-3"></div>
                </div>

                {/* Materials Required */}
                <div>
                  <label className="font-semibold block mb-2">Materials/Items Required:</label>
                  <table className="w-full border-collapse border border-gray-300">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="border border-gray-300 p-2">Item SKU</th>
                        <th className="border border-gray-300 p-2">Description</th>
                        <th className="border border-gray-300 p-2">Quantity</th>
                        <th className="border border-gray-300 p-2">Unit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {Array.from({ length: 8 }).map((_, index) => (
                        <tr key={index}>
                          <td className="border border-gray-300 p-1">
                            <Input 
                              className="border-0 h-8 text-sm" 
                              name={`work_sku_${index}`}
                              value={tableInputs[`work_sku_${index}`] || ''}
                              onChange={(e) => handleTableInputChange(`work_sku_${index}`, e.target.value)}
                              placeholder="SKU"
                            />
                          </td>
                          <td className="border border-gray-300 p-1">
                            <Input 
                              className="border-0 h-8 text-sm" 
                              name={`work_desc_${index}`}
                              value={tableInputs[`work_desc_${index}`] || ''}
                              onChange={(e) => handleTableInputChange(`work_desc_${index}`, e.target.value)}
                              placeholder="Description"
                            />
                          </td>
                          <td className="border border-gray-300 p-1">
                            <Input 
                              className="border-0 h-8 text-sm" 
                              type="number" 
                              name={`work_qty_${index}`}
                              value={tableInputs[`work_qty_${index}`] || ''}
                              onChange={(e) => handleTableInputChange(`work_qty_${index}`, e.target.value)}
                              placeholder="0"
                            />
                          </td>
                          <td className="border border-gray-300 p-1">
                            <Input 
                              className="border-0 h-8 text-sm" 
                              name={`work_unit_${index}`}
                              value={tableInputs[`work_unit_${index}`] || ''}
                              onChange={(e) => handleTableInputChange(`work_unit_${index}`, e.target.value)}
                              placeholder="Each"
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Completion Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6">
                  <div>
                    <label className="font-semibold block mb-2">Work Completed By:</label>
                    <div className="border-b border-black w-full h-6 mb-4"></div>
                    <div className="flex justify-between text-sm">
                      <span>Signature</span>
                      <span>Date/Time</span>
                    </div>
                  </div>
                  <div>
                    <label className="font-semibold block mb-2">Verified By:</label>
                    <div className="border-b border-black w-full h-6 mb-4"></div>
                    <div className="flex justify-between text-sm">
                      <span>Signature</span>
                      <span>Date/Time</span>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="font-semibold block mb-2">Notes/Comments:</label>
                  <div className="border border-gray-300 min-h-[80px] p-3"></div>
                </div>
              </CardContent>
            </Card>
          )}
          </div>
        </div>

        {/* PDF Preview Modal */}
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-4xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>PDF Preview</DialogTitle>
              <DialogDescription>
                Preview your document before downloading or printing
              </DialogDescription>
            </DialogHeader>
            
            <div className="h-[70vh] border rounded-lg">
              {pdfBlob ? (
                <iframe
                  src={URL.createObjectURL(pdfBlob)}
                  className="w-full h-full"
                  title="PDF Preview"
                />
              ) : (
                <div className="flex items-center justify-center h-full text-muted-foreground">
                  <p>Loading PDF preview...</p>
                </div>
              )}
            </div>
            
            <div className="flex justify-end space-x-2">
              <Button onClick={handleDownload} className="bg-green-600 hover:bg-green-700">
                <Download className="h-4 w-4 mr-2" />
                Download PDF
              </Button>
              <Button onClick={handlePrint} variant="outline">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button variant="outline" onClick={() => setShowPreview(false)}>
                Close Preview
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <style>{`
          @media print {
            .no-print {
              display: none !important;
            }
            
            .print-form {
              margin: 0;
              padding: 20px;
              page-break-inside: avoid;
            }
            
            body {
              font-size: 12px;
              line-height: 1.4;
            }
            
            table {
              border-collapse: collapse;
              width: 100%;
            }
            
            th, td {
              border: 1px solid #000 !important;
              padding: 8px;
            }
            
            th {
              background-color: #f5f5f5 !important;
              font-weight: bold;
            }
            
            input[type="checkbox"] {
              width: 15px;
              height: 15px;
            }
            
            /* Make form fields more visible in PDF */
            input, textarea, select {
              border: 1px solid #000 !important;
              background: white !important;
              padding: 4px !important;
              pointer-events: auto !important;
            }
            
            /* Ensure inputs are clickable and functional */
            .print-form input {
              cursor: text !important;
              user-select: text !important;
            }
          }
        `}</style>
      </DialogContent>
    </Dialog>
  );
}