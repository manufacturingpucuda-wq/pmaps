import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Edit, Barcode, Trash2, MoreHorizontal, LogOut, ArrowDownToLine } from "lucide-react";
import type { ItemWithStatus } from "@shared/schema";

interface InventoryTableProps {
  items: ItemWithStatus[];
  isLoading: boolean;
  onDelete: (id: string) => void;
  onShowBarcode: (item: ItemWithStatus) => void;
  onQuickCheckout?: (item: ItemWithStatus) => void;
  onCheckIn?: (item: ItemWithStatus) => void;
  onEdit?: (item: ItemWithStatus) => void;
}

export function InventoryTable({ items, isLoading, onDelete, onShowBarcode, onQuickCheckout, onCheckIn, onEdit }: InventoryTableProps) {
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());

  const toggleSelectAll = () => {
    if (selectedItems.size === items.length) {
      setSelectedItems(new Set());
    } else {
      setSelectedItems(new Set(items.map(item => item.id)));
    }
  };

  const toggleSelectItem = (id: string) => {
    const newSelected = new Set(selectedItems);
    if (newSelected.has(id)) {
      newSelected.delete(id);
    } else {
      newSelected.add(id);
    }
    setSelectedItems(newSelected);
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      available: "bg-green-600 text-white",
      reserved: "bg-yellow-600 text-white", 
      "checked-out": "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[status as keyof typeof variants] || "bg-gray-600 text-white"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  if (isLoading) {
    return (
      <div className="text-center py-8">
        <p className="text-muted-foreground">Loading inventory...</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted">
            <TableHead className="w-12">
              <Checkbox
                checked={selectedItems.size === items.length && items.length > 0}
                onCheckedChange={toggleSelectAll}
                data-testid="checkbox-select-all"
              />
            </TableHead>
            <TableHead className="text-muted-foreground font-medium">SKU</TableHead>
            <TableHead className="text-muted-foreground font-medium">Product Name</TableHead>
            <TableHead className="text-muted-foreground font-medium">Current Stock</TableHead>
            <TableHead className="text-muted-foreground font-medium">Unit Type</TableHead>
            <TableHead className="text-muted-foreground font-medium">Status</TableHead>
            <TableHead className="text-muted-foreground font-medium">Last Updated</TableHead>
            <TableHead className="text-right text-muted-foreground font-medium">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.length === 0 ? (
            <TableRow>
              <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                No items found
              </TableCell>
            </TableRow>
          ) : (
            items.map((item) => (
              <TableRow 
                key={item.id} 
                className="hover:bg-muted/50 transition-colors"
                data-testid={`row-item-${item.id}`}
              >
                <TableCell>
                  <Checkbox
                    checked={selectedItems.has(item.id)}
                    onCheckedChange={() => toggleSelectItem(item.id)}
                    data-testid={`checkbox-${item.id}`}
                  />
                </TableCell>
                <TableCell className="font-mono text-sm font-medium">{item.sku}</TableCell>
                <TableCell className="text-sm">{item.productName}</TableCell>
                <TableCell>
                  <div className="flex flex-col space-y-1">
                    <span className="font-semibold" data-testid={`stock-${item.id}`}>
                      {item.currentStock}
                    </span>
                    <span className="text-muted-foreground text-xs">
                      {item.availableStock} available
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <Badge variant="outline" className="text-xs font-medium bg-blue-50 text-blue-700 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800">
                    {item.unitType || 'pieces'}
                  </Badge>
                </TableCell>
                <TableCell>{getStatusBadge(item.status)}</TableCell>
                <TableCell className="text-sm text-muted-foreground">
                  {item.lastUpdated ? new Date(item.lastUpdated).toLocaleString() : "-"}
                </TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" data-testid={`button-actions-${item.id}`}>
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem 
                        onClick={() => onEdit?.(item)}
                        data-testid={`button-edit-${item.id}`}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        onClick={() => onShowBarcode(item)}
                        data-testid={`button-barcode-${item.id}`}
                      >
                        <Barcode className="h-4 w-4 mr-2" />
                        Barcode
                      </DropdownMenuItem>
                      {onQuickCheckout && item.availableStock > 0 && (
                        <DropdownMenuItem 
                          onClick={() => onQuickCheckout(item)}
                          data-testid={`button-checkout-${item.id}`}
                        >
                          <LogOut className="h-4 w-4 mr-2" />
                          Quick Checkout
                        </DropdownMenuItem>
                      )}
                      {onCheckIn && item.reservedStock > 0 && (
                        <DropdownMenuItem 
                          onClick={() => onCheckIn(item)}
                          data-testid={`button-checkin-${item.id}`}
                        >
                          <ArrowDownToLine className="h-4 w-4 mr-2" />
                          Check In
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuItem 
                        onClick={() => onDelete(item.id)}
                        className="text-destructive"
                        data-testid={`button-delete-${item.id}`}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>
    </div>
  );
}
