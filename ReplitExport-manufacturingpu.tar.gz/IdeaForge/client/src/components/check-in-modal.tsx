import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { ArrowDownToLine, Package } from "lucide-react";
import type { Item } from "@shared/schema";

const checkinFormSchema = z.object({
  quantity: z.number().min(1, "Quantity must be at least 1"),
  notes: z.string().optional(),
  reasonCode: z.enum(["production", "quality-check", "repair", "inventory-adjustment", "customer-return", "damaged", "maintenance", "transfer", "other"]).optional(),
  condition: z.enum(["new", "good", "fair", "damaged", "defective"]).default("good"),
  location: z.string().optional(),
  workOrder: z.string().optional(),
  department: z.string().optional(),
  batchNumber: z.string().optional(),
  serialNumbers: z.string().optional(), // Comma-separated for UI
  actualReturnDate: z.string().optional(), // Date string for form
});

type CheckinFormValues = z.infer<typeof checkinFormSchema>;

interface CheckInModalProps {
  item: Item | null;
  isOpen: boolean;
  onClose: () => void;
}

export function CheckInModal({ item, isOpen, onClose }: CheckInModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<CheckinFormValues>({
    resolver: zodResolver(checkinFormSchema),
    defaultValues: {
      quantity: 1,
      notes: "",
      condition: "good",
      location: "",
      workOrder: "",
      department: "",
      batchNumber: "",
      serialNumbers: "",
    },
  });

  const checkinMutation = useMutation({
    mutationFn: async (values: CheckinFormValues) => {
      if (!item) throw new Error("No item selected");
      
      const response = await fetch(`/api/items/${item.id}/checkin`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(values),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to check in item");
      }

      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/items"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/transactions/enhanced"] });
      toast({
        title: "Item Checked In",
        description: `Successfully checked in ${form.getValues("quantity")} ${item?.unitType} of ${item?.sku}`,
      });
      form.reset();
      onClose();
    },
    onError: (error) => {
      toast({
        title: "Check-in Failed",
        description: error instanceof Error ? error.message : "Failed to check in item",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (values: CheckinFormValues) => {
    checkinMutation.mutate(values);
  };

  if (!item) return null;

  const maxQuantity = item.reservedStock;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ArrowDownToLine className="h-5 w-5 text-green-600" />
            Check In Item
          </DialogTitle>
          <DialogDescription>
            Return items to inventory and update stock levels.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 p-3 bg-muted/50 rounded-lg mb-4">
          <Package className="h-8 w-8 text-muted-foreground" />
          <div>
            <h3 className="font-medium">{item.sku}</h3>
            <p className="text-sm text-muted-foreground">{item.productName}</p>
            <p className="text-xs text-muted-foreground">
              {maxQuantity} {item.unitType} currently checked out
            </p>
          </div>
        </div>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="quantity"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Quantity to Check In</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      min={1}
                      max={maxQuantity}
                      {...field}
                      onChange={(e) => field.onChange(Number(e.target.value))}
                      data-testid="input-checkin-quantity"
                    />
                  </FormControl>
                  <FormDescription>
                    Maximum available: {maxQuantity} {item.unitType}
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="reasonCode"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Reason Code</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-reason-code">
                          <SelectValue placeholder="Select reason" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="production">Production</SelectItem>
                        <SelectItem value="quality-check">Quality Check</SelectItem>
                        <SelectItem value="repair">Repair</SelectItem>
                        <SelectItem value="inventory-adjustment">Inventory Adjustment</SelectItem>
                        <SelectItem value="customer-return">Customer Return</SelectItem>
                        <SelectItem value="damaged">Damaged</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="transfer">Transfer</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="condition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Item Condition</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger data-testid="select-condition">
                          <SelectValue placeholder="Select condition" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="new">New</SelectItem>
                        <SelectItem value="good">Good</SelectItem>
                        <SelectItem value="fair">Fair</SelectItem>
                        <SelectItem value="damaged">Damaged</SelectItem>
                        <SelectItem value="defective">Defective</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="location"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Location</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Warehouse location..."
                        {...field}
                        data-testid="input-location"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="workOrder"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Work Order</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="WO-2025-001..."
                        {...field}
                        data-testid="input-work-order"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <FormField
                control={form.control}
                name="department"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Department</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Production, Quality, etc..."
                        {...field}
                        data-testid="input-department"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="batchNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Batch Number</FormLabel>
                    <FormControl>
                      <Input
                        placeholder="Batch-2025-001..."
                        {...field}
                        data-testid="input-batch-number"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="serialNumbers"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Serial Numbers (Optional)</FormLabel>
                  <FormControl>
                    <Input
                      placeholder="SN001, SN002, SN003... (comma-separated)"
                      {...field}
                      data-testid="input-serial-numbers"
                    />
                  </FormControl>
                  <FormDescription>
                    Enter serial numbers separated by commas
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes (Optional)</FormLabel>
                  <FormControl>
                    <Textarea
                      placeholder="Add any notes about the check-in..."
                      className="resize-none"
                      {...field}
                      data-testid="textarea-checkin-notes"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <DialogFooter>
              <Button 
                type="button" 
                variant="outline" 
                onClick={onClose}
                data-testid="button-cancel-checkin"
              >
                Cancel
              </Button>
              <Button 
                type="submit" 
                disabled={checkinMutation.isPending}
                data-testid="button-confirm-checkin"
              >
                {checkinMutation.isPending ? "Checking In..." : "Check In"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}