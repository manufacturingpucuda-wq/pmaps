import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { OrderPrintModal } from "@/components/order-print-modal";
import { Edit, Trash2, User, Clock, CheckCircle, Pause, Play, AlertTriangle, Printer, ChevronDown, ChevronUp, Activity, Plus, FileText } from "lucide-react";
import type { OrderWithItems } from "@shared/schema";

interface OrderCardProps {
  order: OrderWithItems;
  onFulfill: (id: string) => void;
  onEdit?: (order: OrderWithItems) => void;
  onDelete?: (id: string) => void;
  onStatusChange?: (id: string, status: string) => void;
  onProgressUpdate?: (id: string, progress: number) => void;
  onPriorityChange?: (id: string, priority: string) => void;
  onAssignChange?: (id: string, assignee: string) => void;
}

export function OrderCard({ order, onFulfill, onEdit, onDelete, onStatusChange, onProgressUpdate, onPriorityChange, onAssignChange }: OrderCardProps) {
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [showActivities, setShowActivities] = useState(false);
  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "bg-blue-600 text-white",
      fulfilled: "bg-green-600 text-white",
      cancelled: "bg-gray-600 text-white",
      "in-progress": "bg-orange-600 text-white",
      "on-hold": "bg-yellow-600 text-white",
    };
    return (
      <Badge className={variants[status as keyof typeof variants] || "bg-gray-600 text-white"}>
        {status.charAt(0).toUpperCase() + status.slice(1).replace('-', ' ')}
      </Badge>
    );
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="h-4 w-4" />;
      case "in-progress": return <Play className="h-4 w-4" />;
      case "on-hold": return <Pause className="h-4 w-4" />;
      case "fulfilled": return <CheckCircle className="h-4 w-4" />;
      case "cancelled": return <AlertTriangle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "text-red-500";
      case "high": return "text-orange-500";
      default: return "text-blue-500";
    }
  };

  return (
    <Card className="card-hover" data-testid={`card-order-${order.id}`}>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-4">
            <h4 className="text-lg font-semibold text-foreground" data-testid={`text-order-number-${order.id}`}>
              {order.orderNumber}
            </h4>
            {getStatusBadge(order.status)}
          </div>
          <div className="text-sm text-muted-foreground">
            {order.status === 'fulfilled' ? 'Fulfilled:' : 'Created:'} {' '}
            {order.status === 'fulfilled' && order.fulfilledAt
              ? new Date(order.fulfilledAt).toLocaleString()
              : order.createdAt
              ? new Date(order.createdAt).toLocaleString()
              : "-"
            }
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 mb-4">
          <div>
            <p className="text-sm text-muted-foreground">Customer</p>
            <p className="font-medium text-foreground" data-testid={`text-customer-${order.id}`}>
              {order.customer}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Items</p>
            <p className="font-medium text-foreground" data-testid={`text-items-count-${order.id}`}>
              {order.items.length} items
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Priority</p>
            <p className={`font-medium ${getPriorityColor(order.priority)}`} data-testid={`text-priority-${order.id}`}>
              {order.priority.charAt(0).toUpperCase() + order.priority.slice(1)}
            </p>
          </div>
          <div>
            <p className="text-sm text-muted-foreground">Assigned To</p>
            <div className="flex items-center space-x-1">
              <User className="h-3 w-3 text-muted-foreground" />
              <p className="font-medium text-foreground" data-testid={`text-assigned-${order.id}`}>
                {order.assignedTo || "Unassigned"}
              </p>
            </div>
          </div>
        </div>

        {/* Quick Status Controls */}
        <div className="mb-4 p-3 bg-muted/50 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm font-medium text-foreground">Quick Actions</p>
          </div>
          
          <div className="grid grid-cols-2 gap-2">
            {/* Status Quick Change */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Status</label>
              <Select value={order.status} onValueChange={(value) => onStatusChange?.(order.id, value)}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="in-progress">In Progress</SelectItem>
                  <SelectItem value="on-hold">On Hold</SelectItem>
                  <SelectItem value="fulfilled">Fulfilled</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Priority Quick Change */}
            <div>
              <label className="text-xs text-muted-foreground mb-1 block">Priority</label>
              <Select value={order.priority} onValueChange={(value) => onPriorityChange?.(order.id, value)}>
                <SelectTrigger className="h-8 text-xs">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Progress Quick Update Buttons */}
          <div className="mt-3">
            <label className="text-xs text-muted-foreground mb-1 block">Progress: {order.completionPercentage || 0}%</label>
            <div className="flex items-center space-x-1 mb-2">
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => onProgressUpdate?.(order.id, 0)}
              >
                0%
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => onProgressUpdate?.(order.id, 25)}
              >
                25%
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => onProgressUpdate?.(order.id, 50)}
              >
                50%
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => onProgressUpdate?.(order.id, 75)}
              >
                75%
              </Button>
              <Button 
                size="sm" 
                variant="outline" 
                className="h-6 px-2 text-xs"
                onClick={() => onProgressUpdate?.(order.id, 100)}
              >
                100%
              </Button>
            </div>
            <Progress 
              value={order.completionPercentage || 0} 
              className="h-2" 
              data-testid={`progress-${order.id}`}
            />
          </div>
        </div>
        
        {/* Order Items Preview */}
        <div className="bg-muted rounded-lg p-4 mb-4">
          <h5 className="text-sm font-medium text-foreground mb-2">Order Items:</h5>
          <div className="space-y-2 text-sm">
            {order.items.slice(0, 2).map((orderItem, index) => (
              <div key={orderItem.id} className="flex justify-between" data-testid={`order-item-${index}`}>
                <span className="text-muted-foreground">{orderItem.item.sku}</span>
                <span className="text-foreground">Qty: {orderItem.quantity}</span>
              </div>
            ))}
            {order.items.length > 2 && (
              <button className="text-primary text-xs hover:underline" data-testid={`button-view-all-${order.id}`}>
                View all {order.items.length} items
              </button>
            )}
          </div>
        </div>
        
        {/* Main Action Buttons */}
        <div className="flex items-center justify-between border-t pt-4">
          <div className="flex space-x-2">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onEdit?.(order)}
              data-testid={`button-edit-order-${order.id}`}
            >
              <Edit className="h-4 w-4 mr-1" />
              Edit Details
            </Button>
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => setShowPrintModal(true)}
              data-testid={`button-print-label-${order.id}`}
            >
              <Printer className="h-4 w-4 mr-1" />
              Print Order
            </Button>
          </div>
          
          <div className="flex items-center space-x-2">
            {order.status === 'pending' && (
              <Button 
                size="sm"
                onClick={() => onStatusChange?.(order.id, 'in-progress')}
                className="bg-orange-600 hover:bg-orange-700 text-white"
                data-testid={`button-start-${order.id}`}
              >
                <Play className="h-4 w-4 mr-1" />
                Start Work
              </Button>
            )}
            
            {order.status === 'in-progress' && (
              <>
                <Button 
                  size="sm"
                  onClick={() => onStatusChange?.(order.id, 'on-hold')}
                  variant="outline"
                  data-testid={`button-pause-${order.id}`}
                >
                  <Pause className="h-4 w-4 mr-1" />
                  Pause
                </Button>
                <Button 
                  size="sm"
                  onClick={() => onStatusChange?.(order.id, 'fulfilled')}
                  className="bg-green-600 hover:bg-green-700 text-white"
                  data-testid={`button-complete-${order.id}`}
                >
                  <CheckCircle className="h-4 w-4 mr-1" />
                  Complete
                </Button>
              </>
            )}
            
            {order.status === 'on-hold' && (
              <Button 
                size="sm"
                onClick={() => onStatusChange?.(order.id, 'in-progress')}
                className="bg-orange-600 hover:bg-orange-700 text-white"
                data-testid={`button-resume-${order.id}`}
              >
                <Play className="h-4 w-4 mr-1" />
                Resume
              </Button>
            )}
            
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => onDelete?.(order.id)}
              className="text-red-600 hover:text-red-700 border-red-300"
              data-testid={`button-delete-order-${order.id}`}
            >
              <Trash2 className="h-4 w-4 mr-1" />
              Delete
            </Button>
          </div>
        </div>

        {/* Activity Log Section */}
        <Collapsible open={showActivities} onOpenChange={setShowActivities}>
          <div className="border-t pt-4 mt-4">
            <CollapsibleTrigger asChild>
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full flex items-center justify-between p-2 hover:bg-muted/50"
                data-testid={`button-toggle-activities-${order.id}`}
              >
                <div className="flex items-center space-x-2">
                  <Activity className="h-4 w-4" />
                  <span className="text-sm font-medium">
                    Activity Log ({order.activities?.length || 0} entries)
                  </span>
                </div>
                {showActivities ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
              </Button>
            </CollapsibleTrigger>
            
            <CollapsibleContent className="mt-2">
              <div className="space-y-2 max-h-48 overflow-y-auto">
                {order.activities && order.activities.length > 0 ? (
                  order.activities.map((activity, index) => (
                    <div 
                      key={activity.id} 
                      className="flex items-start space-x-3 p-3 bg-muted/30 rounded-md text-sm"
                      data-testid={`activity-${activity.id}`}
                    >
                      <div className="flex-shrink-0">
                        {activity.activityType === 'created' && <Plus className="h-4 w-4 text-green-600 mt-0.5" />}
                        {activity.activityType === 'item_added' && <Plus className="h-4 w-4 text-blue-600 mt-0.5" />}
                        {activity.activityType === 'item_removed' && <Trash2 className="h-4 w-4 text-red-600 mt-0.5" />}
                        {activity.activityType === 'status_changed' && <Clock className="h-4 w-4 text-orange-600 mt-0.5" />}
                        {activity.activityType === 'fulfilled' && <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />}
                        {activity.activityType === 'assigned' && <User className="h-4 w-4 text-purple-600 mt-0.5" />}
                        {activity.activityType === 'work_order_created' && <FileText className="h-4 w-4 text-indigo-600 mt-0.5" />}
                        {!['created', 'item_added', 'item_removed', 'status_changed', 'fulfilled', 'assigned', 'work_order_created'].includes(activity.activityType) && 
                          <Activity className="h-4 w-4 text-gray-600 mt-0.5" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-foreground font-medium">
                          {activity.description}
                        </p>
                        <div className="flex items-center space-x-2 mt-1 text-xs text-muted-foreground">
                          <span>
                            {activity.user.firstName} {activity.user.lastName} 
                            <span className="ml-1 text-xs opacity-75">({activity.user.username})</span>
                          </span>
                          <span>•</span>
                          <span>
                            {activity.createdAt ? new Date(activity.createdAt).toLocaleString() : 'Unknown time'}
                          </span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    No activity recorded yet
                  </div>
                )}
              </div>
            </CollapsibleContent>
          </div>
        </Collapsible>
      </CardContent>
      
      <OrderPrintModal
        open={showPrintModal}
        onOpenChange={setShowPrintModal}
        order={order}
      />
    </Card>
  );
}
