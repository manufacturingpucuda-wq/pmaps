import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { ReceivingOrder, InsertReceivingOrder } from "@shared/schema";

export function useReceivingOrders() {
  return useQuery<ReceivingOrder[]>({
    queryKey: ["/api/receiving-orders"],
  });
}

export function useReceivingOrder(id: string) {
  return useQuery<ReceivingOrder>({
    queryKey: ["/api/receiving-orders", id],
    enabled: !!id,
  });
}

export function useCreateReceivingOrder() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (data: InsertReceivingOrder) => {
      const response = await apiRequest("POST", "/api/receiving-orders", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-orders"] });
    },
  });
}

export function useUpdateReceivingOrder() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<ReceivingOrder> }) => {
      const response = await apiRequest("PATCH", `/api/receiving-orders/${id}`, data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-orders"] });
    },
  });
}

export function useDeleteReceivingOrder() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async (id: string) => {
      await apiRequest("DELETE", `/api/receiving-orders/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-orders"] });
    },
  });
}

export function useReceiveItem() {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: async ({ orderId, itemData }: { 
      orderId: string; 
      itemData: { itemId: string; receivedQuantity: number; condition: string; lotNumber?: string; notes?: string }
    }) => {
      const response = await apiRequest("POST", `/api/receiving-orders/${orderId}/receive-item`, itemData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/receiving-orders"] });
    },
  });
}