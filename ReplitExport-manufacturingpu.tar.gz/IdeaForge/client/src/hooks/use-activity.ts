import { useState, useCallback } from 'react';

export interface Activity {
  id: string;
  timestamp: Date;
  action: string;
  description: string;
  entityType: 'user' | 'item' | 'order';
  entityId: string;
  undoAction?: () => Promise<void>;
  canUndo: boolean;
}

const activities: Activity[] = [];

export function useActivity() {
  const [activityList, setActivityList] = useState<Activity[]>(activities);

  const logActivity = useCallback((activity: Omit<Activity, 'id' | 'timestamp'>) => {
    const newActivity: Activity = {
      ...activity,
      id: Math.random().toString(36).substr(2, 9),
      timestamp: new Date(),
    };
    
    activities.unshift(newActivity);
    if (activities.length > 50) activities.pop(); // Keep last 50 activities
    
    setActivityList([...activities]);
  }, []);

  const undoActivity = useCallback(async (activityId: string) => {
    const activity = activities.find(a => a.id === activityId);
    if (activity?.undoAction && activity.canUndo) {
      try {
        await activity.undoAction();
        activity.canUndo = false;
        setActivityList([...activities]);
        return true;
      } catch (error) {
        console.error('Failed to undo activity:', error);
        return false;
      }
    }
    return false;
  }, []);

  const clearActivities = useCallback(() => {
    activities.length = 0;
    setActivityList([]);
  }, []);

  return {
    activities: activityList,
    logActivity,
    undoActivity,
    clearActivities,
  };
}