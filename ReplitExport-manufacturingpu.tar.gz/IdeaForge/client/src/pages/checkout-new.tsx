import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { useInventory } from "@/hooks/use-inventory";
import { useOrders, useCheckout } from "@/hooks/use-orders";
import { useToast } from "@/hooks/use-toast";
import { useActivity } from "@/hooks/use-activity";
import { 
  Search, 
  Plus, 
  Minus,
  Trash2, 
  ShoppingCart, 
  Package,
  User,
  Calendar,
  ClipboardList,
  CheckCircle2,
  AlertCircle
} from "lucide-react";
import type { ItemWithStatus, CheckoutRequest } from "@shared/schema";

interface CartItem {
  itemId: string;
  item: ItemWithStatus;
  quantity: number;
}

export default function NewCheckout() {
  const [activeTab, setActiveTab] = useState("new-order");
  const [selectedOrderId, setSelectedOrderId] = useState("");
  const [customer, setCustomer] = useState("");
  const [priority, setPriority] = useState<"standard" | "high" | "urgent">("standard");
  const [notes, setNotes] = useState("");
  const [itemSearch, setItemSearch] = useState("");
  const [cart, setCart] = useState<CartItem[]>([]);

  const { data: items = [] } = useInventory();
  const { data: orders = [] } = useOrders();
  const checkout = useCheckout();
  const { toast } = useToast();
  const { logActivity } = useActivity();

  const availableItems = items.filter(item => 
    item.availableStock > 0 &&
    (itemSearch === "" || 
     item.sku.toLowerCase().includes(itemSearch.toLowerCase()) ||
     item.productName.toLowerCase().includes(itemSearch.toLowerCase()))
  );

  const pendingOrders = orders.filter(order => 
    order.status === "pending" || order.status === "in-progress"
  );

  const addToCart = (item: ItemWithStatus) => {
    const existingItem = cart.find(cartItem => cartItem.itemId === item.id);
    if (existingItem) {
      setCart(cart.map(cartItem =>
        cartItem.itemId === item.id
          ? { ...cartItem, quantity: Math.min(cartItem.quantity + 1, item.availableStock) }
          : cartItem
      ));
    } else {
      setCart([...cart, { itemId: item.id, item, quantity: 1 }]);
    }
  };

  const removeFromCart = (itemId: string) => {
    setCart(cart.filter(cartItem => cartItem.itemId !== itemId));
  };

  const updateQuantity = (itemId: string, quantity: number) => {
    const cartItem = cart.find(item => item.itemId === itemId);
    if (!cartItem) return;

    if (quantity <= 0) {
      removeFromCart(itemId);
      return;
    }

    const maxQuantity = cartItem.item.availableStock;
    const newQuantity = Math.min(quantity, maxQuantity);

    setCart(cart.map(item =>
      item.itemId === itemId
        ? { ...item, quantity: newQuantity }
        : item
    ));
  };

  const clearCart = () => {
    setCart([]);
  };

  const totalItems = cart.length;
  const totalQuantity = cart.reduce((sum, item) => sum + item.quantity, 0);

  const handleProcessCheckout = async () => {
    if (cart.length === 0) {
      toast({
        title: "Cart Empty",
        description: "Please add items to your cart before checking out",
        variant: "destructive",
      });
      return;
    }

    if (activeTab === "new-order" && !customer.trim()) {
      toast({
        title: "Customer Required",
        description: "Please enter a customer name for the new order",
        variant: "destructive",
      });
      return;
    }

    if (activeTab === "existing-order" && !selectedOrderId) {
      toast({
        title: "Order Required",
        description: "Please select an existing order to add items to",
        variant: "destructive",
      });
      return;
    }

    const checkoutData: CheckoutRequest = {
      orderId: activeTab === "existing-order" ? selectedOrderId : undefined,
      customer: activeTab === "new-order" ? customer.trim() : undefined,
      priority,
      notes: notes.trim() || undefined,
      items: cart.map(item => ({
        itemId: item.itemId,
        quantity: item.quantity,
      })),
    };

    try {
      const result: any = await checkout.mutateAsync(checkoutData);
      
      // Log activity
      logActivity({
        action: "create",
        entityType: "order",
        entityId: String(result?.id || 'unknown'),
        description: activeTab === "existing-order" 
          ? `Added ${totalQuantity} items to order ${selectedOrderId}`
          : `Created new order for ${customer || 'customer'} with ${totalQuantity} items`,
        canUndo: false
      });

      toast({
        title: "Checkout Successful!",
        description: activeTab === "existing-order" 
          ? `${totalQuantity} items added to existing order`
          : `New order created successfully for ${customer}`,
      });

      // Reset form
      clearCart();
      setCustomer("");
      setSelectedOrderId("");
      setNotes("");
      setPriority("standard");
    } catch (error) {
      toast({
        title: "Checkout Failed",
        description: "Something went wrong during checkout. Please try again.",
        variant: "destructive",
      });
    }
  };

  const getPriorityBadgeColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200';
      default: return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-lg p-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <div className="bg-white/10 rounded-full p-3">
              <ShoppingCart className="h-8 w-8" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">Smart Checkout</h1>
              <p className="text-[#02120a]">Check out items to existing orders !</p>
            </div>
          </div>
          
          {cart.length > 0 && (
            <div className="bg-white/10 rounded-lg p-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{totalQuantity}</div>
                <div className="text-sm text-emerald-100">Items in Cart</div>
              </div>
            </div>
          )}
        </div>
      </div>
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        
        {/* Left Section - Item Selection */}
        <div className="xl:col-span-2 space-y-4">
          
          {/* Item Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Package className="h-5 w-5" />
                Add Items to Cart
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="relative mb-4">
                <Input
                  type="text"
                  placeholder="Search by SKU or product name..."
                  value={itemSearch}
                  onChange={(e) => setItemSearch(e.target.value)}
                  className="pl-10"
                  data-testid="input-checkout-item-search"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-96 overflow-y-auto">
                {availableItems.map(item => (
                  <Card 
                    key={item.id}
                    className="hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => addToCart(item)}
                    data-testid={`item-${item.id}`}
                  >
                    <CardContent className="p-4">
                      <div className="space-y-2">
                        <div>
                          <p className="font-medium text-sm">{item.sku}</p>
                          <p className="text-xs text-muted-foreground truncate">
                            {item.productName}
                          </p>
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-1">
                            <Badge variant="secondary" className="text-xs">
                              {item.availableStock} {item.unitType}
                            </Badge>
                          </div>
                          <Button 
                            size="sm" 
                            className="h-6 w-6 p-0"
                            data-testid={`button-add-${item.id}`}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {availableItems.length === 0 && (
                  <div className="col-span-full text-center py-8">
                    <Package className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">No items found</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
          
        </div>

        {/* Right Section - Cart & Checkout */}
        <div className="space-y-4">
          
          {/* Shopping Cart */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <ShoppingCart className="h-5 w-5" />
                  Cart ({totalItems})
                </div>
                {cart.length > 0 && (
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearCart}
                    className="text-red-600 hover:text-red-700"
                  >
                    Clear All
                  </Button>
                )}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3" data-testid="checkout-cart">
                {cart.length === 0 ? (
                  <div className="text-center py-8">
                    <ShoppingCart className="h-12 w-12 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground">Your cart is empty</p>
                    <p className="text-sm text-muted-foreground">Add items from the list above</p>
                  </div>
                ) : (
                  cart.map(cartItem => (
                    <div 
                      key={cartItem.itemId}
                      className="flex items-center justify-between p-3 bg-muted rounded-lg"
                      data-testid={`cart-item-${cartItem.itemId}`}
                    >
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm truncate">{cartItem.item.sku}</p>
                        <p className="text-xs text-muted-foreground">
                          {cartItem.item.unitType}
                        </p>
                      </div>
                      
                      <div className="flex items-center space-x-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="h-6 w-6 p-0"
                          onClick={() => updateQuantity(cartItem.itemId, cartItem.quantity - 1)}
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        
                        <span className="text-sm font-medium w-8 text-center">
                          {cartItem.quantity}
                        </span>
                        
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="h-6 w-6 p-0"
                          onClick={() => updateQuantity(cartItem.itemId, cartItem.quantity + 1)}
                          disabled={cartItem.quantity >= cartItem.item.availableStock}
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-6 w-6 p-0 text-red-600 hover:text-red-700"
                          onClick={() => removeFromCart(cartItem.itemId)}
                          data-testid={`button-remove-${cartItem.itemId}`}
                        >
                          <Trash2 className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Checkout Options */}
          {cart.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <ClipboardList className="h-5 w-5" />
                  Checkout Options
                </CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="new-order" className="text-sm">
                      New Order
                    </TabsTrigger>
                    <TabsTrigger value="existing-order" className="text-sm">
                      Add to Order
                    </TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="new-order" className="space-y-4 mt-4">
                    <div>
                      <Label htmlFor="customer">Customer Name *</Label>
                      <div className="relative mt-1">
                        <Input
                          id="customer"
                          type="text"
                          placeholder="Enter customer name"
                          value={customer}
                          onChange={(e) => setCustomer(e.target.value)}
                          className="pl-10"
                          data-testid="input-checkout-customer"
                        />
                        <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="existing-order" className="space-y-4 mt-4">
                    <div>
                      <Label htmlFor="order-select">Select Order</Label>
                      <Select value={selectedOrderId} onValueChange={setSelectedOrderId}>
                        <SelectTrigger className="mt-1" data-testid="select-existing-order">
                          <SelectValue placeholder="Choose an order..." />
                        </SelectTrigger>
                        <SelectContent>
                          {pendingOrders.map(order => (
                            <SelectItem key={order.id} value={order.id}>
                              <div className="flex items-center justify-between w-full">
                                <span>{order.orderNumber} - {order.customer}</span>
                                <Badge 
                                  variant="secondary" 
                                  className={order.status === 'in-progress' ? 'ml-2 bg-blue-100 text-blue-800' : 'ml-2'}
                                >
                                  {order.status}
                                </Badge>
                              </div>
                            </SelectItem>
                          ))}
                          {pendingOrders.length === 0 && (
                            <SelectItem value="disabled-placeholder" disabled>
                              No pending orders available
                            </SelectItem>
                          )}
                        </SelectContent>
                      </Select>
                    </div>
                  </TabsContent>
                </Tabs>

                {/* Common Options */}
                <div className="space-y-4 mt-4">
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={priority} onValueChange={(value: any) => setPriority(value)}>
                      <SelectTrigger className="mt-1">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="standard">
                          <div className="flex items-center gap-2">
                            Standard
                            <Badge className={getPriorityBadgeColor('standard')}>
                              Normal
                            </Badge>
                          </div>
                        </SelectItem>
                        <SelectItem value="high">
                          <div className="flex items-center gap-2">
                            High Priority
                            <Badge className={getPriorityBadgeColor('high')}>
                              High
                            </Badge>
                          </div>
                        </SelectItem>
                        <SelectItem value="urgent">
                          <div className="flex items-center gap-2">
                            Urgent
                            <Badge className={getPriorityBadgeColor('urgent')}>
                              Urgent
                            </Badge>
                          </div>
                        </SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="notes">Order Notes</Label>
                    <Input
                      id="notes"
                      type="text"
                      placeholder="Optional notes or instructions..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>

                <Separator className="my-4" />

                {/* Summary */}
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Items:</span>
                    <span className="font-medium">{totalItems}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Total Quantity:</span>
                    <span className="font-medium">{totalQuantity}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Action:</span>
                    <span className="font-medium">
                      {activeTab === "new-order" ? "Create Order" : "Add to Existing"}
                    </span>
                  </div>
                </div>

                <Button
                  onClick={handleProcessCheckout}
                  disabled={checkout.isPending}
                  className="w-full mt-4 bg-emerald-600 hover:bg-emerald-700"
                  data-testid="button-process-checkout"
                >
                  <CheckCircle2 className="h-4 w-4 mr-2" />
                  {checkout.isPending ? "Processing..." : 
                   activeTab === "new-order" ? "Create Order" : "Add to Order"}
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}