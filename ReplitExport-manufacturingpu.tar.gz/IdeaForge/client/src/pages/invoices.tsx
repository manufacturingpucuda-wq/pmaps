import { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { FileText, Download, Printer, Plus, Save, Trash2 } from "lucide-react";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

interface InvoiceData {
  invoiceTitle: string;
  companyName: string;
  companyAddress: string;
  companyCity: string;
  companyState: string;
  companyZip: string;
  companyPhone: string;
  companyEmail: string;
  companyWebsite: string;
  invoiceNumber: string;
  date: string;
  dueDate: string;
  paymentTerms: string;
  customerName: string;
  customerAddress: string;
  customerCity: string;
  customerState: string;
  customerZip: string;
  customerPhone: string;
  customerEmail: string;
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  notes: string;
}

export default function Invoices() {
  const { toast } = useToast();
  const invoiceRef = useRef<HTMLDivElement>(null);
  
  const [invoiceData, setInvoiceData] = useState<InvoiceData>({
    invoiceTitle: "INVOICE",
    companyName: "PUCUDA MFG",
    companyAddress: "123 Industrial Way",
    companyCity: "Miami",
    companyState: "FL",
    companyZip: "33101",
    companyPhone: "(305) 555-0123",
    companyEmail: "billing@pucudamfg.com", 
    companyWebsite: "www.pucudamfg.com",
    invoiceNumber: `INV-${Date.now()}`,
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    paymentTerms: "Net 30",
    customerName: "",
    customerAddress: "",
    customerCity: "",
    customerState: "",
    customerZip: "",
    customerPhone: "",
    customerEmail: "",
    items: [
      {
        id: "1",
        description: "Safety Net Installation",
        quantity: 1,
        unitPrice: 500.00,
        total: 500.00
      }
    ],
    subtotal: 500.00,
    taxRate: 8.5,
    taxAmount: 42.50,
    total: 542.50,
    notes: ""
  });

  // Calculate totals when items change
  const updateTotals = (items: InvoiceItem[]) => {
    const subtotal = items.reduce((sum, item) => sum + item.total, 0);
    const taxAmount = subtotal * (invoiceData.taxRate / 100);
    const total = subtotal + taxAmount;
    
    setInvoiceData(prev => ({
      ...prev,
      subtotal,
      taxAmount,
      total
    }));
  };

  const updateInvoiceItem = (id: string, field: keyof InvoiceItem, value: string | number) => {
    const updatedItems = invoiceData.items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          updatedItem.total = updatedItem.quantity * updatedItem.unitPrice;
        }
        return updatedItem;
      }
      return item;
    });
    
    setInvoiceData(prev => ({ ...prev, items: updatedItems }));
    updateTotals(updatedItems);
  };

  const addInvoiceItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: "",
      quantity: 1,
      unitPrice: 0,
      total: 0
    };
    
    const updatedItems = [...invoiceData.items, newItem];
    setInvoiceData(prev => ({ ...prev, items: updatedItems }));
    updateTotals(updatedItems);
  };

  const removeInvoiceItem = (id: string) => {
    if (invoiceData.items.length === 1) return;
    
    const updatedItems = invoiceData.items.filter(item => item.id !== id);
    setInvoiceData(prev => ({ ...prev, items: updatedItems }));
    updateTotals(updatedItems);
  };

  const saveInvoice = () => {
    const invoices = JSON.parse(localStorage.getItem('invoices') || '[]');
    const savedInvoice = {
      ...invoiceData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString()
    };
    
    invoices.push(savedInvoice);
    localStorage.setItem('invoices', JSON.stringify(invoices));
    
    toast({
      title: "Invoice Saved",
      description: "Invoice has been saved successfully",
    });
  };

  const generatePDF = async () => {
    if (!invoiceRef.current) return;

    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        backgroundColor: '#ffffff'
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const pageHeight = 295;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      pdf.save(`invoice-${invoiceData.invoiceNumber}.pdf`);
      
      toast({
        title: "PDF Generated",
        description: "Invoice PDF downloaded successfully",
      });
    } catch (error) {
      toast({
        title: "PDF Generation Failed",
        description: "Could not generate PDF. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Print functionality
  const printInvoice = () => {
    window.print();
  };

  return (
    <div className="p-6 max-w-full mx-auto">
      <div className="mb-6">
        <h1 className="text-3xl font-bold">Invoice Editor & PDF Generator</h1>
        <p className="text-muted-foreground">Create and manage professional invoices</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center">
              <FileText className="h-5 w-5 mr-2" />
              Invoice Editor & PDF Generator
            </div>
            <div className="flex space-x-2">
              <Button onClick={saveInvoice} variant="outline" size="sm" className="print-hide" data-testid="button-save-invoice">
                <Save className="h-4 w-4 mr-2" />
                Save
              </Button>
              <Button onClick={printInvoice} variant="outline" size="sm" className="print-hide" data-testid="button-print-invoice">
                <Printer className="h-4 w-4 mr-2" />
                Print
              </Button>
              <Button onClick={generatePDF} size="sm" className="print-hide" data-testid="button-generate-pdf">
                <Download className="h-4 w-4 mr-2" />
                Generate PDF
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Invoice Form */}
            <div className="space-y-6">
              {/* Invoice Title */}
              <div>
                <Label htmlFor="invoiceTitle">Invoice Title</Label>
                <Input
                  id="invoiceTitle"
                  value={invoiceData.invoiceTitle}
                  onChange={(e) => setInvoiceData(prev => ({ ...prev, invoiceTitle: e.target.value }))}
                  data-testid="input-invoice-title"
                />
              </div>

              {/* Company Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Your Company (From)</h3>
                
                <div>
                  <Label htmlFor="companyName">Company Name</Label>
                  <Input
                    id="companyName"
                    value={invoiceData.companyName}
                    onChange={(e) => setInvoiceData(prev => ({ ...prev, companyName: e.target.value }))}
                    data-testid="input-company-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="companyAddress">Company Address</Label>
                  <Input
                    id="companyAddress"
                    value={invoiceData.companyAddress}
                    onChange={(e) => setInvoiceData(prev => ({ ...prev, companyAddress: e.target.value }))}
                    data-testid="input-company-address"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="companyCity">City</Label>
                    <Input
                      id="companyCity"
                      value={invoiceData.companyCity}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyCity: e.target.value }))}
                      data-testid="input-company-city"
                    />
                  </div>
                  <div>
                    <Label htmlFor="companyState">State</Label>
                    <Input
                      id="companyState"
                      value={invoiceData.companyState}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyState: e.target.value }))}
                      data-testid="input-company-state"
                    />
                  </div>
                  <div>
                    <Label htmlFor="companyZip">ZIP</Label>
                    <Input
                      id="companyZip"
                      value={invoiceData.companyZip}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyZip: e.target.value }))}
                      data-testid="input-company-zip"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="companyPhone">Phone</Label>
                    <Input
                      id="companyPhone"
                      value={invoiceData.companyPhone}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyPhone: e.target.value }))}
                      data-testid="input-company-phone"
                    />
                  </div>
                  <div>
                    <Label htmlFor="companyEmail">Email</Label>
                    <Input
                      id="companyEmail"
                      value={invoiceData.companyEmail}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyEmail: e.target.value }))}
                      data-testid="input-company-email"
                    />
                  </div>
                  <div>
                    <Label htmlFor="companyWebsite">Website</Label>
                    <Input
                      id="companyWebsite"
                      value={invoiceData.companyWebsite}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, companyWebsite: e.target.value }))}
                      data-testid="input-company-website"
                    />
                  </div>
                </div>
              </div>

              {/* Invoice Details */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Invoice Details</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="invoiceNumber">Invoice Number</Label>
                    <Input
                      id="invoiceNumber"
                      value={invoiceData.invoiceNumber}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, invoiceNumber: e.target.value }))}
                      data-testid="input-invoice-number"
                    />
                  </div>
                  <div>
                    <Label htmlFor="paymentTerms">Payment Terms</Label>
                    <Input
                      id="paymentTerms"
                      value={invoiceData.paymentTerms}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, paymentTerms: e.target.value }))}
                      data-testid="input-payment-terms"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="date">Invoice Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={invoiceData.date}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, date: e.target.value }))}
                      data-testid="input-invoice-date"
                    />
                  </div>
                  <div>
                    <Label htmlFor="dueDate">Due Date</Label>
                    <Input
                      id="dueDate"
                      type="date"
                      value={invoiceData.dueDate}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, dueDate: e.target.value }))}
                      data-testid="input-due-date"
                    />
                  </div>
                </div>
              </div>

              {/* Customer Information */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Customer (Bill To)</h3>
                
                <div>
                  <Label htmlFor="customerName">Customer Name</Label>
                  <Input
                    id="customerName"
                    value={invoiceData.customerName}
                    onChange={(e) => setInvoiceData(prev => ({ ...prev, customerName: e.target.value }))}
                    data-testid="input-customer-name"
                  />
                </div>
                
                <div>
                  <Label htmlFor="customerAddress">Customer Address</Label>
                  <Input
                    id="customerAddress"
                    value={invoiceData.customerAddress}
                    onChange={(e) => setInvoiceData(prev => ({ ...prev, customerAddress: e.target.value }))}
                    data-testid="input-customer-address"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="customerCity">City</Label>
                    <Input
                      id="customerCity"
                      value={invoiceData.customerCity}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, customerCity: e.target.value }))}
                      data-testid="input-customer-city"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customerState">State</Label>
                    <Input
                      id="customerState"
                      value={invoiceData.customerState}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, customerState: e.target.value }))}
                      data-testid="input-customer-state"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customerZip">ZIP</Label>
                    <Input
                      id="customerZip"
                      value={invoiceData.customerZip}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, customerZip: e.target.value }))}
                      data-testid="input-customer-zip"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="customerPhone">Phone</Label>
                    <Input
                      id="customerPhone"
                      value={invoiceData.customerPhone}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, customerPhone: e.target.value }))}
                      data-testid="input-customer-phone"
                    />
                  </div>
                  <div>
                    <Label htmlFor="customerEmail">Email</Label>
                    <Input
                      id="customerEmail"
                      value={invoiceData.customerEmail}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, customerEmail: e.target.value }))}
                      data-testid="input-customer-email"
                    />
                  </div>
                </div>
              </div>

              {/* Invoice Items */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">Invoice Items</h3>
                
                {invoiceData.items.map((item) => (
                  <div key={item.id} className="grid grid-cols-12 gap-4 items-end">
                    <div className="col-span-5">
                      <Label>Description</Label>
                      <Input
                        value={item.description}
                        onChange={(e) => updateInvoiceItem(item.id, 'description', e.target.value)}
                        placeholder="Item description..."
                        data-testid={`input-item-description-${item.id}`}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Quantity</Label>
                      <Input
                        type="number"
                        value={item.quantity}
                        onChange={(e) => updateInvoiceItem(item.id, 'quantity', parseFloat(e.target.value) || 0)}
                        min="0"
                        step="1"
                        data-testid={`input-item-quantity-${item.id}`}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Unit Price</Label>
                      <Input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) => updateInvoiceItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                        min="0"
                        step="0.01"
                        data-testid={`input-item-unit-price-${item.id}`}
                      />
                    </div>
                    <div className="col-span-2">
                      <Label>Total</Label>
                      <Input
                        value={`$${item.total.toFixed(2)}`}
                        disabled
                        data-testid={`text-item-total-${item.id}`}
                      />
                    </div>
                    <div className="col-span-1">
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => removeInvoiceItem(item.id)}
                        disabled={invoiceData.items.length === 1}
                        data-testid={`button-remove-item-${item.id}`}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                <Button onClick={addInvoiceItem} variant="outline" size="sm" data-testid="button-add-item">
                  <Plus className="h-4 w-4 mr-2" />
                  Add Item
                </Button>

                {/* Tax Rate */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="taxRate">Tax Rate (%)</Label>
                    <Input
                      id="taxRate"
                      type="number"
                      value={invoiceData.taxRate}
                      onChange={(e) => {
                        const rate = parseFloat(e.target.value) || 0;
                        setInvoiceData(prev => ({ ...prev, taxRate: rate }));
                        updateTotals(invoiceData.items);
                      }}
                      min="0"
                      step="0.1"
                      data-testid="input-tax-rate"
                    />
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea
                    id="notes"
                    value={invoiceData.notes}
                    onChange={(e) => setInvoiceData(prev => ({ ...prev, notes: e.target.value }))}
                    placeholder="Additional notes or terms..."
                    data-testid="textarea-notes"
                  />
                </div>
              </div>
            </div>

            {/* Invoice Preview */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Invoice Preview</h3>
              <div ref={invoiceRef} className="invoice-container bg-white p-8 border-2 border-gray-200 rounded-lg shadow-lg">
                {/* Invoice Header */}
                <div className="invoice-header text-center mb-8 border-b-2 border-orange-600 pb-6 print-no-break">
                  <h1 className="text-4xl font-bold text-black mb-4 print:text-3xl">{invoiceData.invoiceTitle}</h1>
                  <div className="text-2xl font-bold text-orange-600 mb-2 print:text-xl print:text-black">{invoiceData.companyName}</div>
                  <div className="text-sm text-black font-medium print:text-sm">Safety Netting Manufacturer</div>
                </div>

                {/* Company and Customer Info */}
                <div className="invoice-body grid grid-cols-2 gap-8 mb-8 print-no-break">
                  {/* From Section */}
                  <div>
                    <h3 className="text-lg font-bold text-black mb-3 border-b border-gray-300 pb-1 print:text-base print:border-black">FROM:</h3>
                    <div className="text-sm text-black space-y-1 print:text-sm">
                      <div className="font-bold text-base print:text-sm print:font-bold">{invoiceData.companyName}</div>
                      <div>{invoiceData.companyAddress}</div>
                      <div>
                        {invoiceData.companyCity}, {invoiceData.companyState} {invoiceData.companyZip}
                      </div>
                      {invoiceData.companyPhone && <div>Phone: {invoiceData.companyPhone}</div>}
                      {invoiceData.companyEmail && <div>Email: {invoiceData.companyEmail}</div>}
                      {invoiceData.companyWebsite && <div>Website: {invoiceData.companyWebsite}</div>}
                    </div>
                  </div>
                  
                  {/* Bill To Section */}
                  <div>
                    <h3 className="text-lg font-bold text-black mb-3 border-b border-gray-300 pb-1 print:text-base print:border-black">BILL TO:</h3>
                    <div className="text-sm text-black space-y-1 print:text-sm">
                      <div className="font-bold text-base print:text-sm print:font-bold">{invoiceData.customerName || 'Customer Name'}</div>
                      <div>{invoiceData.customerAddress}</div>
                      <div>
                        {invoiceData.customerCity && `${invoiceData.customerCity}, `}
                        {invoiceData.customerState} {invoiceData.customerZip}
                      </div>
                      {invoiceData.customerPhone && <div>Phone: {invoiceData.customerPhone}</div>}
                      {invoiceData.customerEmail && <div>Email: {invoiceData.customerEmail}</div>}
                    </div>
                  </div>
                </div>

                {/* Invoice Details */}
                <div className="grid grid-cols-2 gap-8 mb-8 print-no-break">
                  <div></div>
                  <div className="bg-gray-50 p-4 rounded print:bg-white print:border print:border-black print:p-3">
                    <div className="space-y-2 text-sm text-black print:space-y-1">
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Invoice Number:</span> 
                        <span className="font-mono">{invoiceData.invoiceNumber}</span>
                      </div>
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Invoice Date:</span> 
                        <span>{new Date(invoiceData.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Due Date:</span> 
                        <span>{new Date(invoiceData.dueDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Payment Terms:</span> 
                        <span>{invoiceData.paymentTerms}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Invoice Table */}
                <table className="w-full border-collapse border-2 border-black mb-6 print:border print:border-black print:mb-4">
                  <thead>
                    <tr className="bg-orange-600 text-white print:bg-gray-200 print:text-black">
                      <th className="border border-black px-4 py-3 text-left font-bold print:px-2 print:py-2 print:text-sm print:border-black">DESCRIPTION</th>
                      <th className="border border-black px-4 py-3 text-center font-bold print:px-2 print:py-2 print:text-sm print:border-black">QTY</th>
                      <th className="border border-black px-4 py-3 text-right font-bold print:px-2 print:py-2 print:text-sm print:border-black">UNIT PRICE</th>
                      <th className="border border-black px-4 py-3 text-right font-bold print:px-2 print:py-2 print:text-sm print:border-black">TOTAL</th>
                    </tr>
                  </thead>
                  <tbody>
                    {invoiceData.items.map((item, index) => (
                      <tr key={item.id} className={index % 2 === 0 ? "bg-white print:bg-white" : "bg-gray-50 print:bg-white"}>
                        <td className="border border-gray-400 px-4 py-3 text-black print:border-black print:px-2 print:py-2 print:text-sm">{item.description || 'Item description'}</td>
                        <td className="border border-gray-400 px-4 py-3 text-center text-black print:border-black print:px-2 print:py-2 print:text-sm">{item.quantity}</td>
                        <td className="border border-gray-400 px-4 py-3 text-right text-black print:border-black print:px-2 print:py-2 print:text-sm">${item.unitPrice.toFixed(2)}</td>
                        <td className="border border-gray-400 px-4 py-3 text-right text-black font-semibold print:border-black print:px-2 print:py-2 print:text-sm print:font-bold">${item.total.toFixed(2)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Invoice Totals */}
                <div className="invoice-totals flex justify-end mb-8 print-no-break">
                  <div className="w-64 bg-gray-50 p-4 rounded border print:bg-white print:border-2 print:border-black print:w-auto print:min-w-48 print:p-3">
                    <div className="space-y-2 text-black print:space-y-1">
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Subtotal:</span> 
                        <span className="font-mono">${invoiceData.subtotal.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between print:text-sm">
                        <span className="font-semibold">Tax ({invoiceData.taxRate}%):</span> 
                        <span className="font-mono">${invoiceData.taxAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-xl font-bold border-t-2 border-black pt-2 print:text-lg print:border-t-2 print:border-black print:pt-1">
                        <span>TOTAL:</span> 
                        <span className="font-mono">${invoiceData.total.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Notes and Payment Terms */}
                {(invoiceData.notes || invoiceData.paymentTerms) && (
                  <div className="border-t-2 border-gray-300 pt-6 print:border-t print:border-black print:pt-4">
                    {invoiceData.notes && (
                      <div className="mb-4 print-no-break">
                        <div className="font-bold text-black mb-2 print:text-sm">NOTES:</div>
                        <div className="text-sm text-black whitespace-pre-line bg-gray-50 p-3 rounded print:bg-white print:border print:border-black print:p-2 print:text-sm">
                          {invoiceData.notes}
                        </div>
                      </div>
                    )}
                    
                    <div className="text-center">
                      <div className="text-sm text-black print:text-sm">
                        <span className="font-semibold">Payment Terms:</span> {invoiceData.paymentTerms}
                      </div>
                      <div className="text-xs text-gray-600 mt-2 print:text-black print:text-sm print:mt-1">
                        Thank you for your business!
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}