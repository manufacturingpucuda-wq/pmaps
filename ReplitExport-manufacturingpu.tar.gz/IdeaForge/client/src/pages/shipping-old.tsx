import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Plus, Search, Truck, Package, FileText, Download, Eye, Edit, Trash2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PalletBoxForm } from "@/components/pallet-box-form";

// Mock data for shipments
const mockShipments = [
  {
    id: "1",
    shipmentNumber: "SH-2025-001",
    orderId: "ORD-001",
    customerName: "ABC Manufacturing",
    customerAddress: "123 Industrial Blvd",
    customerCity: "Detroit",
    customerState: "MI",
    customerZip: "48201",
    shippingMethod: "ground",
    carrier: "ups",
    trackingNumber: "1Z123456789",
    weight: 150,
    dimensions: "24x18x12",
    shippingCost: 2500, // in cents
    status: "shipped",
    scheduledPickup: new Date(),
    actualPickup: new Date(),
    estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000),
    bolGenerated: true,
    createdAt: new Date(),
  },
];

const palletBoxItemSchema = z.object({
  qty: z.number().min(0, "Quantity must be positive"),
  length: z.number().min(0, "Length must be positive"),
  width: z.number().min(0, "Width must be positive"),
  height: z.number().min(0, "Height must be positive"),
  weight: z.number().min(0, "Weight must be positive"),
});

const shipmentSchema = z.object({
  salesOrderNumber: z.string().min(1, "Sales order number is required"),
  customerName: z.string().min(1, "Customer name is required"),
  palletBoxItems: z.array(palletBoxItemSchema).min(1, "At least one pallet/box item is required"),
  totalQty: z.number().min(0, "Total quantity must be positive"),
  totalWeight: z.number().min(0, "Total weight must be positive"),
  notes: z.string().optional(),
  completedBy: z.string().min(1, "Completed by is required"),
  completedDate: z.string().min(1, "Completed date is required"),
  supervisor: z.string().min(1, "Supervisor is required"),
});

type ShipmentFormData = z.infer<typeof shipmentSchema>;

export default function Shipping() {
  const [shipments, setShipments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showBOLModal, setShowBOLModal] = useState(false);
  const [selectedShipment, setSelectedShipment] = useState<any>(null);
  const [editingShipment, setEditingShipment] = useState<any>(null);
  const { toast } = useToast();

  // Load shipments from API
  useEffect(() => {
    const loadShipments = async () => {
      try {
        const response = await fetch("/api/shipments", {
          credentials: "include",
        });
        
        if (response.ok) {
          const data = await response.json();
          setShipments(data);
        } else {
          console.error("Failed to load shipments");
          // Fall back to mock data if API fails
          setShipments(mockShipments);
        }
      } catch (error) {
        console.error("Error loading shipments:", error);
        // Fall back to mock data if API fails
        setShipments(mockShipments);
      } finally {
        setLoading(false);
      }
    };

    loadShipments();
  }, []);

  const form = useForm<ShipmentFormData>({
    resolver: zodResolver(shipmentSchema),
    defaultValues: {
      salesOrderNumber: "",
      customerName: "",
      palletBoxItems: [
        { qty: 0, length: 0, width: 0, height: 0, weight: 0 }
      ],
      totalQty: 0,
      totalWeight: 0,
      notes: "",
      completedBy: "",
      completedDate: new Date().toISOString().split('T')[0],
      supervisor: "",
    },
  });

  const filteredShipments = shipments.filter(shipment => {
    if (search && !shipment.shipmentNumber.toLowerCase().includes(search.toLowerCase()) && 
        !shipment.customerName.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (statusFilter && statusFilter !== "all" && shipment.status !== statusFilter) {
      return false;
    }
    return true;
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      pending: "bg-yellow-600 text-white",
      picked: "bg-blue-600 text-white",
      packed: "bg-purple-600 text-white",
      shipped: "bg-green-600 text-white",
      delivered: "bg-emerald-600 text-white",
      returned: "bg-red-600 text-white",
    };
    return (
      <Badge className={variants[status as keyof typeof variants] || "bg-gray-600 text-white"}>
        {status.charAt(0).toUpperCase() + status.slice(1)}
      </Badge>
    );
  };

  const handleCreateShipment = async (data: ShipmentFormData) => {
    try {
      const response = await fetch("/api/shipments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Failed to create shipment");
      }

      const newShipment = await response.json();
      console.log("Shipment created:", newShipment);
      
      toast({
        title: "Success",
        description: "Shipment created successfully",
      });
      setShowCreateModal(false);
      form.reset();
      
      // Add the new shipment to the current list
      setShipments(prev => [newShipment, ...prev]);
    } catch (error) {
      console.error("Error creating shipment:", error);
      toast({
        title: "Error",
        description: "Failed to create shipment",
        variant: "destructive",
      });
    }
  };

  const addPalletBoxItem = () => {
    const currentItems = form.getValues('palletBoxItems');
    form.setValue('palletBoxItems', [...currentItems, { qty: 0, length: 0, width: 0, height: 0, weight: 0 }]);
  };

  const removePalletBoxItem = (index: number) => {
    const currentItems = form.getValues('palletBoxItems');
    if (currentItems.length > 1) {
      const newItems = currentItems.filter((_, i) => i !== index);
      form.setValue('palletBoxItems', newItems);
    }
  };

  const handleEditShipment = (shipment: any) => {
    setEditingShipment(shipment);
    form.reset({
      customerName: shipment.customerName,
      customerAddress: shipment.customerAddress,
      customerCity: shipment.customerCity,
      customerState: shipment.customerState,
      customerZip: shipment.customerZip,
      customerPhone: shipment.customerPhone || "",
      customerEmail: shipment.customerEmail || "",
      shippingMethod: shipment.shippingMethod,
      carrier: shipment.carrier,
      trackingNumber: shipment.trackingNumber || "",
      weight: shipment.weight || 0,
      dimensions: shipment.dimensions || "",
      shippingCost: shipment.shippingCost ? shipment.shippingCost / 100 : 0,
      insuranceValue: shipment.insuranceValue || 0,
      priority: shipment.priority || "standard",
      specialInstructions: shipment.specialInstructions || "",
      scheduledPickup: shipment.scheduledPickup ? shipment.scheduledPickup.toISOString().slice(0, 16) : "",
      estimatedDelivery: shipment.estimatedDelivery ? shipment.estimatedDelivery.toISOString().slice(0, 16) : "",
      notes: shipment.notes || "",
    });
    setShowEditModal(true);
  };

  const handleUpdateShipment = async (data: ShipmentFormData) => {
    try {
      if (!editingShipment?.id) {
        throw new Error("No shipment selected for editing");
      }

      const response = await fetch(`/api/shipments/${editingShipment.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify(data),
      });

      if (!response.ok) {
        throw new Error("Failed to update shipment");
      }

      const updatedShipment = await response.json();
      console.log("Shipment updated:", updatedShipment);
      
      toast({
        title: "Success",
        description: "Shipment updated successfully",
      });
      setShowEditModal(false);
      setEditingShipment(null);
      form.reset();
      
      // Update the shipment in the current list
      setShipments(prev => prev.map(s => s.id === editingShipment.id ? updatedShipment : s));
    } catch (error) {
      console.error("Error updating shipment:", error);
      toast({
        title: "Error",
        description: "Failed to update shipment",
        variant: "destructive",
      });
    }
  };

  const handleDeleteShipment = async (shipmentId: string, shipmentNumber: string) => {
    if (confirm(`Are you sure you want to delete shipment ${shipmentNumber}? This action cannot be undone.`)) {
      try {
        const response = await fetch(`/api/shipments/${shipmentId}`, {
          method: 'DELETE',
          credentials: 'include',
        });

        if (!response.ok) {
          throw new Error('Failed to delete shipment');
        }

        toast({
          title: "Success",
          description: `Shipment ${shipmentNumber} deleted successfully`,
        });
        
        // Remove the deleted shipment from the current list
        setShipments(prev => prev.filter(s => s.id !== shipmentId));
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete shipment",
          variant: "destructive",
        });
      }
    }
  };

  const handleGenerateBOL = (shipment: any) => {
    setSelectedShipment(shipment);
    setShowBOLModal(true);
  };

  const generateBOLDocument = (shipment: any) => {
    // This would generate actual BOL document
    const bolContent = `
      BILL OF LADING
      
      Shipment Number: ${shipment.shipmentNumber}
      Date: ${new Date().toLocaleDateString()}
      
      SHIPPER:
      PUCUDA Manufacturing
      [Company Address]
      
      CONSIGNEE:
      ${shipment.customerName}
      ${shipment.customerAddress}
      ${shipment.customerCity}, ${shipment.customerState} ${shipment.customerZip}
      
      CARRIER: ${shipment.carrier.toUpperCase()}
      SERVICE: ${shipment.shippingMethod}
      
      PACKAGE DETAILS:
      Weight: ${shipment.weight} lbs
      Dimensions: ${shipment.dimensions}
      
      TRACKING: ${shipment.trackingNumber}
      
      This shipment contains manufactured goods as described in the attached order.
      
      Authorized Signature: _________________
      Date: ${new Date().toLocaleDateString()}
    `;

    // Download as text file (in real app, would generate PDF)
    const blob = new Blob([bolContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `BOL-${shipment.shipmentNumber}.txt`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: "BOL Generated",
      description: `Bill of Lading for ${shipment.shipmentNumber} has been downloaded`,
    });
  };

  const ShipmentForm = () => (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleCreateShipment)} className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerName"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer Name</FormLabel>
                <FormControl>
                  <Input {...field} data-testid="input-customer-name" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="customerAddress"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Address</FormLabel>
                <FormControl>
                  <Input {...field} data-testid="input-customer-address" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="customerPhone"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer Phone</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="(555) 123-4567" data-testid="input-customer-phone" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="customerEmail"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Customer Email</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="customer@company.com" data-testid="input-customer-email" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="customerCity"
            render={({ field }) => (
              <FormItem>
                <FormLabel>City</FormLabel>
                <FormControl>
                  <Input {...field} data-testid="input-customer-city" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="customerState"
            render={({ field }) => (
              <FormItem>
                <FormLabel>State</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="MI" data-testid="input-customer-state" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="customerZip"
            render={({ field }) => (
              <FormItem>
                <FormLabel>ZIP Code</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="48201" data-testid="input-customer-zip" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-3 gap-4">
          <FormField
            control={form.control}
            name="shippingMethod"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Shipping Method</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-shipping-method">
                      <SelectValue placeholder="Select method" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="ground">Ground</SelectItem>
                    <SelectItem value="express">Express</SelectItem>
                    <SelectItem value="overnight">Overnight</SelectItem>
                    <SelectItem value="freight">Freight</SelectItem>
                    <SelectItem value="pickup">Customer Pickup</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="carrier"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Carrier</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-carrier">
                      <SelectValue placeholder="Select carrier" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="ups">UPS</SelectItem>
                    <SelectItem value="fedex">FedEx</SelectItem>
                    <SelectItem value="usps">USPS</SelectItem>
                    <SelectItem value="dhl">DHL</SelectItem>
                    <SelectItem value="freight">Freight Company</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="priority"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Priority</FormLabel>
                <Select onValueChange={field.onChange} value={field.value}>
                  <FormControl>
                    <SelectTrigger data-testid="select-priority">
                      <SelectValue placeholder="Select priority" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="expedited">Expedited</SelectItem>
                    <SelectItem value="rush">Rush</SelectItem>
                    <SelectItem value="urgent">Urgent</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="trackingNumber"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Tracking Number</FormLabel>
              <FormControl>
                <Input {...field} placeholder="1Z999AA1234567890" data-testid="input-tracking-number" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="weight"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Weight (lbs)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.1"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    data-testid="input-weight" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="dimensions"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Dimensions (L x W x H)</FormLabel>
                <FormControl>
                  <Input {...field} placeholder="24 x 18 x 12" data-testid="input-dimensions" />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="shippingCost"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Shipping Cost ($)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    data-testid="input-shipping-cost" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="insuranceValue"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Insurance Value ($)</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    step="0.01"
                    {...field} 
                    onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                    placeholder="0.00"
                    data-testid="input-insurance-value" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="scheduledPickup"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Scheduled Pickup</FormLabel>
                <FormControl>
                  <Input 
                    type="datetime-local" 
                    {...field} 
                    data-testid="input-pickup-date" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="estimatedDelivery"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Estimated Delivery</FormLabel>
                <FormControl>
                  <Input 
                    type="datetime-local" 
                    {...field} 
                    data-testid="input-estimated-delivery" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <FormField
          control={form.control}
          name="specialInstructions"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Special Instructions</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Any special handling instructions..." data-testid="textarea-special-instructions" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="notes"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Notes</FormLabel>
              <FormControl>
                <Textarea {...field} placeholder="Additional notes about this shipment..." data-testid="textarea-notes" />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="flex justify-end space-x-2 pt-4">
          <Button
            type="button"
            variant="outline"
            onClick={() => setShowCreateModal(false)}
            data-testid="button-cancel-shipment"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-primary hover:bg-primary/90"
            data-testid="button-save-shipment"
          >
            {editingShipment ? "Update Shipment" : "Create Shipment"}
          </Button>
        </div>
      </form>
    </Form>
  );

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-2xl font-bold flex items-center">
              <Truck className="h-6 w-6 mr-2" />
              Shipping Management
            </CardTitle>
            <Button 
              onClick={() => setShowCreateModal(true)}
              className="bg-primary hover:bg-primary/90"
              data-testid="button-create-shipment"
            >
              <Plus className="h-4 w-4 mr-2" />
              New Shipment
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex space-x-4 mb-6">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search shipments..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-shipment-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[200px]" data-testid="select-status-filter">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="picked">Picked</SelectItem>
                <SelectItem value="packed">Packed</SelectItem>
                <SelectItem value="shipped">Shipped</SelectItem>
                <SelectItem value="delivered">Delivered</SelectItem>
                <SelectItem value="returned">Returned</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Shipments Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Shipment #</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Destination</TableHead>
                  <TableHead>Carrier</TableHead>
                  <TableHead>Weight</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Tracking</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      Loading shipments...
                    </TableCell>
                  </TableRow>
                ) : filteredShipments.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center text-muted-foreground py-8">
                      No shipments found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredShipments.map((shipment) => (
                  <TableRow key={shipment.id}>
                    <TableCell className="font-mono">{shipment.shipmentNumber}</TableCell>
                    <TableCell>
                      <div>
                        <div className="font-medium">{shipment.customerName}</div>
                        <div className="text-sm text-muted-foreground">
                          Order: {shipment.orderId}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        {shipment.customerCity}, {shipment.customerState}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{shipment.carrier.toUpperCase()}</div>
                        <div className="text-muted-foreground">{shipment.shippingMethod}</div>
                      </div>
                    </TableCell>
                    <TableCell>{shipment.weight} lbs</TableCell>
                    <TableCell>{getStatusBadge(shipment.status)}</TableCell>
                    <TableCell>
                      {shipment.trackingNumber ? (
                        <div className="font-mono text-sm">{shipment.trackingNumber}</div>
                      ) : (
                        <span className="text-muted-foreground">-</span>
                      )}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleGenerateBOL(shipment)}
                          data-testid={`button-bol-${shipment.id}`}
                        >
                          <FileText className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditShipment(shipment)}
                          data-testid={`button-edit-shipment-${shipment.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteShipment(shipment.id, shipment.shipmentNumber)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                          data-testid={`button-delete-shipment-${shipment.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
      {/* Create Shipment Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-create-shipment">
          <DialogHeader>
            <DialogTitle>Create New Shipment</DialogTitle>
          </DialogHeader>
          <ShipmentForm />
        </DialogContent>
      </Dialog>
      {/* Edit Shipment Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto" data-testid="modal-edit-shipment">
          <DialogHeader>
            <DialogTitle>Edit Shipment</DialogTitle>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleUpdateShipment)} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Name</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-customer-name-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerAddress"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Address</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-customer-address-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="customerPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Phone</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="(555) 123-4567" data-testid="input-customer-phone-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerEmail"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Customer Email</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="customer@company.com" data-testid="input-customer-email-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="customerCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>City</FormLabel>
                      <FormControl>
                        <Input {...field} data-testid="input-customer-city-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerState"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>State</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="MI" data-testid="input-customer-state-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="customerZip"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ZIP Code</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="48201" data-testid="input-customer-zip-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-3 gap-4">
                <FormField
                  control={form.control}
                  name="shippingMethod"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Shipping Method</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-shipping-method-edit">
                            <SelectValue placeholder="Select method" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ground">Ground</SelectItem>
                          <SelectItem value="express">Express</SelectItem>
                          <SelectItem value="overnight">Overnight</SelectItem>
                          <SelectItem value="freight">Freight</SelectItem>
                          <SelectItem value="pickup">Customer Pickup</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="carrier"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Carrier</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-carrier-edit">
                            <SelectValue placeholder="Select carrier" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ups">UPS</SelectItem>
                          <SelectItem value="fedex">FedEx</SelectItem>
                          <SelectItem value="usps">USPS</SelectItem>
                          <SelectItem value="dhl">DHL</SelectItem>
                          <SelectItem value="freight">Freight Company</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-priority-edit">
                            <SelectValue placeholder="Select priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="standard">Standard</SelectItem>
                          <SelectItem value="expedited">Expedited</SelectItem>
                          <SelectItem value="rush">Rush</SelectItem>
                          <SelectItem value="urgent">Urgent</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="trackingNumber"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tracking Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="1Z999AA1234567890" data-testid="input-tracking-number-edit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="weight"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Weight (lbs)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.1"
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          data-testid="input-weight-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="dimensions"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Dimensions (L x W x H)</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="24 x 18 x 12" data-testid="input-dimensions-edit" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="shippingCost"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Shipping Cost ($)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          placeholder="0.00"
                          data-testid="input-shipping-cost-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="insuranceValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Insurance Value ($)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          {...field} 
                          onChange={(e) => field.onChange(parseFloat(e.target.value) || 0)}
                          placeholder="0.00"
                          data-testid="input-insurance-value-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="scheduledPickup"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Scheduled Pickup</FormLabel>
                      <FormControl>
                        <Input 
                          type="datetime-local" 
                          {...field} 
                          data-testid="input-pickup-date-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="estimatedDelivery"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Estimated Delivery</FormLabel>
                      <FormControl>
                        <Input 
                          type="datetime-local" 
                          {...field} 
                          data-testid="input-estimated-delivery-edit" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="specialInstructions"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Special Instructions</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Any special handling instructions..." data-testid="textarea-special-instructions-edit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea {...field} placeholder="Additional notes about this shipment..." data-testid="textarea-notes-edit" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end space-x-2 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowEditModal(false)}
                  data-testid="button-cancel-edit-shipment"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-update-shipment"
                >
                  Update Shipment
                </Button>
              </div>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
      {/* BOL Generation Modal */}
      <Dialog open={showBOLModal} onOpenChange={setShowBOLModal}>
        <DialogContent className="max-w-2xl" data-testid="modal-bol">
          <DialogHeader>
            <DialogTitle className="text-lg leading-none tracking-tight font-medium">Generate Bill of Lading</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground">
              Generating shipment: {selectedShipment?.shipmentNumber}
            </p>
            <div className="bg-muted p-4 rounded-lg">
              <h4 className="font-medium mb-2">Shipment Details:</h4>
              <div className="text-sm space-y-1">
                <div>Customer: {selectedShipment?.customerName}</div>
                <div>Weight: {selectedShipment?.weight} lbs</div>
                <div>Carrier: {selectedShipment?.carrier?.toUpperCase()}</div>
                <div>Method: {selectedShipment?.shippingMethod}</div>
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button
                variant="outline"
                onClick={() => setShowBOLModal(false)}
                data-testid="button-cancel-bol"
              >
                Cancel
              </Button>
              <Button
                onClick={() => {
                  generateBOLDocument(selectedShipment);
                  setShowBOLModal(false);
                }}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-generate-bol"
              >
                <Download className="h-4 w-4 mr-2" />
                Generate & Download BOL
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}