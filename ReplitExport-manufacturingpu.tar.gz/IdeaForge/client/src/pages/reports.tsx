import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useInventory } from "@/hooks/use-inventory";
import { useOrders } from "@/hooks/use-orders";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { Package, ShoppingCart, TrendingUp, AlertTriangle, Calendar, DollarSign } from "lucide-react";

export default function Reports() {
  const { data: items = [] } = useInventory();
  const { data: orders = [] } = useOrders();

  // Calculate inventory stats
  const totalItems = items.length;
  const totalStock = items.reduce((sum, item) => sum + item.currentStock, 0);
  const lowStockItems = items.filter(item => item.currentStock < 10).length;
  const outOfStockItems = items.filter(item => item.currentStock === 0).length;
  
  // Calculate order stats
  const totalOrders = orders.length;
  const pendingOrders = orders.filter(order => order.status === "pending").length;
  const fulfilledOrders = orders.filter(order => order.status === "fulfilled").length;
  
  // Top products by stock level
  const topProducts = items
    .sort((a, b) => b.currentStock - a.currentStock)
    .slice(0, 10)
    .map(item => ({
      name: item.sku,
      stock: item.currentStock,
      product: item.productName.length > 30 ? 
        item.productName.substring(0, 30) + "..." : 
        item.productName
    }));

  // Stock status distribution
  const stockDistribution = [
    { name: "In Stock", value: items.filter(item => item.currentStock > 10).length, color: "#10b981" },
    { name: "Low Stock", value: lowStockItems, color: "#f59e0b" },
    { name: "Out of Stock", value: outOfStockItems, color: "#ef4444" }
  ];

  // Recent activity (last 30 days)
  const thirtyDaysAgo = new Date();
  thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
  
  const recentOrders = orders.filter(order => 
    order.createdAt && new Date(order.createdAt) >= thirtyDaysAgo
  ).length;

  // Category analysis (based on SKU patterns)
  const categories = items.reduce((acc, item) => {
    let category = "Other";
    if (item.sku.includes("WEB")) category = "Webbing";
    else if (item.sku.includes("ROPE") || item.sku.includes("NSROPE") || item.sku.includes("SROPE")) category = "Rope";
    else if (item.sku.includes("CORD")) category = "Cord";
    else if (item.sku.includes("TWIST")) category = "Twisted";
    else if (item.sku.includes("HOOK") || item.sku.includes("SWEDGE") || item.sku.includes("GROMMET")) category = "Hardware";
    else if (item.sku.startsWith("80R") || item.sku.startsWith("20R")) category = "Rental Equipment";
    else if (item.sku.includes("K-") || item.sku.includes("P-")) category = "Industrial";
    
    acc[category] = (acc[category] || 0) + item.currentStock;
    return acc;
  }, {} as Record<string, number>);

  const categoryData = Object.entries(categories).map(([name, stock]) => ({
    name,
    stock
  })).sort((a, b) => b.stock - a.stock);

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-foreground">Reports & Analytics</h2>
        <div className="text-sm text-muted-foreground">
          Last Updated: {new Date().toLocaleString()}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-2 bg-blue-500/20 rounded-lg">
                <Package className="h-6 w-6 text-blue-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Items</p>
                <p className="text-2xl font-bold text-foreground">{totalItems.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-2 bg-green-500/20 rounded-lg">
                <TrendingUp className="h-6 w-6 text-green-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Stock</p>
                <p className="text-2xl font-bold text-foreground">{totalStock.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-2 bg-purple-500/20 rounded-lg">
                <ShoppingCart className="h-6 w-6 text-purple-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Total Orders</p>
                <p className="text-2xl font-bold text-foreground">{totalOrders}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="p-2 bg-orange-500/20 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-orange-500" />
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Low Stock Items</p>
                <p className="text-2xl font-bold text-foreground">{lowStockItems}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products Chart */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Package className="h-5 w-5" />
              <span>Top Products by Stock</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={topProducts}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis 
                    dataKey="name" 
                    stroke="#9CA3AF"
                    fontSize={12}
                    angle={-45}
                    textAnchor="end"
                    height={60}
                  />
                  <YAxis stroke="#9CA3AF" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                    formatter={(value, name, props) => [
                      `${value} units`,
                      props.payload.product
                    ]}
                    labelFormatter={(label) => `SKU: ${label}`}
                  />
                  <Bar dataKey="stock" fill="#3B82F6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Stock Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="h-5 w-5" />
              <span>Stock Status Distribution</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={stockDistribution}
                    cx="50%"
                    cy="50%"
                    outerRadius={100}
                    dataKey="value"
                    label={({ name, value, percent }) => 
                      `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                    }
                  >
                    {stockDistribution.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1F2937', 
                      border: '1px solid #374151',
                      borderRadius: '8px'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Category Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <BarChart className="h-5 w-5" />
            <span>Inventory by Category</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="horizontal">
                <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                <XAxis type="number" stroke="#9CA3AF" />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  stroke="#9CA3AF"
                  width={120}
                  fontSize={12}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#1F2937', 
                    border: '1px solid #374151',
                    borderRadius: '8px'
                  }}
                  formatter={(value) => [`${value} units`, 'Stock']}
                />
                <Bar dataKey="stock" fill="#10B981" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <ShoppingCart className="h-5 w-5" />
              <span>Order Status</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Pending Orders</span>
                <span className="font-semibold text-yellow-500">{pendingOrders}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Fulfilled Orders</span>
                <span className="font-semibold text-green-500">{fulfilledOrders}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Recent Orders (30 days)</span>
                <span className="font-semibold text-blue-500">{recentOrders}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <AlertTriangle className="h-5 w-5" />
              <span>Inventory Alerts</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Low Stock Items</span>
                <span className="font-semibold text-orange-500">{lowStockItems}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Out of Stock</span>
                <span className="font-semibold text-red-500">{outOfStockItems}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Well Stocked</span>
                <span className="font-semibold text-green-500">
                  {totalItems - lowStockItems - outOfStockItems}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Calendar className="h-5 w-5" />
              <span>System Overview</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Database Status</span>
                <span className="font-semibold text-green-500">Connected</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Last Sync</span>
                <span className="font-semibold text-blue-500">Live</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-muted-foreground">Total Value</span>
                <span className="font-semibold text-purple-500">
                  {totalStock.toLocaleString()} units
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}