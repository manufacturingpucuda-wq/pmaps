import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useInventory, useDeleteItem } from "@/hooks/use-inventory";
import { InventoryTable } from "@/components/inventory-table";
import { AddItemModal } from "@/components/add-item-modal";
import { EditItemModal } from "@/components/edit-item-modal";
import { BarcodeModal } from "@/components/barcode-modal";
import { QuickCheckoutModal } from "@/components/quick-checkout-modal";
import { CheckInModal } from "@/components/check-in-modal";
import { ItemTransactionHistory } from "@/components/item-transaction-history";
import { ReportsModal } from "@/components/reports-modal";
import { FillableFormsModal } from "@/components/fillable-forms";
import { useToast } from "@/hooks/use-toast";
import { Plus, Download, Layers, Search, FileText, Printer, Package, QrCode } from "lucide-react";
import type { ItemWithStatus } from "@shared/schema";

export default function Inventory() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [stockFilter, setStockFilter] = useState("");
  const [sortBy, setSortBy] = useState("sku");
  const [activeTab, setActiveTab] = useState("all");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showBarcodeModal, setShowBarcodeModal] = useState(false);
  const [showCheckoutModal, setShowCheckoutModal] = useState(false);
  const [showCheckinModal, setShowCheckinModal] = useState(false);
  const [showReportsModal, setShowReportsModal] = useState(false);
  const [showFormsModal, setShowFormsModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<ItemWithStatus | null>(null);

  const { data: items = [], isLoading } = useInventory();
  const deleteItem = useDeleteItem();
  const { toast } = useToast();

  // Get unique categories from items (filter out null/undefined)
  const categories = Array.from(new Set(items.map(item => item.category).filter((cat): cat is string => Boolean(cat))));
  
  // Group items by category
  const itemsByCategory = items.reduce((acc, item) => {
    const category = item.category || "Uncategorized";
    if (!acc[category]) acc[category] = [];
    acc[category].push(item);
    return acc;
  }, {} as Record<string, typeof items>);

  // Filter items based on current tab and filters
  const getFilteredItems = (categoryItems: typeof items) => categoryItems
    .filter(item => {
      if (search && !item.sku.toLowerCase().includes(search.toLowerCase()) && 
          !item.productName.toLowerCase().includes(search.toLowerCase())) {
        return false;
      }
      if (statusFilter && statusFilter !== "all" && item.status !== statusFilter) return false;
      if (stockFilter && stockFilter !== "all") {
        if (stockFilter === "in-stock" && item.availableStock <= 0) return false;
        if (stockFilter === "low-stock" && item.currentStock >= 10) return false;
        if (stockFilter === "out-of-stock" && item.currentStock > 0) return false;
      }
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "name": return a.productName.localeCompare(b.productName);
        case "stock": return b.currentStock - a.currentStock;
        case "status": return a.status.localeCompare(b.status);
        default: return a.sku.localeCompare(b.sku);
      }
    });

  // Get items for current tab
  const getCurrentTabItems = () => {
    if (activeTab === "all") {
      return getFilteredItems(items);
    }
    return getFilteredItems(itemsByCategory[activeTab] || []);
  };

  const handleDeleteItem = async (id: string) => {
    if (confirm("Are you sure you want to delete this item?")) {
      try {
        await deleteItem.mutateAsync(id);
        toast({
          title: "Success",
          description: "Item deleted successfully",
        });
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete item",
          variant: "destructive",
        });
      }
    }
  };

  const handleShowBarcode = (item: ItemWithStatus) => {
    setSelectedItem(item);
    setShowBarcodeModal(true);
  };

  const handleQuickCheckout = (item: ItemWithStatus) => {
    setSelectedItem(item);
    setShowCheckoutModal(true);
  };

  const handleEditItem = (item: ItemWithStatus) => {
    setSelectedItem(item);
    setShowEditModal(true);
  };

  const handleCheckIn = (item: ItemWithStatus) => {
    setSelectedItem(item);
    setShowCheckinModal(true);
  };

  const handlePrintAllBarcodes = async () => {
    try {
      toast({
        title: "Generating PDF",
        description: "Creating barcode sheet, please wait...",
      });

      // Dynamically import jsPDF
      const { jsPDF } = await import('jspdf');
      const pdf = new jsPDF();
      
      // PDF settings
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();
      const margin = 20;
      const barcodeWidth = 120;
      const barcodeHeight = 60;
      const cols = 4; // 4 barcodes per row
      const rows = 10; // 10 rows per page
      const spacingX = (pageWidth - 2 * margin) / cols;
      const spacingY = (pageHeight - 2 * margin) / rows;

      // Load JsBarcode if not already loaded
      if (!window.JsBarcode) {
        await new Promise((resolve, reject) => {
          const script = document.createElement('script');
          script.src = 'https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js';
          script.onload = resolve;
          script.onerror = reject;
          document.head.appendChild(script);
        });
      }

      let currentPage = 1;
      let currentRow = 0;
      let currentCol = 0;

      // Add title to first page
      pdf.setFontSize(16);
      pdf.text('PUCUDA MFG - Inventory Barcodes', pageWidth / 2, 15, { align: 'center' });

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        const barcodeValue = item.barcode || item.sku || item.id;

        // Skip items without valid barcode data
        if (!barcodeValue || barcodeValue.trim() === '') {
          console.warn('Skipping item without valid barcode data:', item.productName || 'Unknown item');
          continue;
        }

        // Create a temporary canvas for barcode generation
        const canvas = document.createElement('canvas');
        canvas.width = 300;
        canvas.height = 150;

        try {
          // Generate barcode on canvas
          window.JsBarcode(canvas, barcodeValue, {
            format: "CODE128",
            width: 2,
            height: 80,
            displayValue: true,
            fontSize: 12,
            margin: 5,
          });

          // Calculate position
          const x = margin + currentCol * spacingX;
          const y = margin + 20 + currentRow * spacingY; // 20 offset for title

          // Add barcode image to PDF
          const imgData = canvas.toDataURL('image/png');
          pdf.addImage(imgData, 'PNG', x, y, barcodeWidth, barcodeHeight);

          // Add item name below barcode
          pdf.setFontSize(8);
          const itemName = item.productName.length > 20 ? 
            item.productName.substring(0, 20) + '...' : 
            item.productName;
          pdf.text(itemName, x + barcodeWidth / 2, y + barcodeHeight + 8, { align: 'center' });

          // Move to next position
          currentCol++;
          if (currentCol >= cols) {
            currentCol = 0;
            currentRow++;
            if (currentRow >= rows) {
              // Start new page
              pdf.addPage();
              currentRow = 0;
              currentPage++;
              // Add title to new page
              pdf.setFontSize(16);
              pdf.text(`PUCUDA MFG - Inventory Barcodes (Page ${currentPage})`, pageWidth / 2, 15, { align: 'center' });
            }
          }
        } catch (error) {
          console.error('Error generating barcode for item:', item.productName || item.sku || 'Unknown', error);
        }
      }

      // Save the PDF
      const filename = `PUCUDA-Inventory-Barcodes-${new Date().toISOString().split('T')[0]}.pdf`;
      pdf.save(filename);

      toast({
        title: "Success",
        description: `PDF generated successfully! ${items.length} barcodes created.`,
      });

    } catch (error) {
      console.error('Error generating barcode PDF:', error);
      toast({
        title: "Error",
        description: "Failed to generate barcode PDF",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardContent className="p-6">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <h3 className="text-lg font-semibold text-foreground">Inventory Management</h3>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button 
                onClick={() => setShowAddModal(true)}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-add-item"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add Item
              </Button>
              <Button 
                onClick={() => setShowReportsModal(true)} 
                variant="outline"
                data-testid="button-reports"
              >
                <FileText className="h-4 w-4 mr-2" />
                Reports
              </Button>
              <Button 
                onClick={() => setShowFormsModal(true)} 
                variant="outline"
                data-testid="button-forms"
              >
                <Printer className="h-4 w-4 mr-2" />
                Forms
              </Button>
              <Button 
                onClick={handlePrintAllBarcodes}
                variant="outline"
                data-testid="button-print-all-barcodes"
              >
                <QrCode className="h-4 w-4 mr-2" />
                Print All Barcodes
              </Button>
              <Button variant="outline" data-testid="button-export-inventory">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>
          </div>
          
          {/* Search and Filters */}
          <div className="mt-4 grid grid-cols-1 lg:grid-cols-4 gap-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search SKU or Product Name..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-inventory-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger data-testid="select-status-filter">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="available">Available</SelectItem>
                <SelectItem value="reserved">Reserved</SelectItem>
                <SelectItem value="checked-out">Checked Out</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={stockFilter} onValueChange={setStockFilter}>
              <SelectTrigger data-testid="select-stock-filter">
                <SelectValue placeholder="All Stock Levels" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Stock Levels</SelectItem>
                <SelectItem value="in-stock">In Stock</SelectItem>
                <SelectItem value="low-stock">Low Stock</SelectItem>
                <SelectItem value="out-of-stock">Out of Stock</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger data-testid="select-sort-by">
                <SelectValue placeholder="Sort by SKU" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sku">Sort by SKU</SelectItem>
                <SelectItem value="name">Sort by Name</SelectItem>
                <SelectItem value="stock">Sort by Stock</SelectItem>
                <SelectItem value="status">Sort by Status</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabbed Inventory */}
      <Card>
        <CardContent className="p-0">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <div className="border-b">
              <TabsList className="h-12 p-1 bg-transparent w-full justify-start rounded-none">
                <TabsTrigger 
                  value="all" 
                  className="data-[state=active]:bg-background data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                  data-testid="tab-all-items"
                >
                  <Package className="h-4 w-4 mr-2" />
                  All Items ({items.length})
                </TabsTrigger>
                
                {["Uncategorized", ...categories].map((category) => {
                  const categoryItems = itemsByCategory[category] || [];
                  const safeCategoryName = category || "Uncategorized";
                  return (
                    <TabsTrigger
                      key={safeCategoryName}
                      value={safeCategoryName}
                      className="data-[state=active]:bg-background data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none"
                      data-testid={`tab-${safeCategoryName.toLowerCase().replace(/\s+/g, '-')}`}
                    >
                      {safeCategoryName} ({categoryItems.length})
                    </TabsTrigger>
                  );
                })}
              </TabsList>
            </div>
            
            <TabsContent value={activeTab} className="mt-0">
              <InventoryTable
                items={getCurrentTabItems()}
                isLoading={isLoading}
                onDelete={handleDeleteItem}
                onShowBarcode={handleShowBarcode}
                onQuickCheckout={handleQuickCheckout}
                onCheckIn={handleCheckIn}
                onEdit={handleEditItem}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Modals */}
      <AddItemModal 
        open={showAddModal} 
        onOpenChange={setShowAddModal} 
      />
      
      <EditItemModal
        open={showEditModal}
        onOpenChange={setShowEditModal}
        item={selectedItem}
      />
      
      {selectedItem && (
        <BarcodeModal
          isOpen={showBarcodeModal}
          onClose={() => setShowBarcodeModal(false)}
          item={selectedItem}
        />
      )}
      
      <QuickCheckoutModal
        open={showCheckoutModal}
        onOpenChange={setShowCheckoutModal}
        item={selectedItem}
      />

      <CheckInModal
        item={selectedItem}
        isOpen={showCheckinModal}
        onClose={() => setShowCheckinModal(false)}
      />

      <ReportsModal
        isOpen={showReportsModal}
        onClose={() => setShowReportsModal(false)}
      />

      <FillableFormsModal
        isOpen={showFormsModal}
        onClose={() => setShowFormsModal(false)}
      />

      {/* Transaction History */}
      <Card>
        <CardContent className="p-6">
          <ItemTransactionHistory showItemInfo={true} />
        </CardContent>
      </Card>
    </div>
  );
}
