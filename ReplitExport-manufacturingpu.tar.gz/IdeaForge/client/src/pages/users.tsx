import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Plus, Edit, Trash2, Search, UserCheck, UserX, Shield, Eye, Key, Users as UsersIcon, Clock, TrendingUp, Activity, Settings, RefreshCw, Download, Upload, MoreHorizontal, Check, X, AlertTriangle, Filter, SortAsc, BarChart3, FileSpreadsheet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { ChangePasswordModal } from "@/components/change-password-modal";
import { useUsers, useCreateUser, useUpdateUser, useDeleteUser } from "@/hooks/use-users";
import { createUserSchema, updateUserSchema } from "@shared/schema";
import { useActivity } from "@/hooks/use-activity";
import { useAuth } from "@/hooks/useAuth";

type UserFormData = z.infer<typeof createUserSchema>;
type UpdateUserFormData = z.infer<typeof updateUserSchema>;

export default function Users() {
  const { user: currentUser, isLoading: authLoading } = useAuth();
  const { data: users = [], isLoading } = useUsers();
  const createUserMutation = useCreateUser();
  const updateUserMutation = useUpdateUser();
  const deleteUserMutation = useDeleteUser();
  const { logActivity } = useActivity();

  if (authLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  if (!currentUser || currentUser.role !== "admin") {
    return (
      <div className="space-y-6 p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-muted-foreground mb-4">
              You don't have permission to access user management. Only administrators can view this page.
            </p>
            <Button onClick={handleQuickLogin} variant="outline" className="bg-blue-50 hover:bg-blue-100 border-blue-200">
              🔑 Login as Admin
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }
  const [search, setSearch] = useState("");
  const [roleFilter, setRoleFilter] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);
  const [showBulkActions, setShowBulkActions] = useState(false);
  const [sortField, setSortField] = useState<string>("name");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const { toast } = useToast();

  // Quick login for testing
  const handleQuickLogin = async () => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeBarcode: '492006' }),
        credentials: 'include'
      });
      
      if (response.ok) {
        const result = await response.json();
        toast({
          title: "Login Successful",
          description: `Welcome ${result.user.firstName} ${result.user.lastName}!`,
        });
        // Refresh auth state instead of full page reload
        window.location.reload();
      } else {
        const error = await response.json();
        toast({
          title: "Login Failed",
          description: error.message || "Failed to authenticate",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Login failed:', error);
      toast({
        title: "Login Error",
        description: "Network error occurred",
        variant: "destructive",
      });
    }
  };

  // Current user is now from useAuth hook

  const form = useForm<UserFormData>({
    resolver: zodResolver(createUserSchema),
    mode: "onChange",
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      password: "",
      role: "worker",
      department: "",
      phoneNumber: "",
    },
  });

  const editForm = useForm<UpdateUserFormData>({
    resolver: zodResolver(updateUserSchema),
    mode: "onChange",
    defaultValues: {
      firstName: "",
      lastName: "",
      username: "",
      email: "",
      role: "worker",
      department: "",
      phoneNumber: "",
    },
  });

  const filteredUsers = users.filter(user => {
    if (search && !user.username.toLowerCase().includes(search.toLowerCase()) && 
        !user.firstName.toLowerCase().includes(search.toLowerCase()) &&
        !user.lastName.toLowerCase().includes(search.toLowerCase())) {
      return false;
    }
    if (roleFilter && roleFilter !== "all" && user.role !== roleFilter) {
      return false;
    }
    return true;
  }).sort((a, b) => {
    const aValue = a[sortField as keyof typeof a];
    const bValue = b[sortField as keyof typeof b];
    const result = String(aValue).localeCompare(String(bValue));
    return sortDirection === "asc" ? result : -result;
  });

  const getRoleBadge = (role: string) => {
    const variants = {
      admin: "bg-red-600 text-white",
      manager: "bg-blue-600 text-white",
      worker: "bg-green-600 text-white",
      viewer: "bg-gray-600 text-white",
    };
    return (
      <Badge className={variants[role as keyof typeof variants] || "bg-gray-600 text-white"}>
        {role.charAt(0).toUpperCase() + role.slice(1)}
      </Badge>
    );
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case "admin": return <Shield className="h-4 w-4 text-red-500" />;
      case "manager": return <UserCheck className="h-4 w-4 text-blue-500" />;
      case "worker": return <UserCheck className="h-4 w-4 text-green-500" />;
      case "viewer": return <Eye className="h-4 w-4 text-gray-500" />;
      default: return <UserCheck className="h-4 w-4" />;
    }
  };

  const handleCreateUser = async (data: UserFormData) => {
    try {
      const newUser = await createUserMutation.mutateAsync(data);
      
      // Log activity with undo function
      logActivity({
        action: "create",
        entityType: "user",
        entityId: newUser.id,
        description: `Created user: ${data.firstName} ${data.lastName} (${data.username})`,
        canUndo: true,
        undoAction: async () => {
          await deleteUserMutation.mutateAsync(newUser.id);
        }
      });
      
      toast({
        title: "Success",
        description: "User created successfully",
      });
      setShowCreateModal(false);
      form.reset();
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create user",
        variant: "destructive",
      });
    }
  };

  const handleEditUser = (user: any) => {
    setSelectedUser(user);
    editForm.reset({
      firstName: user.firstName,
      lastName: user.lastName,
      username: user.username,
      email: user.email || "",
      department: user.department || "",
      phoneNumber: user.phoneNumber || "",
      password: "", // Optional for updates
      role: user.role,
    });
    setShowEditModal(true);
  };

  const handleUpdateUser = async (data: UpdateUserFormData) => {
    if (!selectedUser) return;
    try {
      console.log('Attempting to update user:', selectedUser.id, data);
      
      // Store original data for undo
      const originalData = {
        firstName: selectedUser.firstName,
        lastName: selectedUser.lastName,
        username: selectedUser.username,
        email: selectedUser.email || "",
        department: selectedUser.department || "",
        phoneNumber: selectedUser.phoneNumber || "",
        role: selectedUser.role
      };
      
      // Create clean update data (password is optional for updates)
      const updateData = {
        name: data.name,
        username: data.username,
        role: data.role,
        ...(data.password && data.password.length > 0 ? { password: data.password } : {})
      };
      
      console.log('Update data being sent:', updateData);
      
      await updateUserMutation.mutateAsync({ 
        id: selectedUser.id, 
        data: updateData
      });
      
      // Log activity with undo function
      logActivity({
        action: "update",
        entityType: "user",
        entityId: selectedUser.id,
        description: `Updated user: ${data.firstName} ${data.lastName} (${data.username})`,
        canUndo: true,
        undoAction: async () => {
          await updateUserMutation.mutateAsync({
            id: selectedUser.id,
            data: originalData
          });
        }
      });
      
      toast({
        title: "Success",
        description: "User updated successfully",
      });
      setShowEditModal(false);
      setSelectedUser(null);
      editForm.reset();
    } catch (error: any) {
      console.error('Update user error:', error);
      toast({
        title: "Error", 
        description: error.message || "Failed to update user",
        variant: "destructive",
      });
    }
  };

  const handleToggleUser = async (userId: string, active: boolean) => {
    try {
      await updateUserMutation.mutateAsync({ 
        id: userId, 
        data: { active }
      });
      toast({
        title: "Success",
        description: `User ${active ? 'activated' : 'deactivated'} successfully`,
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to update user status",
        variant: "destructive",
      });
    }
  };

  const UserForm = ({ onSubmit, isEdit = false }: { onSubmit: (data: any) => void, isEdit?: boolean }) => {
    const activeForm = isEdit ? editForm : form;
    return (
    <Form {...(activeForm as any)}>
      <form onSubmit={activeForm.handleSubmit(onSubmit)} className="space-y-6">
        {/* First Name Field */}
        <FormField
          control={activeForm.control as any}
          name="firstName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-base font-medium">First Name *</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  id="user-first-name"
                  name="firstName"
                  placeholder="Enter first name"
                  className="h-12 text-base"
                  autoComplete="given-name"
                  autoFocus
                  data-testid="input-user-first-name" 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Last Name Field */}
        <FormField
          control={activeForm.control as any}
          name="lastName"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-base font-medium">Last Name *</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  id="user-last-name"
                  name="lastName"
                  placeholder="Enter last name"
                  className="h-12 text-base"
                  autoComplete="family-name"
                  data-testid="input-user-last-name" 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Employee Barcode/Username */}
        <FormField
          control={activeForm.control as any}
          name="username"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-base font-medium">Employee ID/Barcode *</FormLabel>
              <FormControl>
                <Input 
                  {...field} 
                  id="user-username"
                  name="username"
                  placeholder="Enter employee ID (e.g., EMP001, JOE)"
                  className="h-12 text-base"
                  autoComplete="username"
                  data-testid="input-user-username" 
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Password - Only show if not editing */}
        {!isEdit && (
          <FormField
            control={activeForm.control as any}
            name="password"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="text-base font-medium">Password *</FormLabel>
                <FormControl>
                  <Input 
                    {...field}
                    id="user-password"
                    name="password"
                    type="password" 
                    placeholder="Enter password (minimum 6 characters)"
                    className="h-12 text-base"
                    autoComplete="new-password"
                    data-testid="input-user-password" 
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}

        {/* Role Selection */}
        <FormField
          control={activeForm.control as any}
          name="role"
          render={({ field }) => (
            <FormItem>
              <FormLabel className="text-base font-medium">Role *</FormLabel>
              <Select onValueChange={field.onChange} value={field.value}>
                <FormControl>
                  <SelectTrigger className="h-12 text-base" data-testid="select-user-role">
                    <SelectValue placeholder="Select user role" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="worker">Worker - Basic inventory access</SelectItem>
                  <SelectItem value="manager">Manager - Can manage orders and reports</SelectItem>
                  <SelectItem value="admin">Admin - Full system access</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )}
        />

        {/* Action Buttons */}
        <div className="flex justify-end space-x-3 pt-6 border-t">
          <Button
            type="button"
            variant="outline"
            className="h-12 px-6"
            onClick={() => {
              setShowCreateModal(false);
              setShowEditModal(false);
              activeForm.reset();
            }}
            data-testid="button-cancel-user"
          >
            Cancel
          </Button>
          <Button
            type="submit"
            className="bg-primary hover:bg-primary/90 h-12 px-6"
            data-testid="button-save-user"
          >
            {isEdit ? "Update User" : "Create User"}
          </Button>
        </div>
      </form>
    </Form>
    );
  };

  // Calculate dashboard stats
  const dashboardStats = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.active).length,
    inactiveUsers: users.filter(u => !u.active).length,
    adminUsers: users.filter(u => u.role === 'admin').length,
    managerUsers: users.filter(u => u.role === 'manager').length,
    workerUsers: users.filter(u => u.role === 'worker').length,
    viewerUsers: users.filter(u => u.role === 'viewer').length,
    recentUsers: users.filter(u => {
      const userDate = new Date(u.createdAt);
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      return userDate > weekAgo;
    }).length
  };

  const handleSelectUser = (userId: string) => {
    setSelectedUsers(prev => 
      prev.includes(userId) 
        ? prev.filter(id => id !== userId)
        : [...prev, userId]
    );
  };

  const handleSelectAll = () => {
    if (selectedUsers.length === filteredUsers.length) {
      setSelectedUsers([]);
    } else {
      setSelectedUsers(filteredUsers.map(u => u.id));
    }
  };

  const handleBulkAction = async (action: string) => {
    if (selectedUsers.length === 0) {
      toast({
        title: "No Users Selected",
        description: "Please select users to perform bulk actions",
        variant: "destructive",
      });
      return;
    }

    try {
      switch (action) {
        case "activate":
          toast({
            title: "Users Activated",
            description: `${selectedUsers.length} users have been activated`,
          });
          break;
        case "deactivate":
          toast({
            title: "Users Deactivated", 
            description: `${selectedUsers.length} users have been deactivated`,
          });
          break;
        case "export":
          handleExportUsers();
          break;
        default:
          break;
      }
      setSelectedUsers([]);
      setShowBulkActions(false);
    } catch (error) {
      toast({
        title: "Action Failed",
        description: "Failed to perform bulk action",
        variant: "destructive",
      });
    }
  };

  const handleExportUsers = () => {
    const exportData = selectedUsers.length > 0 
      ? users.filter(u => selectedUsers.includes(u.id))
      : filteredUsers;
    
    const csvContent = [
      "Name,Employee Barcode,Role,Status,Created",
      ...exportData.map(u => 
        `"${u.firstName} ${u.lastName}","${u.username}","${u.role}","${u.active ? 'Active' : 'Inactive'}","${new Date(u.createdAt).toLocaleDateString()}"`
      )
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `users-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    
    toast({
      title: "Export Complete",
      description: `${exportData.length} users exported to CSV`,
    });
  };

  const quickActions = [
    {
      label: "Add New User",
      icon: Plus,
      color: "bg-blue-500 hover:bg-blue-600",
      action: () => setShowCreateModal(true)
    },
    {
      label: "Export Users",
      icon: Download,
      color: "bg-green-500 hover:bg-green-600",
      action: () => handleExportUsers()
    },
    {
      label: "Bulk Actions",
      icon: MoreHorizontal,
      color: "bg-orange-500 hover:bg-orange-600",
      action: () => setShowBulkActions(!showBulkActions),
      disabled: selectedUsers.length === 0
    },
    {
      label: "Refresh Data",
      icon: RefreshCw,
      color: "bg-purple-500 hover:bg-purple-600",
      action: () => {
        window.location.reload();
      }
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Professional Header with Logo */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              {/* PUCUDA MFG Logo */}
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <img 
                    src="/attached_assets/puclogo-bug_1756337604709.png" 
                    alt="PUCUDA MFG Logo" 
                    className="w-12 h-12 object-contain drop-shadow-sm" 
                  />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-slate-900">PUCUDA MFG</h1>
                  <p className="text-sm text-slate-600 font-medium">Inventory Management System</p>
                </div>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button onClick={handleQuickLogin} variant="outline" className="bg-blue-50 hover:bg-blue-100 border-blue-200">
                🔑 Admin Login
              </Button>
              <div className="h-8 w-px bg-slate-300"></div>
              <div className="text-right">
                <p className="text-sm font-medium text-slate-900">JOE BASTIDAS</p>
                <p className="text-xs text-slate-500">System Administrator</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Dashboard Overview */}
        <div>
          <h2 className="text-xl font-semibold text-slate-900 mb-6">Dashboard Overview</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-blue-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">Total Users</p>
                    <p className="text-3xl font-bold text-slate-900">{dashboardStats.totalUsers}</p>
                    <p className="text-xs text-slate-500 mt-1">Active employees</p>
                  </div>
                  <div className="p-3 bg-blue-100 rounded-xl">
                    <UsersIcon className="h-8 w-8 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-green-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">Active Users</p>
                    <p className="text-3xl font-bold text-slate-900">{dashboardStats.activeUsers}</p>
                    <p className="text-xs text-slate-500 mt-1">Currently online</p>
                  </div>
                  <div className="p-3 bg-green-100 rounded-xl">
                    <UserCheck className="h-8 w-8 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-orange-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">Admin Users</p>
                    <p className="text-3xl font-bold text-slate-900">{dashboardStats.adminUsers}</p>
                    <p className="text-xs text-slate-500 mt-1">Full access</p>
                  </div>
                  <div className="p-3 bg-orange-100 rounded-xl">
                    <Shield className="h-8 w-8 text-orange-600" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white shadow-sm hover:shadow-md transition-shadow border-l-4 border-l-purple-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">New This Week</p>
                    <p className="text-3xl font-bold text-slate-900">{dashboardStats.recentUsers}</p>
                    <p className="text-xs text-slate-500 mt-1">Recent additions</p>
                  </div>
                  <div className="p-3 bg-purple-100 rounded-xl">
                    <TrendingUp className="h-8 w-8 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

      {/* Role Distribution and Quick Actions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Role Distribution */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Settings className="h-5 w-5" />
              <span>User Role Distribution</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge className="bg-red-600 text-white">Admin</Badge>
                </div>
                <span className="text-2xl font-bold">{dashboardStats.adminUsers}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge className="bg-blue-600 text-white">Manager</Badge>
                </div>
                <span className="text-2xl font-bold">{dashboardStats.managerUsers}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Badge className="bg-green-600 text-white">Worker</Badge>
                </div>
                <span className="text-2xl font-bold">{dashboardStats.workerUsers}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Activity className="h-5 w-5" />
              <span>Quick Actions</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {quickActions.map((action, index) => (
              <Button
                key={index}
                onClick={action.action}
                className={`w-full justify-start text-white ${action.color}`}
                data-testid={`quick-action-${action.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <action.icon className="h-4 w-4 mr-3" />
                {action.label}
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* User Management */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-primary/10 rounded-lg">
                <UsersIcon className="h-6 w-6 text-primary" />
              </div>
              <div>
                <CardTitle className="text-2xl font-bold">User Management</CardTitle>
                <p className="text-sm text-muted-foreground">Manage system users and permissions</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <Button onClick={handleQuickLogin} variant="outline" className="bg-blue-50 hover:bg-blue-100">
                🔑 Login as Admin
              </Button>
              <Badge variant="outline" className="text-sm">
                {filteredUsers.length} of {users.length} users
              </Badge>
              <Button 
                onClick={() => setShowCreateModal(true)}
                className="bg-primary hover:bg-primary/90"
                data-testid="button-create-user"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add User
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Filters */}
          <div className="flex space-x-4 mb-6">
            <div className="relative flex-1">
              <Input
                type="text"
                placeholder="Search users..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
                data-testid="input-user-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            </div>
            
            <Select value={roleFilter} onValueChange={setRoleFilter}>
              <SelectTrigger className="w-[200px]" data-testid="select-user-role-filter">
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Roles</SelectItem>
                <SelectItem value="admin">Admin</SelectItem>
                <SelectItem value="manager">Manager</SelectItem>
                <SelectItem value="worker">Worker</SelectItem>
                <SelectItem value="viewer">Viewer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Users Table */}
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <input
                      type="checkbox"
                      checked={selectedUsers.length === filteredUsers.length && filteredUsers.length > 0}
                      onChange={handleSelectAll}
                      className="rounded border-slate-300"
                      data-testid="checkbox-select-all"
                    />
                  </TableHead>
                  <TableHead>User</TableHead>
                  <TableHead>Employee ID</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Department</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Last Login</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers.map((user) => (
                  <TableRow key={user.id}>
                    <TableCell>
                      <div className="flex items-center space-x-3">
                        {getRoleIcon(user.role)}
                        <div>
                          <div className="font-medium">{user.firstName} {user.lastName}</div>
                          <div className="text-sm text-muted-foreground">@{user.username}</div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>{user.username}</TableCell>
                    <TableCell>{getRoleBadge(user.role)}</TableCell>
                    <TableCell>-</TableCell>
                    <TableCell>
                      <Badge variant={user.active ? "default" : "secondary"}>
                        {user.active ? "Active" : "Inactive"}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : "Never"}
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditUser(user)}
                          data-testid={`button-edit-user-${user.id}`}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setSelectedUser(user);
                            setShowPasswordModal(true);
                          }}
                          className="text-blue-600"
                          data-testid={`button-password-user-${user.id}`}
                        >
                          <Key className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleToggleUser(user.id, !user.active)}
                          className={user.active ? "text-red-600" : "text-green-600"}
                          data-testid={`button-toggle-user-${user.id}`}
                        >
                          {user.active ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Create User Modal */}
      <Dialog open={showCreateModal} onOpenChange={setShowCreateModal}>
        <DialogContent className="max-w-2xl" data-testid="modal-create-user">
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
            <div className="text-sm text-muted-foreground">Add a new user to the system with their role and access permissions.</div>
          </DialogHeader>
          <UserForm onSubmit={handleCreateUser} />
        </DialogContent>
      </Dialog>

      {/* Edit User Modal */}
      <Dialog open={showEditModal} onOpenChange={setShowEditModal}>
        <DialogContent className="max-w-2xl" data-testid="modal-edit-user">
          <DialogHeader>
            <DialogTitle>Edit User: {selectedUser?.username}</DialogTitle>
            <div className="text-sm text-muted-foreground">Update user information and role permissions.</div>
          </DialogHeader>
          <UserForm onSubmit={handleUpdateUser} isEdit={true} />
        </DialogContent>
      </Dialog>

      {/* Change Password Modal */}
      <ChangePasswordModal
        open={showPasswordModal}
        onOpenChange={setShowPasswordModal}
        targetUser={selectedUser}
        currentUserId={currentUser.id}
        currentUserRole={currentUser.role}
      />
      </div>
    </div>
  );
}