import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Activity as ActivityIcon, 
  Trophy, 
  Target, 
  Zap, 
  Calendar, 
  Clock, 
  TrendingUp, 
  Award,
  Star,
  CheckCircle,
  Package,
  ShoppingCart,
  Users,
  Truck,
  Shield
} from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";

export default function Activity() {
  const { user, isLoading } = useAuth();

  if (isLoading) {
    return <div className="flex items-center justify-center min-h-screen">Loading...</div>;
  }

  // Quick login for testing
  const handleQuickLogin = async () => {
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeBarcode: '492006' }),
        credentials: 'include'
      });
      
      if (response.ok) {
        window.location.reload();
      }
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  if (!user || user.role !== "admin") {
    return (
      <div className="space-y-6 p-6">
        <Card>
          <CardContent className="p-6 text-center">
            <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
            <h3 className="text-lg font-semibold mb-2">Access Denied</h3>
            <p className="text-muted-foreground mb-4">
              You don't have permission to access activity tracking. Only administrators can view this page.
            </p>
            <Button onClick={handleQuickLogin} variant="outline" className="bg-blue-50 hover:bg-blue-100 border-blue-200">
              🔑 Login as Admin
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

// Mock data for user activity and achievements  
const currentUser = {
  id: user.id,
  username: user.employeeBarcode || user.id,
  firstName: user.firstName || "User",
  lastName: user.lastName || "",
  joinDate: new Date(),
  totalPoints: 2850,
  level: 12,
  streak: 7,
};

const achievements = [
  {
    id: "first-login",
    title: "Welcome Aboard",
    description: "Complete your first login",
    icon: "🚀",
    points: 50,
    unlocked: true,
    unlockedDate: new Date("2024-01-15"),
    category: "milestone",
  },
  {
    id: "inventory-master",
    title: "Inventory Master",
    description: "Add 100 items to inventory",
    icon: "📦",
    points: 200,
    unlocked: true,
    unlockedDate: new Date("2024-02-01"),
    category: "inventory",
    progress: 100,
    target: 100,
  },
  {
    id: "order-processor",
    title: "Order Processor",
    description: "Process 50 orders",
    icon: "🎯",
    points: 150,
    unlocked: true,
    unlockedDate: new Date("2024-02-15"),
    category: "orders",
    progress: 50,
    target: 50,
  },
  {
    id: "shipping-specialist",
    title: "Shipping Specialist",
    description: "Complete 25 shipments",
    icon: "🚛",
    points: 100,
    unlocked: false,
    category: "shipping",
    progress: 18,
    target: 25,
  },
  {
    id: "weekly-warrior",
    title: "Weekly Warrior",
    description: "Log in for 7 consecutive days",
    icon: "⚡",
    points: 75,
    unlocked: true,
    unlockedDate: new Date("2024-01-22"),
    category: "engagement",
  },
  {
    id: "productivity-pro",
    title: "Productivity Pro",
    description: "Complete 500 total actions",
    icon: "🏆",
    points: 300,
    unlocked: false,
    category: "milestone",
    progress: 387,
    target: 500,
  },
];

const recentActivities = [
  {
    id: "1",
    action: "Added new item to inventory",
    details: "Widget XL-2000",
    timestamp: new Date(Date.now() - 2 * 60 * 1000),
    type: "inventory",
    points: 5,
  },
  {
    id: "2",
    action: "Processed order",
    details: "Order #ORD-2024-0095",
    timestamp: new Date(Date.now() - 15 * 60 * 1000),
    type: "order",
    points: 10,
  },
  {
    id: "3",
    action: "Updated user profile",
    details: "Jane Smith",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000),
    type: "user",
    points: 3,
  },
  {
    id: "4",
    action: "Created shipping document",
    details: "BOL #BOL-2024-0089",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000),
    type: "shipping",
    points: 8,
  },
  {
    id: "5",
    action: "Received inventory",
    details: "15 items processed",
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000),
    type: "receiving",
    points: 12,
  },
];

const activityStats = {
  todayActions: 23,
  weekActions: 156,
  monthActions: 642,
  totalActions: 2847,
  avgDailyActions: 18.2,
  mostActiveHour: "10:00 AM",
  favoriteFeature: "Inventory Management",
};

const leaderboard = [
  { rank: 1, name: "John Manager", points: 3420, avatar: "👨‍💼" },
  { rank: 2, name: "Admin User", points: 2850, avatar: "👨‍💻", current: true },
  { rank: 3, name: "Sarah Wilson", points: 2630, avatar: "👩‍🔧" },
  { rank: 4, name: "Mike Johnson", points: 2100, avatar: "👨‍🏭" },
  { rank: 5, name: "Lisa Davis", points: 1890, avatar: "👩‍💼" },
];


  const [selectedCategory, setSelectedCategory] = useState("all");

  const filteredAchievements = achievements.filter(achievement => 
    selectedCategory === "all" || achievement.category === selectedCategory
  );

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "inventory": return <Package className="h-4 w-4 text-blue-600" />;
      case "order": return <ShoppingCart className="h-4 w-4 text-green-600" />;
      case "user": return <Users className="h-4 w-4 text-purple-600" />;
      case "shipping": return <Truck className="h-4 w-4 text-orange-600" />;
      case "receiving": return <Package className="h-4 w-4 text-teal-600" />;
      default: return <ActivityIcon className="h-4 w-4 text-gray-600" />;
    }
  };

  const getCategoryBadge = (category: string) => {
    const variants = {
      milestone: "bg-yellow-600 text-white",
      inventory: "bg-blue-600 text-white",
      orders: "bg-green-600 text-white",
      shipping: "bg-orange-600 text-white",
      engagement: "bg-purple-600 text-white",
    };
    return (
      <Badge className={variants[category as keyof typeof variants] || "bg-gray-600 text-white"}>
        {category.charAt(0).toUpperCase() + category.slice(1)}
      </Badge>
    );
  };

  const getProgressLevel = () => {
    const currentLevelPoints = (currentUser.level - 1) * 200;
    const nextLevelPoints = currentUser.level * 200;
    const progressInLevel = currentUser.totalPoints - currentLevelPoints;
    const pointsNeededForLevel = nextLevelPoints - currentLevelPoints;
    return (progressInLevel / pointsNeededForLevel) * 100;
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center">
            <Trophy className="h-6 w-6 mr-2 text-yellow-600" />
            Activity Dashboard
          </CardTitle>
        </CardHeader>
      </Card>

      {/* User Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Level</p>
                <p className="text-3xl font-bold text-primary">{currentUser.level}</p>
              </div>
              <Star className="h-8 w-8 text-yellow-500" />
            </div>
            <div className="mt-4">
              <Progress value={getProgressLevel()} className="h-2" />
              <p className="text-xs text-muted-foreground mt-1">
                {Math.round(getProgressLevel())}% to Level {currentUser.level + 1}
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Points</p>
                <p className="text-3xl font-bold text-green-600">{currentUser.totalPoints.toLocaleString()}</p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              +{recentActivities.slice(0, 5).reduce((sum, activity) => sum + activity.points, 0)} points today
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current Streak</p>
                <p className="text-3xl font-bold text-orange-600">{currentUser.streak}</p>
              </div>
              <Zap className="h-8 w-8 text-orange-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">days in a row</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Achievements</p>
                <p className="text-3xl font-bold text-purple-600">
                  {achievements.filter(a => a.unlocked).length}/{achievements.length}
                </p>
              </div>
              <Award className="h-8 w-8 text-purple-500" />
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              {Math.round((achievements.filter(a => a.unlocked).length / achievements.length) * 100)}% completed
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Activity Statistics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <TrendingUp className="h-5 w-5 mr-2" />
                  Activity Statistics
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{activityStats.todayActions}</p>
                    <p className="text-sm text-blue-600">Today</p>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{activityStats.weekActions}</p>
                    <p className="text-sm text-green-600">This Week</p>
                  </div>
                  <div className="text-center p-4 bg-orange-50 rounded-lg">
                    <p className="text-2xl font-bold text-orange-600">{activityStats.monthActions}</p>
                    <p className="text-sm text-orange-600">This Month</p>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{activityStats.totalActions}</p>
                    <p className="text-sm text-purple-600">All Time</p>
                  </div>
                </div>
                
                <div className="space-y-3 pt-4 border-t">
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Average Daily Actions</span>
                    <span className="font-medium">{activityStats.avgDailyActions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Most Active Hour</span>
                    <span className="font-medium">{activityStats.mostActiveHour}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-muted-foreground">Favorite Feature</span>
                    <span className="font-medium">{activityStats.favoriteFeature}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Latest Achievements */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="h-5 w-5 mr-2" />
                  Latest Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.filter(a => a.unlocked).slice(-3).map((achievement) => (
                    <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
                      <div className="text-2xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <h4 className="font-medium">{achievement.title}</h4>
                        <p className="text-sm text-muted-foreground">{achievement.description}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-medium text-green-600">+{achievement.points}</p>
                        {achievement.unlockedDate && (
                          <p className="text-xs text-muted-foreground">
                            {achievement.unlockedDate.toLocaleDateString()}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Achievements Tab */}
        <TabsContent value="achievements" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <Trophy className="h-5 w-5 mr-2" />
                  Achievements
                </span>
                <div className="flex space-x-2">
                  {["all", "milestone", "inventory", "orders", "shipping", "engagement"].map((category) => (
                    <button
                      key={category}
                      onClick={() => setSelectedCategory(category)}
                      className={`px-3 py-1 rounded-full text-sm ${
                        selectedCategory === category
                          ? "bg-primary text-white"
                          : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                      }`}
                      data-testid={`filter-${category}`}
                    >
                      {category.charAt(0).toUpperCase() + category.slice(1)}
                    </button>
                  ))}
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {filteredAchievements.map((achievement) => (
                  <Card 
                    key={achievement.id} 
                    className={`relative ${achievement.unlocked ? 'bg-green-50 border-green-200' : 'bg-gray-50'}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="text-3xl">{achievement.icon}</div>
                        <div className="flex items-center space-x-2">
                          {getCategoryBadge(achievement.category)}
                          {achievement.unlocked && (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          )}
                        </div>
                      </div>
                      
                      <h3 className="font-semibold mb-1">{achievement.title}</h3>
                      <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                      
                      {achievement.progress !== undefined && achievement.target !== undefined && (
                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span>{achievement.progress}/{achievement.target}</span>
                          </div>
                          <Progress 
                            value={(achievement.progress / achievement.target) * 100} 
                            className="h-2"
                          />
                        </div>
                      )}
                      
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-yellow-600">+{achievement.points} pts</span>
                        {achievement.unlocked && achievement.unlockedDate && (
                          <span className="text-xs text-muted-foreground">
                            {achievement.unlockedDate.toLocaleDateString()}
                          </span>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Recent Activity Tab */}
        <TabsContent value="activity" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Recent Activity
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-center space-x-4 p-4 border border-border rounded-lg">
                    <div className="flex-shrink-0">
                      {getActivityIcon(activity.type)}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium">{activity.action}</h4>
                      <p className="text-sm text-muted-foreground">{activity.details}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-green-600">+{activity.points} pts</p>
                      <p className="text-xs text-muted-foreground">
                        {activity.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Leaderboard Tab */}
        <TabsContent value="leaderboard" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Award className="h-5 w-5 mr-2" />
                Monthly Leaderboard
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((user) => (
                  <div 
                    key={user.rank} 
                    className={`flex items-center space-x-4 p-4 rounded-lg ${
                      user.current ? 'bg-blue-50 border border-blue-200' : 'bg-gray-50'
                    }`}
                  >
                    <div className="flex-shrink-0">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
                        user.rank === 1 ? 'bg-yellow-500' :
                        user.rank === 2 ? 'bg-gray-400' :
                        user.rank === 3 ? 'bg-orange-500' : 'bg-gray-300'
                      }`}>
                        {user.rank}
                      </div>
                    </div>
                    <div className="text-2xl">{user.avatar}</div>
                    <div className="flex-1">
                      <h4 className={`font-medium ${user.current ? 'text-blue-700' : ''}`}>
                        {user.name}
                        {user.current && <span className="ml-2 text-sm text-blue-600">(You)</span>}
                      </h4>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-primary">{user.points.toLocaleString()}</p>
                      <p className="text-xs text-muted-foreground">points</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}