import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/useAuth";
import { useLocation } from "wouter";
import { LogIn, Shield, Scan, Keyboard } from "lucide-react";
import pucudaLogo from "@/assets/pucuda-logo.png";
import { loginSchema, type LoginData } from "@shared/schema";

import puclogo_bug from "@assets/puclogo-bug.png";

export default function Login() {
  const barcodeInputRef = useRef<HTMLInputElement>(null);
  const manualInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();
  const { login, isLoggingIn } = useAuth();
  const [, setLocation] = useLocation();
  const [showManualInput, setShowManualInput] = useState(false);

  const form = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      employeeBarcode: "",
    },
  });

  // Auto-focus barcode input for scanner or manual input
  useEffect(() => {
    if (showManualInput && manualInputRef.current) {
      manualInputRef.current.focus();
    } else if (!showManualInput && barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  }, [showManualInput]);

  const onSubmit = async (data: LoginData) => {
    try {
      await login(data);
      toast({
        title: "Login Successful", 
        description: "Welcome to PUCUDA MFG Warehouse System",
      });
      setLocation("/");
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid employee barcode",
        variant: "destructive",
      });
    }
  };

  const handleBarcodeKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      const value = (e.target as HTMLInputElement).value;
      const trimmedValue = value.trim();
      if (trimmedValue) {
        form.setValue('employeeBarcode', trimmedValue);
        form.handleSubmit(onSubmit)();
      }
    }
  };

  // Auto-submit when barcode is scanned (detect rapid input completion)
  const handleBarcodeInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    form.setValue('employeeBarcode', value);
    
    // Auto-submit if barcode looks complete (6 digits for employee barcode)
    // Only trim for the validation check, not the actual input
    const trimmedValue = value.trim();
    if (trimmedValue.length === 6 && /^\d+$/.test(trimmedValue)) {
      setTimeout(() => {
        form.handleSubmit(onSubmit)();
      }, 100); // Small delay to ensure scanner has finished
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 px-4">
      <div className="w-full max-w-md space-y-8">
        {/* Logo and Company Info */}
        <div className="text-center">
          <div className="flex justify-center mb-4">
            <img 
              src={puclogo_bug} 
              alt="PUCUDA MFG Logo" 
              className="h-16 w-auto"
              data-testid="img-company-logo"
            />
          </div>
          <h1 className="text-3xl font-bold text-gray-900">P-MAPS</h1>
          <p className="text-lg mb-2 text-[#5e7a31]">PUCUDA MANUFACTURING AND PROGRAMMING SOFTWARE</p>
          <p className="text-sm text-gray-500">Scan your employee ID to sign in</p>
        </div>

        {/* Login Form */}
        <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border border-gray-100">
          <CardHeader className="space-y-1 pb-4">
            <CardTitle className="text-2xl font-semibold text-center flex items-center justify-center text-[#3c9448]">
              <Shield className="h-6 w-6 mr-2" />
              Employee Access
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="employeeBarcode"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <Input 
                          {...field} 
                          ref={showManualInput ? manualInputRef : barcodeInputRef}
                          className={showManualInput ? "w-full" : "opacity-0 absolute top-0 left-0 w-full h-full z-10"}
                          data-testid="input-login-barcode"
                          onKeyPress={handleBarcodeKeyPress}
                          onChange={handleBarcodeInput}
                          placeholder={showManualInput ? "Enter your employee barcode" : ""}
                          autoComplete="off"
                          autoFocus
                          style={showManualInput ? {} : { pointerEvents: 'all' }}
                        />
                      </FormControl>
                      
                      {!showManualInput && (
                        <div className="text-center py-12 relative">
                          <div className="text-8xl mb-6">🪪</div>
                          <p className="text-xl font-medium text-gray-800 mb-3">Ready to Scan</p>
                          <p className="text-base text-gray-600 mb-2">Scan your employee ID to sign in</p>
                          <div className="inline-flex items-center text-sm text-gray-500 mt-4">
                            <Scan className="h-4 w-4 mr-2" />
                            <span>Scanner ready...</span>
                          </div>
                          {/* Invisible overlay to capture barcode scanner input */}
                          <div className="absolute inset-0 cursor-pointer" 
                               onClick={() => barcodeInputRef.current?.focus()}
                               title="Click to focus scanner input" />
                        </div>
                      )}

                      {showManualInput && (
                        <div className="mt-4">
                          <Button 
                            type="submit" 
                            className="w-full h-12 bg-primary hover:bg-primary/90 text-white font-semibold"
                            disabled={isLoggingIn}
                            data-testid="button-manual-login"
                          >
                            <LogIn className="h-5 w-5 mr-2" />
                            {isLoggingIn ? "Signing In..." : "Sign In"}
                          </Button>
                        </div>
                      )}

                      <div className="mt-6 text-center">
                        <Button 
                          type="button"
                          variant="outline"
                          size="sm"
                          className="text-xs h-8 px-3 text-gray-600 border-gray-300"
                          onClick={() => setShowManualInput(!showManualInput)}
                          data-testid="button-toggle-input"
                        >
                          <Keyboard className="h-3 w-3 mr-2" />
                          {showManualInput ? "Use Scanner" : "Type Barcode"}
                        </Button>
                      </div>
                      
                      <FormMessage />
                    </FormItem>
                  )}
                />

              </form>
            </Form>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-gray-500">
          <p>&copy; 2025 PUCUDA Manufacturing. All rights reserved.</p>
          <p className="mt-1">Warehouse Management System v2.1.0</p>
        </div>
      </div>
    </div>
  );
}