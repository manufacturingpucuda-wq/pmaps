import React, { useState, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { Search, FileText, Download, ExternalLink, Globe, Archive, Bookmark, Clock, Printer, Plus, Edit3, Save, Trash2 } from "lucide-react";
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

// Invoice line item interface
interface InvoiceItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
}

// Invoice data interface
interface InvoiceData {
  // Company Information
  companyName: string;
  companyAddress: string;
  companyCity: string;
  companyState: string;
  companyZip: string;
  companyPhone: string;
  companyEmail: string;
  companyWebsite: string;
  
  // Invoice Details
  invoiceNumber: string;
  date: string;
  dueDate: string;
  
  // Customer Information
  customerName: string;
  customerAddress: string;
  customerCity: string;
  customerState: string;
  customerZip: string;
  customerPhone: string;
  customerEmail: string;
  
  // Line Items and Totals
  items: InvoiceItem[];
  subtotal: number;
  taxRate: number;
  taxAmount: number;
  total: number;
  
  // Additional Info
  notes: string;
  paymentTerms: string;
  invoiceTitle: string;
}

// Mock warehouse document templates and search results
const documentTemplates = [
  {
    id: "1",
    title: "Bill of Lading Template",
    description: "Standard BOL form for shipping documentation",
    category: "shipping",
    format: "PDF",
    lastUpdated: new Date(),
    url: "#",
  },
  {
    id: "2", 
    title: "Receiving Report Template",
    description: "Form for documenting received inventory",
    category: "receiving",
    format: "Excel",
    lastUpdated: new Date(),
    url: "#",
  },
  {
    id: "3",
    title: "Inventory Cycle Count Sheet",
    description: "Physical inventory counting form",
    category: "inventory",
    format: "PDF",
    lastUpdated: new Date(),
    url: "#",
  },
  {
    id: "4",
    title: "Safety Data Sheet Template",
    description: "SDS form for hazardous materials",
    category: "safety",
    format: "Word",
    lastUpdated: new Date(),
    url: "#",
  },
  {
    id: "5",
    title: "Invoice Template",
    description: "Professional invoice generator with PDF export",
    category: "billing",
    format: "PDF",
    lastUpdated: new Date(),
    url: "#",
  },
];

// External tools and software - moved to dedicated Time Clock page
const externalTools: any[] = [];

const savedSearches = [
  "warehouse management best practices",
  "inventory cycle counting procedures",
  "shipping documentation requirements",
  "receiving inspection checklists",
  "safety protocols manufacturing",
];

export default function Documents() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [recentSearches, setRecentSearches] = useState([
    "warehouse safety protocols",
    "BOL shipping requirements",
    "inventory management procedures",
  ]);
  const [showInvoiceEditor, setShowInvoiceEditor] = useState(false);
  const [savedInvoices, setSavedInvoices] = useState<InvoiceData[]>([]);
  const invoiceRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Default invoice data
  const [invoiceData, setInvoiceData] = useState<InvoiceData>({
    // Company Information
    companyName: "PUCUDA MFG",
    companyAddress: "123 Industrial Way",
    companyCity: "Manufacturing City",
    companyState: "TX",
    companyZip: "75001",
    companyPhone: "(555) 123-4567",
    companyEmail: "billing@pucudamfg.com",
    companyWebsite: "www.pucudamfg.com",
    
    // Invoice Details
    invoiceNumber: `INV-${Date.now()}`,
    date: new Date().toISOString().split('T')[0],
    dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    
    // Customer Information
    customerName: "",
    customerAddress: "",
    customerCity: "",
    customerState: "",
    customerZip: "",
    customerPhone: "",
    customerEmail: "",
    
    // Line Items and Totals
    items: [
      { id: "1", description: "", quantity: 1, unitPrice: 0, total: 0 }
    ],
    subtotal: 0,
    taxRate: 8.25,
    taxAmount: 0,
    total: 0,
    
    // Additional Info
    notes: "",
    paymentTerms: "Net 30",
    invoiceTitle: "INVOICE"
  });

  // Invoice calculation functions
  const calculateItemTotal = (quantity: number, unitPrice: number) => quantity * unitPrice;
  
  const calculateSubtotal = (items: InvoiceItem[]) => 
    items.reduce((sum, item) => sum + item.total, 0);
  
  const updateInvoiceTotals = (items: InvoiceItem[]) => {
    const subtotal = calculateSubtotal(items);
    const taxAmount = (subtotal * invoiceData.taxRate) / 100;
    const total = subtotal + taxAmount;
    
    setInvoiceData(prev => ({
      ...prev,
      subtotal,
      taxAmount,
      total
    }));
  };

  // Invoice item management
  const addInvoiceItem = () => {
    const newItem: InvoiceItem = {
      id: Date.now().toString(),
      description: "",
      quantity: 1,
      unitPrice: 0,
      total: 0
    };
    setInvoiceData(prev => ({
      ...prev,
      items: [...prev.items, newItem]
    }));
  };

  const removeInvoiceItem = (id: string) => {
    const updatedItems = invoiceData.items.filter(item => item.id !== id);
    setInvoiceData(prev => ({ ...prev, items: updatedItems }));
    updateInvoiceTotals(updatedItems);
  };

  const updateInvoiceItem = (id: string, field: keyof InvoiceItem, value: any) => {
    const updatedItems = invoiceData.items.map(item => {
      if (item.id === id) {
        const updatedItem = { ...item, [field]: value };
        if (field === 'quantity' || field === 'unitPrice') {
          updatedItem.total = calculateItemTotal(updatedItem.quantity, updatedItem.unitPrice);
        }
        return updatedItem;
      }
      return item;
    });
    setInvoiceData(prev => ({ ...prev, items: updatedItems }));
    updateInvoiceTotals(updatedItems);
  };

  // PDF generation
  const generatePDF = async () => {
    if (!invoiceRef.current) return;

    try {
      const canvas = await html2canvas(invoiceRef.current, {
        scale: 2,
        useCORS: true,
        allowTaint: true
      });
      
      const pdf = new jsPDF('p', 'mm', 'a4');
      const imgWidth = 210;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      pdf.addImage(canvas.toDataURL('image/png'), 'PNG', 0, 0, imgWidth, imgHeight);
      pdf.save(`Invoice-${invoiceData.invoiceNumber}.pdf`);
      
      toast({
        title: "Success",
        description: "Invoice PDF generated successfully"
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to generate PDF",
        variant: "destructive"
      });
    }
  };

  // Print functionality
  const printInvoice = () => {
    const printWindow = window.open('', '_blank');
    if (printWindow && invoiceRef.current) {
      printWindow.document.write(`
        <html>
          <head>
            <title>Invoice ${invoiceData.invoiceNumber}</title>
            <style>
              body { font-family: Arial, sans-serif; margin: 20px; }
              .invoice-header { text-align: center; margin-bottom: 30px; }
              .invoice-details { display: flex; justify-content: space-between; margin-bottom: 30px; }
              .invoice-table { width: 100%; border-collapse: collapse; margin-bottom: 30px; }
              .invoice-table th, .invoice-table td { border: 1px solid #ddd; padding: 12px; text-align: left; }
              .invoice-table th { background-color: #f8f9fa; }
              .invoice-totals { text-align: right; }
              @media print { body { margin: 0; } }
            </style>
          </head>
          <body>
            ${invoiceRef.current.innerHTML}
          </body>
        </html>
      `);
      printWindow.document.close();
      printWindow.print();
    }
  };

  // Save invoice
  const saveInvoice = () => {
    const updatedInvoices = [...savedInvoices];
    const existingIndex = updatedInvoices.findIndex(inv => inv.invoiceNumber === invoiceData.invoiceNumber);
    
    if (existingIndex >= 0) {
      updatedInvoices[existingIndex] = invoiceData;
    } else {
      updatedInvoices.push(invoiceData);
    }
    
    setSavedInvoices(updatedInvoices);
    localStorage.setItem('savedInvoices', JSON.stringify(updatedInvoices));
    
    toast({
      title: "Success",
      description: "Invoice saved successfully"
    });
  };

  // Load saved invoices on component mount
  React.useEffect(() => {
    const saved = localStorage.getItem('savedInvoices');
    if (saved) {
      setSavedInvoices(JSON.parse(saved));
    }
  }, []);

  const categories = [
    { id: "all", name: "All Documents", count: documentTemplates.length + externalTools.length },
    { id: "billing", name: "Billing", count: 1 },
    { id: "shipping", name: "Shipping", count: documentTemplates.filter(d => d.category === "shipping").length },
    { id: "receiving", name: "Receiving", count: documentTemplates.filter(d => d.category === "receiving").length },
    { id: "inventory", name: "Inventory", count: documentTemplates.filter(d => d.category === "inventory").length },
    { id: "tools", name: "External Tools", count: externalTools.length },
    { id: "safety", name: "Safety", count: documentTemplates.filter(d => d.category === "safety").length },
  ];

  const filteredTemplates = documentTemplates.filter(doc => 
    selectedCategory === "all" || doc.category === selectedCategory
  );

  const filteredTools = externalTools.filter(tool => 
    selectedCategory === "all" || tool.category === selectedCategory
  );

  const allFilteredItems = [...filteredTemplates, ...filteredTools];

  const handleWebSearch = async () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Search Required",
        description: "Please enter a search term",
        variant: "destructive",
      });
      return;
    }

    setIsSearching(true);
    
    try {
      // Simulate web search - in real app would call search API
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Mock search results
      const mockResults = [
        {
          title: "Warehouse Management Best Practices Guide",
          description: "Comprehensive guide covering inventory management, safety protocols, and operational efficiency in warehouse environments.",
          url: "https://example.com/warehouse-guide",
          source: "Industry Publication",
          type: "Guide",
        },
        {
          title: "OSHA Warehouse Safety Standards",
          description: "Official safety requirements and guidelines for warehouse operations from the Occupational Safety and Health Administration.",
          url: "https://osha.gov/warehouse-safety",
          source: "OSHA.gov",
          type: "Regulation",
        },
        {
          title: "Shipping Documentation Templates",
          description: "Collection of standard forms including bill of lading, packing slips, and customs documentation templates.",
          url: "https://example.com/shipping-docs",
          source: "Logistics Resource",
          type: "Templates",
        },
        {
          title: "Inventory Cycle Counting Procedures",
          description: "Step-by-step procedures for conducting accurate inventory cycle counts and maintaining stock accuracy.",
          url: "https://example.com/cycle-counting",
          source: "Operations Manual",
          type: "Procedure",
        },
      ];

      setSearchResults(mockResults);
      
      // Add to recent searches
      if (!recentSearches.includes(searchQuery)) {
        setRecentSearches(prev => [searchQuery, ...prev.slice(0, 4)]);
      }

      toast({
        title: "Search Complete",
        description: `Found ${mockResults.length} results for "${searchQuery}"`,
      });
    } catch (error) {
      toast({
        title: "Search Error",
        description: "Failed to search for documents",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleDownloadTemplate = (doc: any) => {
    toast({
      title: "Download Started",
      description: `Downloading ${doc.title}`,
    });
    // In real app, would trigger actual download
  };

  const handleOpenExternal = (tool: any) => {
    window.open(tool.url, '_blank');
    toast({
      title: "Opening External Tool",
      description: `Opening ${tool.title} in new tab`,
    });
  };

  const getCategoryBadge = (category: string) => {
    const variants = {
      shipping: "bg-blue-600 text-white",
      receiving: "bg-green-600 text-white", 
      inventory: "bg-purple-600 text-white",
      safety: "bg-red-600 text-white",
      tools: "bg-orange-600 text-white",
    };
    return (
      <Badge className={variants[category as keyof typeof variants] || "bg-gray-600 text-white"}>
        {category.charAt(0).toUpperCase() + category.slice(1)}
      </Badge>
    );
  };

  const getFormatBadge = (format: string) => {
    const variants = {
      PDF: "bg-red-100 text-red-800",
      Excel: "bg-green-100 text-green-800",
      Word: "bg-blue-100 text-blue-800",
      "Web App": "bg-purple-100 text-purple-800",
    };
    return (
      <Badge variant="outline" className={variants[format as keyof typeof variants]}>
        {format}
      </Badge>
    );
  };

  const getTypeBadge = (type: string) => {
    const variants = {
      Guide: "bg-purple-100 text-purple-800",
      Regulation: "bg-red-100 text-red-800",
      Templates: "bg-blue-100 text-blue-800",
      Procedure: "bg-green-100 text-green-800",
    };
    return (
      <Badge variant="outline" className={variants[type as keyof typeof variants]}>
        {type}
      </Badge>
    );
  };

  return (
    <div className="space-y-6 p-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center">
            <FileText className="h-6 w-6 mr-2" />
            Warehouse Documents & Resources
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="search" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="search">Web Search</TabsTrigger>
          <TabsTrigger value="templates">Document Templates</TabsTrigger>
          <TabsTrigger value="invoices">Invoice Editor</TabsTrigger>
          <TabsTrigger value="saved">Saved Resources</TabsTrigger>
        </TabsList>

        {/* Web Search Tab */}
        <TabsContent value="search" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="h-5 w-5 mr-2" />
                Search Warehouse Documents Online
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Search Input */}
              <div className="flex space-x-4">
                <div className="flex-1">
                  <Input
                    type="text"
                    placeholder="Search for warehouse documents, procedures, templates..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleWebSearch()}
                    className="w-full"
                    data-testid="input-web-search"
                  />
                </div>
                <Button 
                  onClick={handleWebSearch}
                  disabled={isSearching}
                  className="bg-primary hover:bg-primary/90"
                  data-testid="button-web-search"
                >
                  {isSearching ? (
                    <>
                      <Search className="h-4 w-4 mr-2 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="h-4 w-4 mr-2" />
                      Search Web
                    </>
                  )}
                </Button>
              </div>

              {/* Recent Searches */}
              {recentSearches.length > 0 && (
                <div>
                  <h4 className="text-sm font-medium mb-2 flex items-center">
                    <Clock className="h-4 w-4 mr-1" />
                    Recent Searches
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {recentSearches.map((search, index) => (
                      <Button
                        key={index}
                        variant="outline"
                        size="sm"
                        onClick={() => setSearchQuery(search)}
                        data-testid={`button-recent-search-${index}`}
                      >
                        {search}
                      </Button>
                    ))}
                  </div>
                </div>
              )}

              {/* Search Results */}
              {searchResults.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Search Results</h3>
                  {searchResults.map((result, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-medium text-lg mb-2">{result.title}</h4>
                            <p className="text-muted-foreground mb-3">{result.description}</p>
                            <div className="flex items-center space-x-4 text-sm text-muted-foreground">
                              <span>Source: {result.source}</span>
                              {getTypeBadge(result.type)}
                            </div>
                          </div>
                          <div className="flex space-x-2 ml-4">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                toast({
                                  title: "Opening Link",
                                  description: `Opening ${result.title}`,
                                });
                              }}
                              data-testid={`button-open-result-${index}`}
                            >
                              <ExternalLink className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                toast({
                                  title: "Bookmarked",
                                  description: `Saved ${result.title} to bookmarks`,
                                });
                              }}
                              data-testid={`button-bookmark-result-${index}`}
                            >
                              <Bookmark className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Document Templates Tab */}
        <TabsContent value="templates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Archive className="h-5 w-5 mr-2" />
                Document Templates
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Category Filter */}
              <div className="flex space-x-2 mb-6">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    data-testid={`button-category-${category.id}`}
                  >
                    {category.name} ({category.count})
                  </Button>
                ))}
              </div>

              {/* Templates and Tools Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {allFilteredItems.map((item) => (
                  <Card key={item.id}>
                    <CardContent className="p-4">
                      <div className="flex justify-between items-start mb-3">
                        {(item as any).isExternal ? (
                          <Globe className="h-8 w-8 text-primary" />
                        ) : (
                          <FileText className="h-8 w-8 text-primary" />
                        )}
                        <div className="flex space-x-2">
                          {getCategoryBadge(item.category)}
                          {getFormatBadge(item.format)}
                        </div>
                      </div>
                      <h4 className="font-medium mb-2">{item.title}</h4>
                      <p className="text-sm text-muted-foreground mb-4">{item.description}</p>
                      <div className="flex justify-between items-center">
                        <span className="text-xs text-muted-foreground">
                          Updated {item.lastUpdated.toLocaleDateString()}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => (item as any).isExternal ? handleOpenExternal(item) : handleDownloadTemplate(item)}
                          data-testid={`button-${(item as any).isExternal ? 'open' : 'download'}-${item.id}`}
                        >
                          {(item as any).isExternal ? (
                            <ExternalLink className="h-4 w-4" />
                          ) : (
                            <Download className="h-4 w-4" />
                          )}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Invoice Editor Tab */}
        <TabsContent value="invoices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center">
                  <FileText className="h-5 w-5 mr-2" />
                  Invoice Editor & PDF Generator
                </div>
                <div className="flex space-x-2">
                  <Button onClick={saveInvoice} variant="outline" size="sm" className="print-hide" data-testid="button-save-invoice">
                    <Save className="h-4 w-4 mr-2" />
                    Save
                  </Button>
                  <Button onClick={printInvoice} variant="outline" size="sm" className="print-hide" data-testid="button-print-invoice">
                    <Printer className="h-4 w-4 mr-2" />
                    Print
                  </Button>
                  <Button onClick={generatePDF} size="sm" className="print-hide" data-testid="button-generate-pdf">
                    <Download className="h-4 w-4 mr-2" />
                    Generate PDF
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Invoice Form */}
                <div className="space-y-6">
                  {/* Invoice Title */}
                  <div>
                    <Label htmlFor="invoiceTitle">Invoice Title</Label>
                    <Input
                      id="invoiceTitle"
                      value={invoiceData.invoiceTitle}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, invoiceTitle: e.target.value }))}
                      data-testid="input-invoice-title"
                    />
                  </div>

                  {/* Company Information */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Your Company (From)</h3>
                    
                    <div>
                      <Label htmlFor="companyName">Company Name</Label>
                      <Input
                        id="companyName"
                        value={invoiceData.companyName}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, companyName: e.target.value }))}
                        data-testid="input-company-name"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="companyAddress">Company Address</Label>
                      <Input
                        id="companyAddress"
                        value={invoiceData.companyAddress}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, companyAddress: e.target.value }))}
                        data-testid="input-company-address"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="companyCity">City</Label>
                        <Input
                          id="companyCity"
                          value={invoiceData.companyCity}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, companyCity: e.target.value }))}
                          data-testid="input-company-city"
                        />
                      </div>
                      <div>
                        <Label htmlFor="companyState">State</Label>
                        <Input
                          id="companyState"
                          value={invoiceData.companyState}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, companyState: e.target.value }))}
                          data-testid="input-company-state"
                        />
                      </div>
                      <div>
                        <Label htmlFor="companyZip">ZIP</Label>
                        <Input
                          id="companyZip"
                          value={invoiceData.companyZip}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, companyZip: e.target.value }))}
                          data-testid="input-company-zip"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="companyPhone">Phone</Label>
                        <Input
                          id="companyPhone"
                          value={invoiceData.companyPhone}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, companyPhone: e.target.value }))}
                          data-testid="input-company-phone"
                        />
                      </div>
                      <div>
                        <Label htmlFor="companyEmail">Email</Label>
                        <Input
                          id="companyEmail"
                          value={invoiceData.companyEmail}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, companyEmail: e.target.value }))}
                          data-testid="input-company-email"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="companyWebsite">Website</Label>
                      <Input
                        id="companyWebsite"
                        value={invoiceData.companyWebsite}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, companyWebsite: e.target.value }))}
                        data-testid="input-company-website"
                      />
                    </div>
                  </div>
                  
                  {/* Invoice Details */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Invoice Details</h3>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="invoiceNumber">Invoice Number</Label>
                        <Input
                          id="invoiceNumber"
                          value={invoiceData.invoiceNumber}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, invoiceNumber: e.target.value }))}
                          data-testid="input-invoice-number"
                        />
                      </div>
                      <div>
                        <Label htmlFor="date">Date</Label>
                        <Input
                          id="date"
                          type="date"
                          value={invoiceData.date}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, date: e.target.value }))}
                          data-testid="input-invoice-date"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="dueDate">Due Date</Label>
                        <Input
                          id="dueDate"
                          type="date"
                          value={invoiceData.dueDate}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, dueDate: e.target.value }))}
                          data-testid="input-due-date"
                        />
                      </div>
                      <div>
                        <Label htmlFor="paymentTerms">Payment Terms</Label>
                        <Input
                          id="paymentTerms"
                          value={invoiceData.paymentTerms}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, paymentTerms: e.target.value }))}
                          data-testid="input-payment-terms"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="taxRate">Tax Rate (%)</Label>
                      <Input
                        id="taxRate"
                        type="number"
                        step="0.01"
                        value={invoiceData.taxRate}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, taxRate: parseFloat(e.target.value) || 0 }))}
                        data-testid="input-tax-rate"
                      />
                    </div>
                  </div>

                  {/* Customer Info */}
                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold">Customer Information (Bill To)</h3>
                    
                    <div>
                      <Label htmlFor="customerName">Customer Name</Label>
                      <Input
                        id="customerName"
                        value={invoiceData.customerName}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, customerName: e.target.value }))}
                        data-testid="input-customer-name"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="customerAddress">Address</Label>
                      <Input
                        id="customerAddress"
                        value={invoiceData.customerAddress}
                        onChange={(e) => setInvoiceData(prev => ({ ...prev, customerAddress: e.target.value }))}
                        data-testid="input-customer-address"
                      />
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="customerCity">City</Label>
                        <Input
                          id="customerCity"
                          value={invoiceData.customerCity}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, customerCity: e.target.value }))}
                          data-testid="input-customer-city"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerState">State</Label>
                        <Input
                          id="customerState"
                          value={invoiceData.customerState}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, customerState: e.target.value }))}
                          data-testid="input-customer-state"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerZip">ZIP</Label>
                        <Input
                          id="customerZip"
                          value={invoiceData.customerZip}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, customerZip: e.target.value }))}
                          data-testid="input-customer-zip"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="customerPhone">Phone</Label>
                        <Input
                          id="customerPhone"
                          value={invoiceData.customerPhone}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, customerPhone: e.target.value }))}
                          data-testid="input-customer-phone"
                        />
                      </div>
                      <div>
                        <Label htmlFor="customerEmail">Email</Label>
                        <Input
                          id="customerEmail"
                          value={invoiceData.customerEmail}
                          onChange={(e) => setInvoiceData(prev => ({ ...prev, customerEmail: e.target.value }))}
                          data-testid="input-customer-email"
                        />
                      </div>
                    </div>
                  </div>

                  {/* Line Items */}
                  <h4 className="text-md font-semibold mt-6">Line Items</h4>
                  <div className="space-y-3">
                    {invoiceData.items.map((item) => (
                      <div key={item.id} className="grid grid-cols-12 gap-2 items-end">
                        <div className="col-span-5">
                          <Label>Description</Label>
                          <Input
                            value={item.description}
                            onChange={(e) => updateInvoiceItem(item.id, 'description', e.target.value)}
                            placeholder="Item description"
                            data-testid={`input-item-description-${item.id}`}
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Qty</Label>
                          <Input
                            type="number"
                            value={item.quantity}
                            onChange={(e) => updateInvoiceItem(item.id, 'quantity', parseInt(e.target.value) || 0)}
                            data-testid={`input-item-quantity-${item.id}`}
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Price</Label>
                          <Input
                            type="number"
                            step="0.01"
                            value={item.unitPrice}
                            onChange={(e) => updateInvoiceItem(item.id, 'unitPrice', parseFloat(e.target.value) || 0)}
                            data-testid={`input-item-price-${item.id}`}
                          />
                        </div>
                        <div className="col-span-2">
                          <Label>Total</Label>
                          <Input
                            value={`$${item.total.toFixed(2)}`}
                            disabled
                            data-testid={`text-item-total-${item.id}`}
                          />
                        </div>
                        <div className="col-span-1">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => removeInvoiceItem(item.id)}
                            disabled={invoiceData.items.length === 1}
                            data-testid={`button-remove-item-${item.id}`}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <Button onClick={addInvoiceItem} variant="outline" size="sm" data-testid="button-add-item">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Item
                  </Button>

                  {/* Notes */}
                  <div>
                    <Label htmlFor="notes">Notes</Label>
                    <Textarea
                      id="notes"
                      value={invoiceData.notes}
                      onChange={(e) => setInvoiceData(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Additional notes or terms..."
                      data-testid="textarea-notes"
                    />
                  </div>
                </div>

                {/* Invoice Preview */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold">Invoice Preview</h3>
                  <div ref={invoiceRef} className="invoice-container bg-white p-8 border-2 border-gray-200 rounded-lg shadow-lg">
                    {/* Invoice Header */}
                    <div className="invoice-header text-center mb-8 border-b-2 border-orange-600 pb-6 print-no-break">
                      <h1 className="text-4xl font-bold text-black mb-4 print:text-3xl">{invoiceData.invoiceTitle}</h1>
                      <div className="text-2xl font-bold text-orange-600 mb-2 print:text-xl print:text-black">{invoiceData.companyName}</div>
                      <div className="text-sm text-black font-medium print:text-sm">Safety Netting Manufacturer</div>
                    </div>

                    {/* Company and Customer Info */}
                    <div className="invoice-body grid grid-cols-2 gap-8 mb-8 print-no-break">
                      {/* From Section */}
                      <div>
                        <h3 className="text-lg font-bold text-black mb-3 border-b border-gray-300 pb-1 print:text-base print:border-black">FROM:</h3>
                        <div className="text-sm text-black space-y-1 print:text-sm">
                          <div className="font-bold text-base print:text-sm print:font-bold">{invoiceData.companyName}</div>
                          <div>{invoiceData.companyAddress}</div>
                          <div>
                            {invoiceData.companyCity}, {invoiceData.companyState} {invoiceData.companyZip}
                          </div>
                          {invoiceData.companyPhone && <div>Phone: {invoiceData.companyPhone}</div>}
                          {invoiceData.companyEmail && <div>Email: {invoiceData.companyEmail}</div>}
                          {invoiceData.companyWebsite && <div>Website: {invoiceData.companyWebsite}</div>}
                        </div>
                      </div>
                      
                      {/* Bill To Section */}
                      <div>
                        <h3 className="text-lg font-bold text-black mb-3 border-b border-gray-300 pb-1 print:text-base print:border-black">BILL TO:</h3>
                        <div className="text-sm text-black space-y-1 print:text-sm">
                          <div className="font-bold text-base print:text-sm print:font-bold">{invoiceData.customerName || 'Customer Name'}</div>
                          <div>{invoiceData.customerAddress}</div>
                          <div>
                            {invoiceData.customerCity && `${invoiceData.customerCity}, `}
                            {invoiceData.customerState} {invoiceData.customerZip}
                          </div>
                          {invoiceData.customerPhone && <div>Phone: {invoiceData.customerPhone}</div>}
                          {invoiceData.customerEmail && <div>Email: {invoiceData.customerEmail}</div>}
                        </div>
                      </div>
                    </div>

                    {/* Invoice Details */}
                    <div className="grid grid-cols-2 gap-8 mb-8 print-no-break">
                      <div></div>
                      <div className="bg-gray-50 p-4 rounded print:bg-white print:border print:border-black print:p-3">
                        <div className="space-y-2 text-sm text-black print:space-y-1">
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Invoice Number:</span> 
                            <span className="font-mono">{invoiceData.invoiceNumber}</span>
                          </div>
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Invoice Date:</span> 
                            <span>{new Date(invoiceData.date).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Due Date:</span> 
                            <span>{new Date(invoiceData.dueDate).toLocaleDateString()}</span>
                          </div>
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Payment Terms:</span> 
                            <span>{invoiceData.paymentTerms}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Invoice Table */}
                    <table className="w-full border-collapse border-2 border-black mb-6 print:border print:border-black print:mb-4">
                      <thead>
                        <tr className="bg-orange-600 text-white print:bg-gray-200 print:text-black">
                          <th className="border border-black px-4 py-3 text-left font-bold print:px-2 print:py-2 print:text-sm print:border-black">DESCRIPTION</th>
                          <th className="border border-black px-4 py-3 text-center font-bold print:px-2 print:py-2 print:text-sm print:border-black">QTY</th>
                          <th className="border border-black px-4 py-3 text-right font-bold print:px-2 print:py-2 print:text-sm print:border-black">UNIT PRICE</th>
                          <th className="border border-black px-4 py-3 text-right font-bold print:px-2 print:py-2 print:text-sm print:border-black">TOTAL</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoiceData.items.map((item, index) => (
                          <tr key={item.id} className={index % 2 === 0 ? "bg-white print:bg-white" : "bg-gray-50 print:bg-white"}>
                            <td className="border border-gray-400 px-4 py-3 text-black print:border-black print:px-2 print:py-2 print:text-sm">{item.description || 'Item description'}</td>
                            <td className="border border-gray-400 px-4 py-3 text-center text-black print:border-black print:px-2 print:py-2 print:text-sm">{item.quantity}</td>
                            <td className="border border-gray-400 px-4 py-3 text-right text-black print:border-black print:px-2 print:py-2 print:text-sm">${item.unitPrice.toFixed(2)}</td>
                            <td className="border border-gray-400 px-4 py-3 text-right text-black font-semibold print:border-black print:px-2 print:py-2 print:text-sm print:font-bold">${item.total.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>

                    {/* Invoice Totals */}
                    <div className="invoice-totals flex justify-end mb-8 print-no-break">
                      <div className="w-64 bg-gray-50 p-4 rounded border print:bg-white print:border-2 print:border-black print:w-auto print:min-w-48 print:p-3">
                        <div className="space-y-2 text-black print:space-y-1">
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Subtotal:</span> 
                            <span className="font-mono">${invoiceData.subtotal.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between print:text-sm">
                            <span className="font-semibold">Tax ({invoiceData.taxRate}%):</span> 
                            <span className="font-mono">${invoiceData.taxAmount.toFixed(2)}</span>
                          </div>
                          <div className="flex justify-between text-xl font-bold border-t-2 border-black pt-2 print:text-lg print:border-t-2 print:border-black print:pt-1">
                            <span>TOTAL:</span> 
                            <span className="font-mono">${invoiceData.total.toFixed(2)}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Notes and Payment Terms */}
                    {(invoiceData.notes || invoiceData.paymentTerms) && (
                      <div className="border-t-2 border-gray-300 pt-6">
                        {invoiceData.notes && (
                          <div className="mb-4">
                            <div className="font-bold text-black mb-2">NOTES:</div>
                            <div className="text-sm text-black whitespace-pre-line bg-gray-50 p-3 rounded">
                              {invoiceData.notes}
                            </div>
                          </div>
                        )}
                        
                        <div className="text-center">
                          <div className="text-sm text-black">
                            <span className="font-semibold">Payment Terms:</span> {invoiceData.paymentTerms}
                          </div>
                          <div className="text-xs text-gray-600 mt-2">
                            Thank you for your business!
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Saved Resources Tab */}
        <TabsContent value="saved" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bookmark className="h-5 w-5 mr-2" />
                Saved Resources & Quick Access
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <h4 className="font-medium">Frequently Searched Topics</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {savedSearches.map((search, index) => (
                    <Card key={index}>
                      <CardContent className="p-4">
                        <div className="flex justify-between items-center">
                          <span>{search}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setSearchQuery(search);
                              // Switch to search tab
                              const searchTab = document.querySelector('[value="search"]') as HTMLElement;
                              searchTab?.click();
                            }}
                            data-testid={`button-quick-search-${index}`}
                          >
                            <Search className="h-4 w-4" />
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}