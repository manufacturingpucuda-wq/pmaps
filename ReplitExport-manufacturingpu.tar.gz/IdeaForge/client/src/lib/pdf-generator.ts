// PDF generation utility for shipping documents
export const generateShipmentPDF = (shipment: any) => {
  // Create a new window for PDF preview
  const printWindow = window.open('', '_blank', 'width=800,height=600');
  if (!printWindow) {
    alert('Please allow popups to generate PDF preview');
    return;
  }

  let content = '';
  
  if (shipment.formType === 'pallet') {
    // Generate Pallet/Box Form PDF
    content = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Pallet/Box Shipment - ${shipment.shipmentNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .form-section { margin-bottom: 20px; }
            .form-row { display: flex; gap: 20px; margin-bottom: 10px; }
            .form-field { flex: 1; }
            .form-field label { font-weight: bold; display: block; margin-bottom: 5px; }
            .form-field input { width: 100%; padding: 8px; border: 2px solid #ccc; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
            th { background-color: #f5f5f5; font-weight: bold; }
            .signature-section { margin-top: 30px; display: flex; gap: 30px; }
            .signature-field { flex: 1; }
            .totals { background-color: #fffbea; padding: 15px; border: 2px solid #fbbf24; }
            @media print { body { margin: 0; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>PUCUDA MFG</h1>
            <h2>Pallet/Box Shipment Form</h2>
            <p><strong>Shipment #:</strong> ${shipment.shipmentNumber}</p>
          </div>
          
          <div class="form-section">
            <div class="form-row">
              <div class="form-field">
                <label>SALES ORDER #</label>
                <input type="text" value="${shipment.salesOrderNumber || ''}" readonly>
              </div>
              <div class="form-field">
                <label>CUSTOMER NAME</label>
                <input type="text" value="${shipment.customerName || ''}" readonly>
              </div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>PALLET/BOX QTY</th>
                <th>LENGTH</th>
                <th>WIDTH</th>
                <th>HEIGHT</th>
                <th>PALLET WEIGHT</th>
              </tr>
            </thead>
            <tbody>
              ${shipment.palletBoxItems?.map((item: any) => `
                <tr>
                  <td>${item.qty}</td>
                  <td>${item.length}</td>
                  <td>${item.width}</td>
                  <td>${item.height}</td>
                  <td>${item.weight}</td>
                </tr>
              `).join('') || '<tr><td colspan="5">No items</td></tr>'}
            </tbody>
          </table>

          <div class="totals">
            <div class="form-row">
              <div class="form-field">
                <label>TOTAL QTY</label>
                <input type="text" value="${shipment.totalQty || 0}" readonly>
              </div>
              <div class="form-field">
                <label>TOTAL WEIGHT</label>
                <input type="text" value="${shipment.totalWeight || 0}" readonly>
              </div>
            </div>
          </div>

          <div class="form-section">
            <label><strong>NOTES:</strong></label>
            <textarea style="width: 100%; padding: 8px; border: 2px solid #ccc; height: 60px;" readonly>${shipment.notes || ''}</textarea>
          </div>

          <div class="signature-section">
            <div class="signature-field">
              <label>Completed by:</label>
              <input type="text" value="${shipment.completedBy || ''}" readonly>
            </div>
            <div class="signature-field">
              <label>Date:</label>
              <input type="text" value="${shipment.completedDate || ''}" readonly>
            </div>
            <div class="signature-field">
              <label>Supervisor:</label>
              <input type="text" value="${shipment.supervisor || ''}" readonly>
            </div>
          </div>
        </body>
      </html>
    `;
  } else if (shipment.formType === 'pulllist') {
    // Generate Pull List Form PDF
    content = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Pull List - ${shipment.shipmentNumber}</title>
          <style>
            body { font-family: Arial, sans-serif; padding: 20px; }
            .header { text-align: center; margin-bottom: 30px; }
            .form-section { margin-bottom: 20px; }
            .form-row { display: flex; gap: 20px; margin-bottom: 10px; }
            .form-field { flex: 1; }
            .form-field label { font-weight: bold; display: block; margin-bottom: 5px; }
            .form-field input { width: 100%; padding: 8px; border: 2px solid #ccc; }
            table { width: 100%; border-collapse: collapse; margin: 20px 0; }
            th, td { border: 1px solid #ccc; padding: 8px; text-align: center; }
            th { background-color: #f5f5f5; font-weight: bold; }
            .signature-section { margin-top: 30px; display: flex; gap: 30px; }
            .signature-field { flex: 1; }
            @media print { body { margin: 0; } }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>PUCUDA MFG</h1>
            <h2>Pull List</h2>
            <p><strong>Shipment #:</strong> ${shipment.shipmentNumber}</p>
          </div>
          
          <div class="form-section">
            <div class="form-row">
              <div class="form-field">
                <label>Project:</label>
                <input type="text" value="${shipment.project || ''}" readonly>
              </div>
              <div class="form-field">
                <label>Date:</label>
                <input type="text" value="${shipment.date || ''}" readonly>
              </div>
            </div>
            <div class="form-row">
              <div class="form-field">
                <label>Company:</label>
                <input type="text" value="${shipment.company || ''}" readonly>
              </div>
              <div class="form-field">
                <label>Pull List Received:</label>
                <input type="text" value="${shipment.pullListReceived === 'yes' ? 'Yes' : 'No'}" readonly>
              </div>
            </div>
            <div class="form-field">
              <label>Sales Order #:</label>
              <input type="text" value="${shipment.salesOrderNumber || ''}" readonly>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>QTY ORDERED</th>
                <th>QTY SHIPPED</th>
                <th>PART NUMBER</th>
                <th>DESCRIPTION</th>
                <th>QTY RETURNED</th>
              </tr>
            </thead>
            <tbody>
              ${shipment.items?.map((item: any) => `
                <tr>
                  <td>${item.qtyOrdered}</td>
                  <td>${item.qtyShipped}</td>
                  <td>${item.partNumber}</td>
                  <td>${item.description}</td>
                  <td>${item.qtyReturned || 0}</td>
                </tr>
              `).join('') || '<tr><td colspan="5">No items</td></tr>'}
            </tbody>
          </table>

          <div class="signature-section">
            <div class="signature-field">
              <label>Pulled by:</label>
              <input type="text" value="${shipment.pulledBy || ''}" readonly>
              <label style="margin-top: 10px;">Date:</label>
              <input type="text" value="${shipment.pulledDate || ''}" readonly>
            </div>
            <div class="signature-field">
              <label>Supervisor:</label>
              <input type="text" value="${shipment.supervisor || ''}" readonly>
              <label style="margin-top: 10px;">Date:</label>
              <input type="text" value="${shipment.supervisorDate || ''}" readonly>
            </div>
          </div>
        </body>
      </html>
    `;
  }

  printWindow.document.write(content);
  printWindow.document.close();
  
  // Add print functionality
  printWindow.onload = () => {
    setTimeout(() => {
      printWindow.focus();
    }, 500);
  };
};